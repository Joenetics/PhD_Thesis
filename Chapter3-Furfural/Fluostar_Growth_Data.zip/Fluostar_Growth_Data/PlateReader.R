##working directory set as source of R file... which is with Plate reader data.

#turns plate reader files into characteristics

install.packages("reshape2")
install.packages("ggplot2")
install.packages("Hmisc", dependencies=T)
install.packages('inflection')
library('inflection')
library("Hmisc")
library("reshape2")
library("ggplot2")




#Run this, it reads in all the relevant CSVs (if they're in directory) so you can do the rest of the stuff
LogGrowth <- "LogGrowth" #Run this if you're doing log growth of ODs.
#LogGrowth <- ""          #Run this if you're just using regular data points (linear growth). not recommended.
i <- "DE"  # could be 1,2,3,...9, DE



#specific_wells <- c("P1D04", "P1D06", "P1D08", "P1D10", "P1D11", "P1D12", "P1E01", "P1E02", "P1E03", "P1E04", "P1E05", "P1E06", "P1E07", "P1E08", "P1E09", "P1E10", "P1E11", "P1E12", "P1F01", "P1F02", "P1F03", "P1F05", "P1F06", "P1F07", "P1F11", "P1G05", "P1G06", "P1G08", "P1G09", "P1G10", "P3C09", "P3D01", "P3E04", "P3F02", "P3F03", "P3F04", "P3F07", "P3F10", "P3F11", "P3G01", "P3G03", "P3G04", "P3G05", "P3G06", "P3H02", "P3H03", "P3H04", "P3H05", "P3H06", "P3H09", "P4C11", "P4C12", "P4D01", "P4D05", "P4D06", "P4D09", "P4D11", "P4E02", "P4E04", "P4E06", "P4E07", "P4E08", "P4E09", "P4E10", "P4E11", "P4E12", "P4F01", "P4F02", "P4F03", "P4F04", "P4F05", "P4F09", "P4F10", "P4F11", "P4F12", "P4G01", "P4G02", "P4G03", "P4G05", "P4G07", "P4G08", "P4G09", "P4G10", "P4G11", "P4G12", "P4H02", "P4H03", "P4H04", "P4H06", "P4H07", "P4H09", "P4H10", "P4H11", "P4H12", "P5A01", "P5A02", "P5A03", "P5A04", "P5A06", "P5A07", "P5A08", "P5A09", "P5A10", "P5A11", "P5B01", "P5B02", "P5B03", "P5B04", "P5B05", "P5B06", "P5B07", "P5B11", "P5B12", "P5C01", "P5C03", "P5C05", "P5C08", "P5D01", "P5D02", "P5D03", "P5D05", "P5D06", "P5D11", "P5E06", "P6B03", "P6B09", "P6H02", "P7A02", "P7A04", "P7A05", "P7A08", "P7A10", "P7B02", "P7B03", "P7C01", "P7C02", "P7C03", "P7C04", "P7C05", "P7C06", "P7C08", "P7C09", "P7C10", "P7C12", "P7D02", "P7D03", "P7D04", "P7D05", "P7D06", "P7D07", "P7D09", "P7D12", "P7E05", "P7E06", "P7E08", "P7E09", "P7E11", "P7F03", "P7F04", "P7F05", "P7F06", "P7F07", "P7H05", "P7H06", "P7H07", "P7H08", "P7H10", "P7H11")
specific_wells <- TraitData$Well
#SC_Strains <- c("70", "72", "74", "76", "77", "78", "79", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "90", "91", "92", "93", "95", "96", "97", "505", "1006", "1026", "1228", "1245", "1681", "2826", "3452", "167", "192", "196", "197", "200", "205", "206", "208", "210", "211", "212", "213", "221", "222", "223", "224", "225", "228", "1064", "1151", "1337", "3612", "3630", "232", "667", "695", "235", "3265", "3266", "3311", "3313", "3314", "3315", "3318", "3319", "3445", "3447", "3448", "3449", "3455", "3456", "3457", "3458", "3460", "3461", "3462", "3467", "3470", "3471", "3472", "3486", "3487", "360", "2592", "2945", "361", "1444", "1603", "2397", "2733", "2737", "3406", "356", "357", "358", "430", "478", "479", "482", "619", "620", "621", "672", "684", "816", "1406", "1407", "1408", "1409", "1413", "1414", "1415", "2401", "2517", "2688", "2855", "2947", "2948", "490", "491", "1529", "241", "609", "1315", "3557", "3324", "3025", "3026", "3051", "3052", "3028", "2776", "3030", "3122", "3123", "3325", "3326", "2777", "3331", "2778", "3031", "3333", "2779", "3076", "3334", "3338", "3077", "3078", "3032", "3339", "3121", "3124", "3114", "2780", "2798", "3033", "3035", "3125", "3126", "3127", "3036", "3037", "3038", "3039", "2967", "2974")
SC_Strains <- row.names(TraitData)
well_names <- c("A01", "A02", "A03", "A04", "A05", "A06", "A07", "A08", "A09", "A10", "A11", "A12", "B01", "B02", "B03", "B04", "B05", "B06", "B07", "B08", "B09", "B10", "B11", "B12", "C01", "C02", "C03", "C04", "C05", "C06", "C07", "C08", "C09", "C10", "C11", "C12", "D01", "D02", "D03", "D04", "D05", "D06", "D07", "D08", "D09", "D10", "D11", "D12", "E01", "E02", "E03", "E04", "E05", "E06", "E07", "E08", "E09", "E10", "E11", "E12", "F01", "F02", "F03", "F04", "F05", "F06", "F07", "F08", "F09", "F10", "F11", "F12", "G01", "G02", "G03", "G04", "G05", "G06", "G07", "G08", "G09", "G10", "G11", "G12", "H01", "H02", "H03", "H04", "H05", "H06", "H07", "H08", "H09", "H10", "H11", "H12")
#NEEDS  ManhattanPlotGeneration.R  to get TraitData!!
Slope_points <- TraitData$Timepoint.furfural
infelction_points <- TraitData$Rough.Inflection.Point
resistance_scoring <-TraitData$Slope.Point.Cluster.Score + TraitData$MaxOD.Cluster.Score + TraitData$Inflection.Cluster.Score


x11()
par(mfrow=c(12,14))
par(mar=c(1,1,1,1))
for (i in 1:9){
  
  
  
  ##this bit is for DE plates
  #FileName1 <- paste("YPlate1R1.csv", sep = '')
  #FileName2 <- paste("YPlate1R2.csv", sep = '')
  #FileName3 <- paste("YPlate1R3.csv", sep = '')
  #FileName4 <- paste("YPlateDER1.csv", sep = '')
  #FileName5 <- paste("YPlateDER2.csv", sep = '')
  #FileName6 <- paste("YPlateDER3.csv", sep = '')
  
  
  
FileName1 <- paste("YPlate", i, "R1.csv", sep = '')
FileName2 <- paste("YPlate", i, "R2.csv", sep = '')
FileName3 <- paste("YPlate", i, "R3.csv", sep = '')
FileName4 <- paste("YPlate", i, "F15R1.csv", sep = '')
FileName5 <- paste("YPlate", i, "F15R2.csv", sep = '')
FileName6 <- paste("YPlate", i, "F15R3.csv", sep = '')
#FileName7 <- paste("YPlate", i, "F15R4.csv", sep = '')
#FileName8 <- paste("YPlate", i, "R4.csv", sep = '')
#FileName9 <- "testing_three.csv"

MainFile1 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", FileName1, sep = ''))
MainFile2 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", FileName2, sep = ''))
MainFile3 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", FileName3, sep = ''))
MainFile4 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", FileName4, sep = ''))
MainFile5 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", FileName5, sep = ''))
MainFile6 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", FileName6, sep = ''))
#MainFile7 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", FileName7, sep = ''))
#MainFile8 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", FileName8, sep = ''))
#MainFile9 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", FileName9, sep = ''))

# blabla[row,column]
JustData1 <- MainFile1[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
JustData2 <- MainFile2[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
JustData3 <- MainFile3[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
JustData4 <- MainFile4[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
JustData5 <- MainFile5[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
JustData6 <- MainFile6[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
#JustData7 <- MainFile7[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
#JustData8 <- MainFile8[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
#JustData9 <- MainFile9[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
#sixliner(TRUE, FALSE, FALSE, FALSE, i)


for (j in c(1:96)){
  #print((paste("P", (i), well_names[j], sep = "")))
  #print(paste("Strain ", SC_Strains[j]))
  if ( (paste("P", (i), well_names[j], sep = "")) %in% specific_wells){
    matching <- match((paste("P", (i), well_names[j], sep = "")), specific_wells)
    ThreePlot(FALSE, FALSE, FALSE, TRUE, TRUE, infelction_points[matching], Slope_points[matching], well_names[j], paste("P", (i), well_names[j], " S: ", SC_Strains[matching], " R: ", resistance_scoring[matching], sep = ""), TRUE)
    #print(paste("P", (i), well_names[j], " Strain: ", SC_Strains[j], sep = ""))
    #print("D")
  } 
}

}

  dev.copy2pdf(file = paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\ForPresentation.pdf", sep=''))



##test here
for (j in c(1:96)){
  #print((paste("P", (i), well_names[j], sep = "")))
  #print(paste("Strain ", SC_Strains[j]))
  if ( (paste("P", (i), well_names[j], sep = "")) %in% specific_wells){
    matching <- match((paste("P", (i), well_names[j], sep = "")), specific_wells)
    ThreePlot(FALSE, FALSE, FALSE, TRUE, TRUE, infelction_points[matching], Slope_points[matching], well_names[j], paste("P", (i), well_names[j], " Strain: ", SC_Strains[matching], " Resistance: ", resistance_scoring[matching], sep = ""), FALSE)
    #print(paste("P", (i), well_names[j], " Strain: ", SC_Strains[j], sep = ""))
    #print("D")
  } 
}
# end test

###KAI

FileName1 <- paste("KAI_Plate1_Replicate1.csv", sep = '')
FileName2 <- paste("KAI_Plate1_Replicate2.csv", sep = '')
FileName3 <- paste("KAI_Plate1_Replicate3.csv", sep = '')
FileName4 <- paste("KAI_Plate1_Replicate4.csv", sep = '')
FileName5 <- paste("KAI_Plate1_Replicate5.csv", sep = '')


MainFile1 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Malt_Extract\\Kai_Growth\\", FileName1, sep = ''))
MainFile2 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Malt_Extract\\Kai_Growth\\", FileName2, sep = ''))
MainFile3 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Malt_Extract\\Kai_Growth\\", FileName3, sep = ''))
MainFile4 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Malt_Extract\\Kai_Growth\\", FileName4, sep = ''))
MainFile5 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Malt_Extract\\Kai_Growth\\", FileName5, sep = ''))

# blabla[row,column]
JustData1 <- MainFile1[3:98,4:100]            #Take all the datapoints (every half hour) for all wells.
JustData2 <- MainFile2[3:98,4:100]            #Take all the datapoints (every half hour) for all wells.
JustData3 <- MainFile3[3:98,4:100]            #Take all the datapoints (every half hour) for all wells.
JustData4 <- MainFile4[3:98,4:100]            #Take all the datapoints (every half hour) for all wells.
JustData5 <- MainFile5[3:98,4:100]            #Take all the datapoints (every half hour) for all wells.

###KAI

ThreePlot(FALSE, FALSE, FALSE, TRUE, TRUE)
ThreePlot(FALSE, FALSE, FALSE, TRUE, TRUE, 25, 40, "A01", "Tester")
 ####Basic plot of all wells and timepoints

  tab <- t(JustData1) ##Find a way to loop all 3

  plot(tab[,1],type="l",ylim=c(min(tab),max(tab)), main = strsplit(FileName1, ".csv")[[1]], col="red",lty=2,ylab="Optical Density",lwd=1,xlab="Cycle")
  for (i in 2:95){
    lines(tab[,i], type = "l", col = "red", lty = 2, lwd = 1)
  }
  lines(tab[,96], type = "l", col = "black", lty = 2, lwd = 2) ##THIS IS THE CONTROL... which didnt work?
  grid()
  axis(1,at=c(1:nrow(tab)),labels=rownames(tab))

  tab <- t(JustData2) ##Find a way to loop all 3
 #### 
  plot(tab[,1],type="l",ylim=c(min(tab),max(tab)), main = strsplit(FileName2, ".csv")[[1]], col="red",lty=2,ylab="Optical Density",lwd=1,xlab="Cycle")
  for (i in 2:95){
    lines(tab[,i], type = "l", col = "red", lty = 2, lwd = 1)
  }
  lines(tab[,96], type = "l", col = "black", lty = 2, lwd = 2) ##THIS IS THE CONTROL... which didnt work?
  grid()
  axis(1,at=c(1:nrow(tab)),labels=rownames(tab))
 ####
  tab <- t(JustData3) ##Find a way to loop all 3
  
  plot(tab[,1],type="l",ylim=c(min(tab),max(tab)), main = strsplit(FileName3, ".csv")[[1]], col="red",lty=2,ylab="Optical Density",lwd=1,xlab="Cycle")
  for (i in 2:95){
    lines(tab[,i], type = "l", col = "red", lty = 2, lwd = 1)
  }
  lines(tab[,96], type = "l", col = "black", lty = 2, lwd = 2) ##THIS IS THE CONTROL... which didnt work?
  grid()
  axis(1,at=c(1:nrow(tab)),labels=rownames(tab))
  

  



###Here we do each rep on eachother; print out pdf of all 96 wells & their replicates.
  x11()
  par(mfrow=c(12,8))

  par(mar=c(1,1,1,1))
WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
AllThree <- rbind(log10(JustData1), log10(JustData2),log10(JustData3)) ##Log growth!
#AllThree <- rbind((JustData1), (JustData2),(JustData3))              ##normal growth!
for (i in c(1:96)){
  TempVector <- rbind(log10(JustData1[i,]), log10(JustData2[i,]), log10(JustData3[i,])) ##log growth
  #TempVector <- rbind((JustData1[i,]), (JustData2[i,]), (JustData3[i,]))       #Normal growth
  TempVector <- t(TempVector)
  plot(TempVector[,1],type="l",ylim=c(min(AllThree),max(AllThree)), main = paste("Well", WellNames[i], sep = ' '), col="red",lty=2,ylab="Optical Density",lwd=1,xlab="Cycle")
  for (i in 1:3){
    lines(TempVector[,i], type = "l", col = "red", lty = 2, lwd = 1)
  }
  grid()
  axis(1,at=c(1:nrow(TempVector)),labels=rownames(TempVector))

}
  
  dev.copy2pdf(file = "C:/Users/Jsdsa/Desktop/PhD_stuff/Replicates.pdf")
  
  
  
  
  
  ####4-colour plot of quadruple-replicate. 
  #Then, use ReplicateSwapper.py to swap well data, and find best 3 replicates.
  #FourPlot( Do you want it as 12*8 matrix? Then TRUE, do you want an output pdf? then also TRUE)
  #FourPlot(FALSE,FALSE) allows you to run through individual wells in console to see which replicates should be removed of the four.
  FourPlot(FALSE, FALSE)
  
  FourPlot <- function(plotted, yesno){
  
  if (plotted == TRUE) {
  x11()
  par(mfrow=c(8,12))
  
  par(mar=c(1,1,1,1))
  }
  
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
  Tab <- cbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData8[i,])
  Tab <- t(Tab)
  Tab <- data.frame(Tab)
  Tab[,2] <- rep(c(1:49),4)
  Tab[,3] <- c(rep("Red", 49),rep("Blue", 49), rep("Black", 49), rep("pink", 49))
  colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
  plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group, pch = 16, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=c(0,3), xlab = "Cycle(30Min)", ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  

  axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
  } 
  cat("Ignore warnings. They're for row names. Still need to fix that")
  if (yesno == TRUE){
    print("potate")
    dev.copy2pdf(file = paste("C:/Users/Jsdsa/Desktop/PhD_stuff/JustControl", Platenumber,".pdf", sep = ''))
  }
  }
  #Function ends here.
  
  
  ####4-colour plot of quadruple-replicate for KAI. 
  #Then, use ReplicateSwapper.py to swap well data, and find best 3 replicates.
  #FourPlot( Do you want it as 12*8 matrix? Then TRUE, do you want an output pdf? then also TRUE)
  #FourPlot(FALSE,FALSE) allows you to run through individual wells in console to see which replicates should be removed of the four.
  FourPlotKai(TRUE, FALSE)
  
  FourPlotKai <- function(plotted, yesno){
    
    if (plotted == TRUE) {
      x11()
      par(mfrow=c(8,12))
      
      par(mar=c(1,1,1,1))
    }
    
    WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
    for (i in 1:96){
      Tab <- cbind(JustData2[i,], JustData4[i,],JustData6[i,],JustData8[i,])
      #Tab <- cbind(JustData1[i,], JustData3[i,],JustData5[i,],JustData7[i,])
      Tab <- t(Tab)
      Tab <- data.frame(Tab)
      Tab[,2] <- rep(c(1:97),4)
      Tab[,3] <- c(rep("Black", 97),rep("Blue", 97), rep("Pink", 97), rep("Red", 97))
      colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
      plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group, pch = 16, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=c(0,3), xlab = "Cycle(30Min)", ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
      
      axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
    } 
    cat("Ignore warnings. They're for row names. Still need to fix that")
    if (yesno == TRUE){
      print("potate")
      dev.copy2pdf(file = paste("C:/Users/Jsdsa/Desktop/PhD_stuff/JustControl", Platenumber,".pdf", sep = ''))
    }
  }
  #Function ends here.
  
  
  ####3-colour plot of quadruple-replicate. 
  #ThreePlot( Do you want it as 12*8 matrix? Then TRUE, do you want an output pdf? then also TRUE)
  #ThreePlot(FALSE,FALSE) allows you to run through individual wells in console to see which replicates should be removed of the four.
  # third option is control (TRUE) and furfural (FALSE). fourth is for mean and SE instead of all replicates
  ThreePlot(FALSE, FALSE, FALSE, TRUE, TRUE)
  
 
  ThreePlot <- function(plotted, yesno, controlonly, meanSE, logvalues, lag_phase, slope_point, whichwell, titleplot, For12_14){
    #print()
    if (slope_point > 44){
      slope_point <-44
    }
    #print(titleplot)
    std <- function(x) sd(x)/sqrt(length(x))
    if (plotted == TRUE) {
      x11()
      par(mfrow=c(8,12))
      
      par(mar=c(1,1,1,1))
    }
    
    WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
    for (i in 1:96){
      if (whichwell != "NA" && WellNames[i] == whichwell){
        
      if (meanSE == FALSE) {
        
      
      if (controlonly == TRUE){
      Tab <- cbind(JustData1[i,], JustData2[i,],JustData3[i,])
      if (logvalues == TRUE){
        Tab <- log(Tab)
      }
      }
      else {
        #print("Enetered furfural")
        Tab <- cbind(JustData4[i,], JustData5[i,],JustData6[i,])
        if (logvalues == TRUE){
          Tab <- log(Tab)
        }
      }
      Tab <- t(Tab)
      Tab <- data.frame(Tab)
      Tab[,2] <- rep(c(1:49),3)
      if (controlonly == TRUE){
        Tab[,3] <- c(rep("Red", 49),rep("Red", 49), rep("Red", 49))
        colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
        plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group, pch = 16, yaxt = 'n',xaxt = "n",  cex = 1, ylim=c(0,3), xlab = "Time(30Min)", ylab = "OpticalDensity", main = paste("Well", WellNames[i], " Control", sep = ' '))  
        
        axis(1,at=c(1:nrow(Tab)),labels=rownames(c(1:49)))
      }
      else{
        Tab[,3] <- c(rep("Blue", 49),rep("Black", 49), rep("Red", 49))
        colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
        plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group, pch = 16, yaxt = 'n',xaxt = "n",  cex = 1, ylim=c(0,3), xlab = "Time(30Min)", ylab = "OpticalDensity", main = paste("Well", WellNames[i], " Furfural", sep = ' '))  
        
        axis(1,at=c(1:nrow(Tab)),labels=rownames(c(1:49)))
      }
      }
      else{
        #print("Using SE/SD")
        if (controlonly == TRUE){
          Tab <- cbind(rep(0, 49), rep(0, 49), rep(0, 49), rep(0, 49))
        for (j in 1:length(JustData1)){
          if (logvalues == TRUE){
            Tab[j, 1] <- mean(log(c(JustData1[i,j], JustData2[i,j],JustData3[i,j])))
            Tab[j, 2] <- std(log(c(JustData1[i,j], JustData2[i,j],JustData3[i,j])))
          }
          else{
            Tab[j, 1] <- mean(c(JustData1[i,j], JustData2[i,j],JustData3[i,j]))
            Tab[j, 2] <- std(c(JustData1[i,j], JustData2[i,j],JustData3[i,j]))
          }
        }}
        else{
          Tab <- cbind(rep(0, 49), rep(0, 49), rep(0, 49), rep(0, 49))
          for (j in 1:length(JustData1)){
            if (logvalues == TRUE){
              #print("Taking logs")
              Tab[j, 1] <- mean(log(c(JustData4[i,j], JustData5[i,j],JustData6[i,j])))
              Tab[j, 2] <- std(log(c(JustData4[i,j], JustData5[i,j],JustData6[i,j])))
            }
            else{
              Tab[j, 1] <- mean(c(JustData4[i,j], JustData5[i,j],JustData6[i,j]))
              Tab[j, 2] <- std(c(JustData4[i,j], JustData5[i,j],JustData6[i,j]))
            }
          }
        }
        
        if (controlonly == TRUE){
          Tab[,3] <- c(rep("Red", 49))
        }
        else{
          Tab[,3] <- c(rep("Blue", 49))
        }
        Tab[,4] <- c(1:49)
        colnames(Tab) <- c("Mean", "STD", "Colour", "Cycle")
        Tab <- data.frame(Tab)
        Tab[,1] <- as.numeric(as.character(Tab[,1]))
        Tab[,2] <- as.numeric(as.character(Tab[,2]))
        if (controlonly == TRUE){
          #plot(c(1:49), Tab$Mean,  pch = 19, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=range(c(Tab$Mean - Tab$STD, Tab$Mean + Tab$STD )), xlab = "Time(30Mins)", ylab = "OpticalDensity", main = paste("Well", WellNames[i], " Control Conditions", sep = ' '))  
          plot(c(1:49), Tab$Mean,  pch = 19,   cex = 1, ylim=range(c(Tab$Mean - Tab$STD, Tab$Mean + Tab$STD )), xlab = "Time(30Mins)", ylab = "OpticalDensity", main = titleplot)  
        }
        else{
          #plot(c(1:49), Tab$Mean,  pch = 19, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=range(c(Tab$Mean - Tab$STD, Tab$Mean + Tab$STD )), xlab = "Time(30Mins)", ylab = "OpticalDensity", main = paste("Well", WellNames[i], " Furfural Conditions", sep = ' ')) 
          
          if (For12_14 == TRUE){
            par("mar")
            par(mar=c(1,1,1,1))
            
            plot(seq(0, 24, by=0.5), Tab$Mean,  pch = 19, cex = 2, cex.axis = 2, cex.lab = 2, ylim=range(c(-2,2)), xaxt = "n", yaxt = "n", 
                 #col = c(rep("red", 22), rep("black", 8), rep("green", 5), rep("black", 14) ), main = WellNames[i]) # P1E9; strain 87
                 col = c(rep("red", lag_phase), rep("black", (49 - lag_phase)) ), main = titleplot) # P3B3; strain 816
            
          }
          else{
          par(mar=c(5.1,5,4.1,2.1))
          plot(seq(0, 24, by=0.5), Tab$Mean,  pch = 19, cex = 2, cex.axis = 2, cex.lab = 2, ylim=range(c(Tab$Mean - Tab$STD, Tab$Mean + Tab$STD )), xlab = "Time(hrs)", ylab = "Log10 OpticalDensity", 
               #col = c(rep("red", 22), rep("black", 8), rep("green", 5), rep("black", 14) ), main = WellNames[i]) # P1E9; strain 87
               col = c(rep("red", lag_phase), rep("black", (49 - lag_phase)) ), main = titleplot) # P3B3; strain 816
          }
          if (slope_point > 0){
            #straight_line = c(Tab$Mean[ (slope_point-2)], (Tab$Mean[ (slope_point-2)] + (Tab$Mean[ (slope_point-2)] + Tab$Mean[ (slope_point+2)])/2)/2,(Tab$Mean[ (slope_point-2)] + Tab$Mean[ (slope_point+2)])/2 , (Tab$Mean[ (slope_point+2)] + (Tab$Mean[ (slope_point-2)] + Tab$Mean[ (slope_point+2)])/2)/2,Tab$Mean[(slope_point + 2)])
            y_values <- c(Tab$Mean[ (slope_point-4)], Tab$Mean[ (slope_point-3)], Tab$Mean[ (slope_point-2)], Tab$Mean[ (slope_point-1)], Tab$Mean[ (slope_point)], Tab$Mean[ (slope_point+1)], Tab$Mean[ (slope_point+2)], Tab$Mean[ (slope_point+3)],Tab$Mean[ (slope_point+4)])
            summed <- sum(y_values)
            #print("SUMMED")
            #print(summed)
            average_y <- summed/9
            #print("Average")
            #print(average_y)
            x_values <- c(slope_point-4, slope_point-3, slope_point-2, slope_point-1, slope_point, slope_point+1, slope_point+2, slope_point+3, slope_point+4)
            #print("X values")
            #print(x_values)
            average_x <- slope_point
            x_change <- c(-4, -3, -2, -1, 0, 1, 2, 3, 4)
            y_change <- c(y_values[1] - average_y, y_values[2] - average_y, y_values[3] - average_y, y_values[4] - average_y, y_values[5] - average_y, y_values[6] - average_y, y_values[7] - average_y, y_values[8] - average_y, y_values[9] - average_y)
            #print("Y change")
            #print(y_change)
            multiplied_xy <- c(y_change[1] * x_change[1], y_change[2] * x_change[2], y_change[3] * x_change[3], y_change[4] * x_change[4], y_change[5] * x_change[5], y_change[6] * x_change[6], y_change[7] * x_change[7], y_change[8] * x_change[8], y_change[9] * x_change[9] )
            summed_XY <- sum(multiplied_xy)
            #print("Summed xy")
            #print(summed_XY)
            multiplied_xx <- c(16, 9, 4, 1, 0, 1, 4, 9, 16)
            summed_xx <- sum(multiplied_xx)
            #print("Summed xx")
            #print(summed_xx)
            sloped <- (summed_XY/summed_xx)   # left as is so its per half-hour
            c_value <- average_y - (average_x * sloped)
            
            ###end with long line
            top <- ((slope_point+4) * sloped) + c_value
            bottom <-  c_value  # at x=0, y=c
            stepwise <- (top-bottom)/(slope_point+4)
            straight_line <- c(bottom)
            for (h in c(1: (slope_point +4))){
              straight_line <- c(straight_line, (bottom + (h*stepwise)))
            }
            #straight_line = c(bottom, bottom + stepwise, bottom + 2*(stepwise), bottom + 3*(stepwise), bottom + 4*(stepwise), bottom + 5*(stepwise), bottom + 6*(stepwise), bottom + 7*(stepwise), top)
            lines(seq(0, 24, by=0.5), c(straight_line, rep(NA, (49-slope_point -5))), lwd =4, col = "green")
            
            
            ### end with short line
            #top <- ((slope_point+4) * sloped) + c_value
            #bottom <- ((slope_point-4) * sloped) + c_value
            #stepwise <- (top-bottom)/8
            #straight_line = c(bottom, bottom + stepwise, bottom + 2*(stepwise), bottom + 3*(stepwise), bottom + 4*(stepwise), bottom + 5*(stepwise), bottom + 6*(stepwise), bottom + 7*(stepwise), top)
            #lines(seq(0, 24, by=0.5), c(rep(NA, (slope_point -5)), straight_line, rep(NA, (49-slope_point -4))), lwd =4, col = "green")
            
            }
        }
        if (For12_14 == TRUE){
          #do nothing
        }
        else{
        arrows(seq(0, 24, by=0.5), Tab$Mean - Tab$STD, seq(0, 24, by=0.5), Tab$Mean + Tab$STD , length=0.05, angle=90, code=3)
        #arrows(c(1:49), Tab$Mean - Tab$STD, c(1:49), Tab$Mean + Tab$STD , length=0.05, angle=90, code=3) # old
        #axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
        }
        
      }
    } }
    cat("Ignore warnings. They're for row names. Still need to fix that")
    if (yesno == TRUE){
      print("potate")
      dev.copy2pdf(file = paste("C:/Users/Jsdsa/Desktop/PhD_stuff/JustControl", Platenumber,".pdf", sep = ''))
    }
  }
  
  #Function ends here.
  ThreePlot(FALSE, FALSE, FALSE, TRUE, TRUE, 45, 6,"D10", "Plot Title")
  
  # ThreePlot <- function(plotted_96, yesno, controlonly, meanSE, logvalues){
  
Tab$OpticalDensity[1:3]
  
  
  Tab$Mean - Tab$STD
  as.numeric(as.character(Tab$Mean)) - as.numeric(as.character(Tab$STD))
  as.numeric(as.character(Tab$Mean)) + as.numeric(as.character(Tab$STD)) 
  

  
  ##Mean with SD error bars method? eh, didnt continue. keep for posterity. just in case
  
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    Tab <- rbind(JustData1[i,], JustData2[i,],JustData3[i,])
    Tab <- t(Tab)
    Tab <- data.frame(Tab)
    for (j in 1:49){
    Tab[j,4] <- (mean(c(Tab[j,1], Tab[j,2], Tab[j,3])))
    Tab[j,5] <- (sd(c(Tab[j,1], Tab[j,2], Tab[j,3])))
    }
    Tab[,6] <- c(1:49)
    colnames(Tab) <- c("Cycle1", "Cycle2", "Cycle3", "Mean","SD", "Cycle")
    plot(Tab$Cycle, Tab$Mean, pch = 16, cex = 1, xlab = "Cycle(30Min)", ylab = "OD + SD", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
    with (
      data = Tab
      , expr = errbar(Tab$Cycle, Tab$Mean, Tab$Mean + Tab$SD, Tab$Mean - Tab$SD, add=T, pch=1, cap=.1)
    )
    axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
  } 
  cat("Ignore warnings. They're for row names. Still need to fix that")
 
  ##Log10 method, with line over. messy. redo as mean. But works, with all 6 reps being done as log10

  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    Tab <- cbind((log10(cbind(JustData1[i,], JustData2[i,],JustData3[i,]))), log10(cbind(JustData4[i,], JustData5[i,],JustData6[i,])))
    Tab <- t(Tab)
    Tab <- data.frame(Tab)
    Tab[,2] <- rep(c(1:49),6)
    Tab[,3] <- rep((c(rep("Red", 49),rep("Blue", 49), rep("Black", 49))),2)
    colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
    plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group, pch = 16, cex = 1, xlab = "Cycle(30Min)", ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
    
    axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
  } 
  cat("Ignore warnings. They're for row names. Still need to fix that")

  
  
  ##Mean semi-log; also not worth it
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    Tab <- rbind(JustData1[i,], JustData2[i,], JustData3[i,])
    Tab <- t(Tab)
    Tab <- data.frame(Tab)
    for (j in 1:49){
      Tab[j,4] <- mean(c(Tab[j,1], Tab[j,2], Tab[j,3]))
      Tab[j,5] <- log10(Tab[j,4])
    }
    
    Tab2 <- c(Tab[,4], Tab[,5])
    Tab2  <- data.frame(Tab2)
    Tab2[,2] <- rep(c(1:49),2)
    Tab2[,3] <- (c(rep("Red", 49),rep("Blue", 49)))
    colnames(Tab2) <- c("OpticalDensity", "Cycle", "Group")
    plot(Tab2$Cycle, Tab2$OpticalDensity, col = Tab2$Group, pch = 16, cex = 1, xlab = "Cycle(30Min)", ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
    
    axis(1,at=c(1:nrow(Tab2)),labels=rownames(Tab2))
  } 
  cat("Ignore warnings. They're for row names. Still need to fix that")
  
  
  #Maybe with Log10? looks slightly better.
  Tempy <- data.frame(log10(t(rbind(JustData1[i,], JustData2[i,], JustData3[i,], JustData4[i,], JustData5[i,], JustData6[i,]))))
  for (i in 1:49){
    Tempy[i,4] <- (sd(c(JustData1[i,], JustData2[i,], JustData3[i,], JustData4[i,], JustData5[i,], JustData6[i,])))
    Tempy[i,5] <- mean(c(JustData1[i,], JustData2[i,], JustData3[i,], JustData4[i,], JustData5[i,], JustData6[i,]))
  }
  Tempy[,6] <- c(1:49)
  colnames(Tempy) <- c("Replicate 1", "Replicate 2", "Replicate 3", "SD", "Mean", "TimePoint")
  
  plot(Tempy$TimePoint, Tempy$Mean, type="n", main = "SD bars for replicates to log10", ylab = "Mean", xlab = "Cycle")
  with (
    data = Tempy
    , expr = errbar(Tempy$TimePoint, Tempy$Mean, Tempy$Mean + Tempy$SD, Tempy$Mean - Tempy$SD, add=T, pch=1, cap=.1)
  )
  
  
  

  ####just 3 (all replicates of a condition.)
  ###
  x11()
  par(mfrow=c(8,12))
  
  par(mar=c(1,1,1,1))
  
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    Tab <- cbind(JustData1[i,], JustData2[i,],JustData3[i,])
    Tab <- t(Tab)
    Tab <- data.frame(Tab)
    Tab[,2] <- rep(c(1:49),3)
    Tab[,3] <- c(rep("FireBrick1", 49),rep("FireBrick2", 49), rep("FireBrick3", 49))
    colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
    plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, cex = 1,xaxt='n', ylim=c(0,3.5) , ylab = "OpticalDensity", main = WellNames[i])  
    

  } 
  cat("Ignore warnings. They're for row names. Still need to fix that")
  dev.copy2pdf(file = "C:/Users/Jsdsa/Desktop/PhD_stuff/JustControl.pdf")
  dev.copy2pdf(file = "C:\\Users\\Joe\\Desktop\\DEPlate_Repliates.pdf")
  
  
  ####ALL 6!!
  ###6 lines; with (blueish) and without furfurals (reddish)
  #sixliner(Do you want printouts as log10? yes =TRUE, do you want plots as a 12*8 matrix? yes= TRUE, do you want pdf prinout? yes= TRUE)
  
  sixliner(TRUE,FALSE, FALSE, FALSE, i)
  
  sixliner <- function(LogOfValues, matrix, pdfout, printall, Platenumber){
  if (matrix == TRUE){
  x11()
  par(mfrow=c(8,12))
  par(mar=c(1,1,1,1))
  
  }
  std <- function(x) sd(x)/sqrt(length(x))
  SteepestSlope1 <- c(1:96)
  SteepestSlope2 <- c(1:96)
  Match1 <- c(1:96)
  Match2 <- c(1:96)
  MaxOD1 <- c(1:96)
  MaxOD2 <- c(1:96)
  Inlfection_Point_Angle <- rep(NA, 96)
  Inlfection_Point_Angle_control <- rep(NA, 96)
  C_scores <- rep(NA, 96)
  
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    if (LogOfValues == TRUE){
      Tab <- log10(cbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData4[i,], JustData5[i,],JustData6[i,]))
      
    }
    else{
      Tab <- cbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData4[i,], JustData5[i,],JustData6[i,])
      
    }
    Tab <- t(Tab)
    Tab <- data.frame(Tab)
    Tab[,2] <- rep(c(1:49),6)
    Tab[,3] <- c(rep("FireBrick1", 49),rep("FireBrick2", 49), rep("FireBrick3", 49),rep("dodgerblue1", 49),rep("dodgerblue2", 49), rep("dodgerblue3", 49))
    colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
   
     ##Extra bit for slope calc.
    if (LogOfValues == TRUE){
      Tab6 <- rbind(log10(JustData1[i,]), log10(JustData2[i,]),log10(JustData3[i,]),log10(JustData4[i,]), log10(JustData5[i,]),log10(JustData6[i,]), c(1:49), c(1:49), c(1:49))
      
    }
   else{
    Tab6 <- rbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData4[i,], JustData5[i,],JustData6[i,], c(1:49), c(1:49), c(1:49))
    } 
    Tab6 <- t(Tab6)
    ##this loop makes average columns (7&8)
    for (k in 1:49){
      Tab6[k,7] <- (Tab6[k,1] + Tab6[k,2] + Tab6[k,3] )/3 # average of log control
      Tab6[k,8] <- (Tab6[k,4] + Tab6[k,5]+ Tab6[k,6] )/3  # average of log furfural
      Tab6[k,9] <- (Tab6[k,4] + Tab6[k,5]+ Tab6[k,6] )/3  # average of furfural
    }
    ##CORRECT FOR BAD DATA POINTS. 
    ##Only changes next point if it's unusualy high; if its a downward trend, it doesnt change values much.
    #plot(1:49, Tab6[,8], main = "Unadjusted Data")
    #for (k in 2:46){
    #  if(Tab6[k,8] < Tab6[k + 1,8] && Tab6[k + 1,8] < Tab6[k + 2,8] && Tab6[k+1,8] > Tab6[k + 3,8] && Tab6[k +2,8] > Tab6[k+3,8] && Tab6[k,8] < Tab6[k +3,8]){
    #    Tab6[k + 1,8] <- ((Tab6[k + 3,8] - Tab6[k,8])*0.333) + Tab6[k,8]
    #    Tab6[k + 2,8] <- ((Tab6[k + 3,8] - Tab6[k,8])*0.666) + Tab6[k,8]
    #  }
    #  if (Tab6[k,8] < Tab6[k + 1,8] && Tab6[k + 1,8] > Tab6[k + 2,8] && Tab6[k,8] < Tab6[k + 2,8] ){
    #  Tab6[k + 1,8] <- (Tab6[k,8] + Tab6[k + 2,8])/2
    #  }
    #  else if (Tab6[k,8] > Tab6[k + 1,8] && Tab6[k + 1,8] < Tab6[k + 2,8] && Tab6[k,8] < Tab6[k + 2,8]){
    #    Tab6[k + 1,8] <- (Tab6[k,8] + Tab6[k + 2,8])/2
    #  }
    #  
    #}
    #plot(1:49, Tab6[,8], main = "Smoothed data for slopes") #see what changes?
    #####
    
    
    Tab8 <- data.frame(c(1:97), c(1:97))
    colnames(Tab8) <- c("AverageFurfural", "IndexValue")
    for (h in c(1:48)){
      Tab8$AverageFurfural[2*h-1] <- (Tab8$AverageFurfural[h])
      Tab8$AverageFurfural[2*h] <- (Tab8$AverageFurfural[h] + Tab8$AverageFurfural[h+1])/2
    }
    Tab8$AverageFurfural[97] <- Tab6[49,8]
    LoData <- loess(Tab8$AverageFurfural~ Tab8$IndexValue, data = Tab8, span= 0.40)
    smoothed10 <- predict(LoData) 
    smoothed10 <- smoothed10[seq(1,97,2)]
    
    lo <- loess(Tab6[,8]~Tab6[,9])
    xl <- seq(min(Tab6[,9]),max(Tab6[,9]), (max(Tab6[,9]) - min(Tab6[,9]))/1000)
    out = predict(lo,xl)
    infl <- c(FALSE, diff(diff(out)>0)!=0)
    
    ##This does 3-point average (46+4 =49)
    Slopes1 <- rep(0, 48)
    Slopes2 <- rep(0, 48)
    Slopes3 <- rep(0, 48)
    c_values <- rep(0, 48)
    for (p in 6:45){
      ##THIS BIT IS NON-FURFURAL
      y_values <- c(Tab6[p-4,7], Tab6[p-3,7], Tab6[p-2,7], Tab6[p-1,7], Tab6[p,7], Tab6[p+1,7], Tab6[p+2,7], Tab6[p+3,7], Tab6[p+4,7])
      differences <- sort(c(abs(y_values[1] -y_values[2]), abs(y_values[2] -y_values[3]), abs(y_values[3] -y_values[4]), abs(y_values[4] -y_values[5]), abs(y_values[5] -y_values[6]), abs(y_values[6] -y_values[7]), abs(y_values[7] -y_values[8]), abs(y_values[8] -y_values[9])))
      if  (round(differences[8], 9) == (round(differences[7],9))){
        differences[7] <- differences[7] * 2
      }
      if (differences[8] > (5*differences[7]) || differences[7] > (5*differences[6])){
        
        Slopes1[p] <- 0
        Slopes2[p] <- 0
        Slopes3[p] <- 0
        c_values[p] <- 0
      }
      else{
        summed <- sum(y_values)
        average_y <- summed/9
        x_values <- c(p-4, p-3, p-2, p-1, p, p+1, p+2, p+3, p+4)
        average_x <- p
        x_change <- c(-4, -3, -2, -1, 0, 1, 2, 3, 4)
        y_change <- c(y_values[1] - average_y, y_values[2] - average_y, y_values[3] - average_y, y_values[4] - average_y, y_values[5] - average_y, y_values[6] - average_y, y_values[7] - average_y, y_values[8] - average_y, y_values[9] - average_y)
        multiplied_xy <- c(y_change[1] * x_change[1], y_change[2] * x_change[2], y_change[3] * x_change[3], y_change[4] * x_change[4], y_change[5] * x_change[5], y_change[6] * x_change[6], y_change[7] * x_change[7], y_change[8] * x_change[8], y_change[9] * x_change[9] )
        summed_XY <- sum(multiplied_xy)
        multiplied_xx <- c(16, 9, 4, 1, 0, 1, 4, 9, 16)
        summed_xx <- sum(multiplied_xx)
        Slopes1[p] <- (summed_XY/summed_xx) * 2  # multiplied by two as this is per half-hour, we want per-hour
        
        #c_values[p] <- average_y - (average_x * Slopes1[p])
      }
      
      
      #print("*****")
      y_values <- c(Tab6[p-4,8], Tab6[p-3,8], Tab6[p-2,8], Tab6[p-1,8], Tab6[p,8], Tab6[p+1,8], Tab6[p+2,8], Tab6[p+3,8], Tab6[p+4,8])
      differences <- sort(c(abs(y_values[1] -y_values[2]), abs(y_values[2] -y_values[3]), abs(y_values[3] -y_values[4]), abs(y_values[4] -y_values[5]), abs(y_values[5] -y_values[6]), abs(y_values[6] -y_values[7]), abs(y_values[7] -y_values[8]), abs(y_values[8] -y_values[9])))
      if  (round(differences[8], 9) == (round(differences[7],9))){
        differences[7] <- differences[7] * 2
      }
      if (differences[8] > (5*differences[7]) || differences[7] > (5*differences[6])){
        
        Slopes1[p] <- 0
        Slopes2[p] <- 0
        Slopes3[p] <- 0
        c_values[p] <- 0
      }
      else{
      summed <- sum(y_values)
      average_y <- summed/9
      x_values <- c(p-4, p-3, p-2, p-1, p, p+1, p+2, p+3, p+4)
      average_x <- p
      x_change <- c(-4, -3, -2, -1, 0, 1, 2, 3, 4)
      y_change <- c(y_values[1] - average_y, y_values[2] - average_y, y_values[3] - average_y, y_values[4] - average_y, y_values[5] - average_y, y_values[6] - average_y, y_values[7] - average_y, y_values[8] - average_y, y_values[9] - average_y)
      multiplied_xy <- c(y_change[1] * x_change[1], y_change[2] * x_change[2], y_change[3] * x_change[3], y_change[4] * x_change[4], y_change[5] * x_change[5], y_change[6] * x_change[6], y_change[7] * x_change[7], y_change[8] * x_change[8], y_change[9] * x_change[9] )
      summed_XY <- sum(multiplied_xy)
      multiplied_xx <- c(16, 9, 4, 1, 0, 1, 4, 9, 16)
      summed_xx <- sum(multiplied_xx)
      Slopes2[p] <- (summed_XY/summed_xx) * 2  # multiplied by two as this is per half-hour, we want per-hour
      Slopes3[p] <- (summed_XY/summed_xx) * 2
      c_values[p] <- average_y - (average_x * Slopes1[p])
      }
      #print("slope")
      #print((summed_XY/summed_xx) * 2)
      
      #if ( differences[4] > 3*(differences[2]) ){  # ignore anaomalous 
        #print(differences)
        #Slopes2[p] <- ((Tab6[p+2,8]-Tab6[p-2,8])/4)*2  # five-point slope from Tom's idea ; /4 for 5 time-points, *2 for per hour calculation
        #Slopes3[p] <- ((Tab6[p+2,8]-Tab6[p-2,8])/4)*2   # inflection needs small slope changes for best results 
        #Slopes2[p] <- 0
      #}
      #else{
        #Slopes2[p] <- ((Tab6[p+2,8]-Tab6[p-2,8])/4)*2  # five-point slope from Tom's idea ; /4 for 5 time-points, *2 for per hour calculation
        #Slopes2[p] <- (summed)/2
        #Slopes3[p] <- ((Tab6[p+2,8]-Tab6[p-2,8])/4)*2   # inflection needs small slope changes for best results    
      #}
      #Slopes1[p] <- ((Tab6[p+1,7]-Tab6[p-1,7])/2)
      #Slopes2[p] <- ((Tab6[p+1,8]-Tab6[p-1,8])/2)  # old (3-point slope, use if Tom's 5-point doesnt work out) 
         
      
    }
    
    #plot(1:48, Slopes3, main = "Slopes")
    start_OD_furfural <- (Tab6[2,8] + Tab6[3,8] + Tab6[4,8])/3 # first point is often bad; ignore it
    start_OD_control <- (Tab6[2,7] + Tab6[3,7] + Tab6[4,7])/3 # first point is often bad; ignore it
    
    angles <- rep(0, 40)   
    for (slope in 4:40){  # 46+next 2 points check == 48
      if (Tab6[slope+1, 8] > Tab6[slope,8] && Tab6[slope+2,8]> Tab6[slope+1,8] && Tab6[slope-2, 8] < Tab6[slope+2,8]){  # old version (check next two points for increase)
        
        
        angles[slope] <- abs(atan(abs((Slopes3[slope-2] - Slopes3[slope + 2])/(1 + (Slopes3[slope-2] * Slopes3[slope + 2])))))
        #angles[slope] <- abs(atan(abs((((Slopes3[slope - 1] + Slopes3[slope - 2])/2) - Slopes3[slope +1])/(1 + (Slopes3[slope+1] * ((Slopes3[slope - 1] + Slopes3[slope - 2])/2))))))
        
        
        }
    }
    angles_a <- angles
    for (pop in c(4: 39)){
      angles_a[pop] <- (angles[pop] + angles[pop+1])/2
    }
    
    largest_angle = sort(angles_a)[40]
    Inlfection_Point_Angle[i] <- match(largest_angle, angles_a)
    #plot(1:46, angles, main = "Gradient swap")
    ## Original!!
    #angles1 <- sort(angles)
    #Inlfection_Point_Angle[i] <- match(c(angles1[46]),angles)
    #if (angles1[46] == 0){
    #  Inlfection_Point_Angle[i] <- 48
    #}
    
    ## TOMS:
    
    
    point_of_highest_slope <- match(c(sort(Slopes2)[48]),Slopes2)
    per_half_hour <- (sort(Slopes2)[48])/2  # dont convert
    #per_half_hour <- (sort(Slopes2)[48])/2  # convert back to half-hour
    Inlfection_Point_Angle[i] <- point_of_highest_slope - abs(round((Tab6[point_of_highest_slope,8] - start_OD_furfural)/(per_half_hour)))
    if (Inlfection_Point_Angle[i] < 1){
      Inlfection_Point_Angle[i] <- 1
    }
    
    point_of_highest_slope <- match(c(sort(Slopes1)[48]),Slopes1)
    per_half_hour <- (sort(Slopes1)[48])/2  # dont convert
    #per_half_hour <- (sort(Slopes2)[48])/2  # convert back to half-hour
    Inlfection_Point_Angle_control[i] <- point_of_highest_slope - abs(round((Tab6[point_of_highest_slope,7] - start_OD_control)/(per_half_hour)))
    if (Inlfection_Point_Angle_control[i] < 1){
      Inlfection_Point_Angle_control[i] <- 1
    }
    
    
    
    #Inlfection_Point_Angle[i] <- sort(Slopes2)[48]
    C_scores[i] <- c_values[point_of_highest_slope]
    
    
    #print("****")
    #print(Slopes2) #correct.
    #print(point_of_highest_slope)
    #print(start_OD)
    #print(Tab6[point_of_highest_slope,8])
    #print(Inlfection_Point_Angle[i])
    ##end toms
    
    
    
    
    MaxOD1[i] <- Tab6[49,7]
    MaxOD2[i] <- Tab6[49,8]
    Slopes3 <- sort(Slopes1)
    Slopes4 <- sort(Slopes2)
    Match1[i] <- match(c(Slopes3[48]),Slopes1)
    Match2[i] <- match(c(Slopes4[48]),Slopes2) ##this is the literal point of steepest slope (middle line)
    
    #start_slope = (((Tab6[3,8]+Tab6[4,8]+Tab6[5,8])/3)-Tab6[3,8])
    #print(InfPoints[i])
    #print(Match2[i]-3)
    #print("***")
    #InfPoints[i] <- (Match2[i]- 3)/(start_slope- Slopes4[47])
    #find intersection of slope at point 3 and one at steepest point; doesnt work as many intersect at >|100|
    
    SteepestSlope1[i] <- Slopes3[48]
    SteepestSlope2[i] <- Slopes4[48]
    
    #####
    if (LogOfValues == TRUE && printall == TRUE){
      plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=c(-1,1) , ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
      legend("topleft", legend=c(signif(Slopes3[48], digits = 3), signif(Slopes4[48], digits = 3)), col=c("red", "blue"), cex = 1, x.intersp = 0.1,y.intersp = 0.7)
      
      ##axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
      axis(2, 0:3)
      points(xl[infl ], out[infl ], col="black")
      lines(xl, out, col='red', lwd=2)
    }
    else{
      plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=c(-3,3) , ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
      legend("topleft", legend=c(signif(Slopes3[48], digits = 3), signif(Slopes4[48], digits = 3)), col=c("red", "blue"), cex = 1, x.intersp = 0.1,y.intersp = 0.7)
      
      ##axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
      axis(2, 0:3)
      points(xl[infl ], out[infl ], col="black")
      lines(xl, out, col='red', lwd=2)  
    }
   
  } 
  #MainFrame <- data.frame(SteepestSlope1, Match1,MaxOD1, SteepestSlope2, Match2, MaxOD2, InfPoints)
  MainFrame <- data.frame(SteepestSlope1, Match1,MaxOD1,Inlfection_Point_Angle_control, SteepestSlope2, Match2, MaxOD2, Inlfection_Point_Angle, C_scores)
  colnames(MainFrame) <- c("Highest Slope control", "Timepoint Control", "Max OD control", "Rough Inflection Control", "Highest Slope furfural", "Timepoint furfural", "Max OD furfural", "Rough Inflection Point", "C_Value")
  rownames(MainFrame) <- WellNames
  if (LogOfValues == TRUE){
    write.csv(MainFrame, file = paste("Plate", Platenumber, "SlopeResults", LogGrowth,".csv", sep = ''))
  }
  else{
  write.csv(MainFrame, file = paste("Plate", Platenumber, "SlopeResults.csv", sep = ''))
  }
  sum(SteepestSlope1)/96
  sum(SteepestSlope2)/96
  cat("Ignore warnings. They're for row names. Still need to fix that")
  if (pdfout == TRUE){
  dev.copy2pdf(file = paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Plate", Platenumber, "WithAndWithout.pdf", sep=''))
  }
  }
  #function ends here
  
  i <-1
  i <-"DE"
  sixliner(TRUE,FALSE, FALSE,FALSE, i)
  
  

  ####ALL 6!!
  ###6 lines; with (blueish) and without furfurals (reddish)
  #sixliner(Do you want printouts as log10? yes =TRUE, do you want plots as a 12*8 matrix? yes= TRUE, do you want pdf prinout? yes= TRUE)
  
  sixlinerKai(FALSE,TRUE, TRUE, 1)
  
  sixlinerKai <- function(LogOfValues, matrix, pdfout, Platenumber){
    
    if (matrix == TRUE){
      x11()
      par(mfrow=c(8,12))
      par(mar=c(1,1,1,1))
      
    }
    SteepestSlope1 <- c(1:96)
    SteepestSlope2 <- c(1:96)
    Match1 <- c(1:96)
    Match2 <- c(1:96)
    MaxOD1 <- c(1:96)
    MaxOD2 <- c(1:96)
    Max_SD <- c(1:96)
    InfPoints <- rep(NA, 96)
    Inlfection_Point_Angle <- rep(NA, 96)
    
    
    WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
    for (i in 1:96){
      if (LogOfValues == TRUE){
        Tab <- log10(cbind(JustData1[i,], JustData2[i,],JustData3[i,]))
        
      }
      else{
        Tab <- cbind(JustData1[i,], JustData2[i,],JustData3[i,])
        
      }
      Tab <- t(Tab)
      Tab <- data.frame(Tab)
      Tab[,2] <- rep(c(1:97),3)
      Tab[,3] <- c(rep("FireBrick1", 97),rep("FireBrick2", 97), rep("FireBrick3", 97))
      colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
      
      
      ##Extra bit for slope calc.
      
      Tab6 <- rbind(JustData1[i,], JustData2[i,],JustData3[i,], c(1:97), c(1:97))  # columns for each OD + empty for average, one for SD
        
      
      Tab6 <- t(Tab6)
      ##this loop makes average columns (7&8)
      for (k in 1:97){
        Tab6[k,4] <- (Tab6[k,1] + Tab6[k,2] + Tab6[k,3] )/3  # average in column 4
        Tab6[k,5] <- sd(c(Tab6[k,1], Tab6[k,2], Tab6[k,3]))  # SD in column 5
        #print(Tab6[k,5])
      }
      
      
      
      
      ##This does 3-point average (46+4 =49)
      Slopes1 <- rep(0, 96)
      Slopes2 <- rep(0, 96)
      for (p in 2:96){
        #print(Tab6[p+1,8])
        #print(Tab6[p-1,8])
        #print("*****")
        Slopes1[p] <- ((Tab6[p+1,4]-Tab6[p-1,4])/2)
        Slopes2[p] <- ((Tab6[p+1,4]-Tab6[p-1,4])/2) 
        #old
        # Slopes2[p] <- (((Tab6[p+1,8]+Tab6[p+2,8]+Tab6[p+3,8])/3)-Tab6[p,8])/1.5
      }
      
      angles <- rep(0, 94)  
      for (slope in 2:94){  # 46+next 2 points check == 48
        #print(Slopes2[slope+2])
        #print(Slopes2[slope+1])
        #print(Slopes2[slope])
        
        if (Slopes2[slope+1] > Slopes2[slope] && Slopes2[slope+2]> Slopes2[slope+1]){  # old version (check next two points for increase)
          #TOM: change to increase at next TWO points. same data? if 0 => 48 (top cluster)
          #if (Slopes2[slope+1] > Slopes2[slope] && Slopes2[slope+2]> Slopes2[slope+1] && Slopes2[slope+3]> Slopes2[slope+2]){  # new; cehck next 3 points.
          angles[slope] <- atan((Slopes2[slope] + Slopes2[slope + 2])/(1 + (Slopes2[slope] * Slopes2[slope + 2])))
        }
        #angles[slope] <- atan((Slopes2[slope] + Slopes2[slope + 1])/(1 + (Slopes2[slope] * Slopes2[slope + 1])))
        #angles[slope] <- abs(tan((Slopes2[slope] + Slopes2[slope + 1])/(1 + (Slopes2[slope] * Slopes2[slope + 1])))) #abs count decrease inflection? so ignore.
      }
      
      angles1 <- sort(angles)
      Inlfection_Point_Angle[i] <- match(c(angles1[94]),angles)
      if (angles1[94] == 0){
        Inlfection_Point_Angle[i] <- 96
      }
      #print(angles1[45])
      #print(Inlfection_Point_Angle[i])
      #print(angles1)
      
      MaxOD1[i] <- Tab6[97,4]
      Max_SD[i] <- Tab6[97,5]
      Slopes3 <- sort(Slopes1)
      Match1[i] <- match(c(Slopes3[96]),Slopes1)
      ##Find OD of point representing highest slope. remove lowest point of graph. 
      ##then,divide number by slope; find timepoint for when inflection roughly started for fast growth. 
      
      #start_slope = (((Tab6[3,8]+Tab6[4,8]+Tab6[5,8])/3)-Tab6[3,8])
      #print(InfPoints[i])
      #print(Match2[i]-3)
      #print("***")
      #InfPoints[i] <- (Match2[i]- 3)/(start_slope- Slopes4[47])
      #find intersection of slope at point 3 and one at steepest point; doesnt work as many intersect at >|100|
      
      SteepestSlope1[i] <- Slopes3[96]
      
      #####
      if (LogOfValues == TRUE){
        plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=c(-1,1) , ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
        
      }
      else{
        #plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=c(0,3) , ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
        plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=c(0,5) ,  main = paste(WellNames[i], sep = ' '))  
        
      }
      #legend("topleft", legend=c(signif(Slopes3[96], digits = 3), signif(Slopes4[96], digits = 3)), col=c("red", "blue"), cex = 1, x.intersp = 0.1,y.intersp = 0.7)
      
      ##axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
      #axis(2, 0:3)
      
    } 
    #MainFrame <- data.frame(SteepestSlope1, Match1,MaxOD1, SteepestSlope2, Match2, MaxOD2, InfPoints)
    MainFrame <- data.frame(SteepestSlope1, Match1,MaxOD1, Max_SD)
    colnames(MainFrame) <- c("Highest Slope", "Timepoint", "Max OD", "MaxOD_SD")
    rownames(MainFrame) <- WellNames
    if (LogOfValues == TRUE){
      write.csv(MainFrame, file = paste("Plate", Platenumber, "_KAI_Data.csv", sep = ''))
    }
    else{
      write.csv(MainFrame, file = paste("Plate", Platenumber, "_logKAI_Data.csv", sep = ''))
    }
    sum(SteepestSlope1)/96
    sum(SteepestSlope2)/96
    cat("Ignore warnings. They're for row names. Still need to fix that")
    if (pdfout == TRUE){
      dev.copy2pdf(file = paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Plate", Platenumber, "_KAI.pdf", sep=''))
    }
    
    }
  #function ends here
  
    sixlinerKai(FALSE,FALSE, TRUE, 1)
  #######
  
    
  ##all 6 just for report
  x11()
  par(mfrow=c(8,12))
  
  #par(mar=c(2,2,2,2))
  par(mar=c(1,1,1,1))
  SteepestSlope1 <- c(1:96)
  SteepestSlope2 <- c(1:96)
  Match1 <- c(1:96)
  Match2 <- c(1:96)
  
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    Tab <- cbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData4[i,], JustData5[i,],JustData6[i,])
    Tab <- (t(Tab))
    Tab <- data.frame(Tab)
    Tab[,2] <- rep(c(1:49),6)
    Tab[,3] <- c(rep("FireBrick1", 49),rep("FireBrick2", 49), rep("FireBrick3", 49),rep("dodgerblue1", 49),rep("dodgerblue2", 49), rep("dodgerblue3", 49))
    colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
    
    #####
    #plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, ,  cex = 1, ylim=c(0,3) , ylab = "OpticalDensity", main = paste("Well", WellNames[i], sep = ' '))  
    plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, ,  cex = 1, xaxt = "n", yaxt = "n", ylab = "OpticalDensity", main = paste("Well", WellNames[i], sep = ' '))  
    
    if (i== 85){
      
      axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
      axis(2)
    }
  } 
  par(new=F)
  plot(xaxt = c(1:12), yaxt = c("A", "B", "C", "D", "E", "F", "G", "H"), ylab = "OpticalDensity", main = paste("Well", WellNames[i], sep = ' '))  
  cat("Ignore warnings. They're for row names. Still need to fix that")
  dev.copy2pdf(file = "C:\\Users\\Joe\\Desktop\\PhD_stuff\\Plate1WithAndWithout.pdf")
  
  ###############################################################################
  ##Just 1 well for testing####
  #first, load data
  FileName1 <- "ZYGO_TEST_F-top_vs_M-bottom.csv"
  MainFile1 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\", FileName1, sep = ''))
  JustData1 <- MainFile1[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
  #### Next, run thingy
  
  x11()
  par(mfrow=c(8,12))
  
  par(mar=c(1,1,1,1))
  SteepestSlope1 <- c(1:96)
  SteepestSlope2 <- c(1:96)
  Match1 <- c(1:96)
  Match2 <- c(1:96)
  
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    Tab <- cbind(JustData1[i,])
    Tab <- (t(Tab))
    Tab <- data.frame(Tab)
    Tab[,2] <- rep(c(1:49))
    Tab[,3] <- rep("FireBrick1", 49)
    colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
    #####
    plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, ,  cex = 1, ylim=c(0,3) , ylab = "OpticalDensity", main = paste("Well", WellNames[i], sep = ' '))  
    
    if (i== 85){
      
      axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
      axis(2)
    }
  } 
  
  cat("Ignore warnings. They're for row names. Still need to fix that")
  dev.copy2pdf(file = "C:\\Users\\Joe\\Desktop\\PhD_stuff\\Plate1WithAndWithout.pdf")
  

  
  ####Below is orig. slope calc
  Tab6 <- rbind(JustData1[4,], JustData2[4,],JustData3[4,],JustData4[4,], JustData5[4,],JustData6[4,], c(1:49), c(1:49), c(1:49))
  Tab6 <- (t(Tab6))

  for (k in 1:49){
    Tab6[k,7] <- (Tab6[k,1] + Tab6[k,2] + Tab6[k,3] )/3
    Tab6[k,8] <- (Tab6[k,4] + Tab6[k,5]+ Tab6[k,6] )/3
  }
  Tab7 <- data.frame(Tab6)
  colnames(Tab7) <- c("AvControl1", "AvControl2", "AvControl3", "AcFurfural1", "AvFurfural2", "AvFurfural3", "AverageControl", "AverageFurfural", "Index")
  A<-findiplist(Tab7$AverageFurfural, Tab7$Index,0)
  print(A[5])
  Pizza = 1
  for (i in Tab7$AverageFurfural){
    Pie = i- A[5]
    if (abs(Pie) < Pizza){
      Pizza = Pie
    }
  }
  LagValue <- Pizza
  
  Slopes1 <- c(1:46)
  Slopes2 <- c(1:46)
  for (p in 1:46){
    Slopes1[p] <- (((Tab6[p+1,7]+Tab6[p+2,7]+Tab6[p+3,7])/3)-Tab6[p,7])/1.5
    Slopes2[p] <- (((Tab6[p+1,8]+Tab6[p+2,8]+Tab6[p+3,8])/3)-Tab6[p,8])/1.5
  }
  Slopes3 <- sort(Slopes1)
  Slopes4 <- sort(Slopes2)
  SteepestSlope1 <- Slopes3[46]
  SteepestSlope2 <- Slopes4[46]
  signif(SteepestSlope1, digits = 3)
  signif(SteepestSlope2, digits = 3)
  
  viewer <- data.frame(Slopes1, Slopes2, c(1:46))
plot(viewer$c.1.46., viewer$Slopes2, ylab = "Slope steepness", xlab = "timepoint")



  ##All 9- test

  
  x11()
  par(mfrow=c(8,12))
  
  par(mar=c(1,1,1,1))
  
  ###6 Colours; with (blueish) and without furfurals (reddish)
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    Tab <- cbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData4[i,], JustData5[i,], JustData6[i,],JustData7[i,], JustData8[i,], JustData9[i,])
    Tab <- t(Tab)
    Tab <- data.frame(Tab)
    Tab[,2] <- rep(c(1:49),9)
    Tab[,3] <- c(rep("FireBrick1", 49),rep("FireBrick2", 49), rep("FireBrick3", 49),rep("dodgerblue1", 49),rep("dodgerblue2", 49), rep("dodgerblue3", 49), rep("black", 49), rep("black", 49), rep("black", 49))
    colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
    plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group, pch = 16, cex = 1, xlab = "Cycle(30Min)", ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
    
    axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
  } 
  cat("Ignore warnings. They're for row names. Still need to fix that")
  dev.copy2pdf(file = "C:/Users/Jsdsa/Desktop/PhD_stuff/Plate3F25R3.pdf")

  
  