pscp shepherd@n85716://home/joShare/Joseph/StrainData/Plate_1/freebayes_output/* C:\Users\Joseph\Desktop\PhD_stuff\Jo_Stuff\Programs_for_joShare\Plate1VCF_CIGAR\
password!
pscp shepherd@n85716://home/joShare/Joseph/StrainData/Plate_2/freebayes_output/* C:\Users\Joseph\Desktop\PhD_stuff\Jo_Stuff\Programs_for_joShare\Plate2VCF_CIGAR\
password!
pscp shepherd@n85716://home/joShare/Joseph/StrainData/Plate_3/freebayes_output/* C:\Users\Joseph\Desktop\PhD_stuff\Jo_Stuff\Programs_for_joShare\Plate3VCF_CIGAR\
password!
pscp shepherd@n85716://home/joShare/Joseph/StrainData/Plate_4/freebayes_output/* C:\Users\Joseph\Desktop\PhD_stuff\Jo_Stuff\Programs_for_joShare\Plate4VCF_CIGAR\
password!
pscp shepherd@n85716://home/joShare/Joseph/StrainData/Plate_5/freebayes_output/* C:\Users\Joseph\Desktop\PhD_stuff\Jo_Stuff\Programs_for_joShare\Plate5VCF_CIGAR\
password!
pscp shepherd@n85716://home/joShare/Joseph/StrainData/Plate_6/freebayes_output/* C:\Users\Joseph\Desktop\PhD_stuff\Jo_Stuff\Programs_for_joShare\Plate6VCF_CIGAR\
password!
pscp shepherd@n85716://home/joShare/Joseph/StrainData/Plate_7/freebayes_output/* C:\Users\Joseph\Desktop\PhD_stuff\Jo_Stuff\Programs_for_joShare\Plate7VCF_CIGAR\
password!