#!/bin/bash
echo Conservative variant calling from Saccharomyces cerevisiae reads against the artificial 1,011 pangenome

##### EDIT THIS ARRAY AND INDEX BELOW TO CONTAIN/INCLUDE STRAINS UNDERGOING ANALYSIS

AllStrains=(356 357 358 430 463 478 479 482 619 620 621 671 672 684 816 1406 1407 1408 1409 1410 1411 1412 1413 1414 1415 1431 2401 2402 2517 2587 2683 2688 2695 2804 2808 2809 2855 2947 2948 489 490 491 525 694 995 996 1529 1530 1765 3020 3021 3022 238 241 341 911 1384 1510 3267 3431 100 111 143 151 152 179 188 243 244 350 426 587 744 827 851 906 970 1424 1425 1426 1429 1441 2265 2559 2597 2675 2886 2887 2907 3104 3303 3344 3396 3502 3519 3537)

plate_number="5"
sequencing_plate="Eurofins" # could be Eurofins

for index in $(seq 0 95);

do 

mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/freebayes_output/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}


/home/joShare/Joseph/programs/bwa/bwa mem /home/joShare/Joseph/programs/allORFs_pangenome.fasta /home/joShare/${sequencing_plate}_Plate_${plate_number}/Deduplicated_and_trimmed_reads/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_forward_paired.fastq /home/joShare/${sequencing_plate}_Plate_${plate_number}/Deduplicated_and_trimmed_reads/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_reverse_paired.fastq > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}.sam


samtools view -h -F 4 /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped.sam


##### STEP 3: Remove soft and hard clippings
##### This step removes reads that only partially mapped to the reference

samclip --ref /home/joShare/Joseph/programs/allORFs_pangenome.fasta --max 0 /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam


##### STEP 4: FAT-CIGAR filtering
##### This is Prithika's tool, which keeps only those reads which exactly match to the reference sequence at both ends
##### Her recent version does this all in one line but as the tool is in flux I'll send you this stable older version where we do things in several lines
#for testing


samtools view -H /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_header.sam

samtools view -bS /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_PRE.bam

python cigarv2.py /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_PRE.bam /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.bam

samtools view -h /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.bam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.sam

samtools view /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.sam | awk '($6 ~ /^[1-9][0-9]=.*[1-9][0-9]=$/) || ($6 ~ /^[1-9][0-9]=.*[1-2][0-9][0-9]=$/) || ($6 ~ /^[1-2][0-9][0-9]=.*[1-9][0-9]=$/) || ($6 ~ /^[5-9][0-9]=$/) || ($6 ~ /^[1-2][0-9][0-9]=$/)' > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.sam

cat /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_header.sam /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered2.sam

samtools view -bS /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered2.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.bam


##### STEP 5: Variant calling
##### The only filter here is on the quality of the base call, the default frequency filter of 0.2 will apply (i.e. a variant has to seen in at least a fifth of reads for it to be called)

freebayes --min-base-quality 30 -f /home/joShare/Joseph/programs/allORFs_pangenome.fasta /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.bam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial.vcf


##### STEP 6: Variant splitting
##### This uses the vcflib tools and breaks down any complex variants in the vcf file into simpler variants
##### We tried loads of ways to do this task, the recipe below performed the best

vcfbreakmulti /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial2.vcf

vcfallelicprimitives -kg /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial2.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial3.vcf

vcfstreamsort /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial3.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial4.vcf

vcfuniq /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial4.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial5.vcf


##### STEP 7: Variant filtering
##### This again uses vcflib and filters here on read depth (>= 30) and variant type (i.e. SNPs only)

vcffilter -f "DP > 29 & TYPE = snp" /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial5.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/freebayes_output/NCYC${AllStrains[index]}_freebayes_SNP_genome.vcf


done
