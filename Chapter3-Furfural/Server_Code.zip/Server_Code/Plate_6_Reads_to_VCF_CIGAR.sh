#!/bin/bash
echo Conservative variant calling from Saccharomyces cerevisiae reads against the artificial 1,011 pangenome

##### EDIT THIS ARRAY AND INDEX BELOW TO CONTAIN/INCLUDE STRAINS UNDERGOING ANALYSIS

AllStrains=(128 171 385 417 464 469 548 551 563 570 571 573 575 580 609 752 776 807 929 935 1315 1368 1400 1427 1474 1477 1496 1497 1498 1515 1520 1521 1548 1553 1554 1555 1556 1557 1558 1572 1573 1591 1592 1656 1673 1766 2258 2307 2693 2742 2775 2790 2797 2897 2898 2927 2931 2932 2933 2934 2935 2956 2980 2981 2995 3000 3001 3034 3041 3053 3090 3091 3092 3134 3146 3298 3302 3307 3354 3358 3378 3379 3407 3410 3414 3557 3562 3716 3724 3776 3961 3963 3964 3966 3968 4020)

plate_number="6"
sequencing_plate="Eurofins" # could be Eurofins

for index in $(seq 0 95);

do 

mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/freebayes_output/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}


/home/joShare/Joseph/programs/bwa/bwa mem /home/joShare/Joseph/programs/allORFs_pangenome.fasta /home/joShare/${sequencing_plate}_Plate_${plate_number}/Deduplicated_and_trimmed_reads/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_forward_paired.fastq /home/joShare/${sequencing_plate}_Plate_${plate_number}/Deduplicated_and_trimmed_reads/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_reverse_paired.fastq > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}.sam


samtools view -h -F 4 /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped.sam


##### STEP 3: Remove soft and hard clippings
##### This step removes reads that only partially mapped to the reference

samclip --ref /home/joShare/Joseph/programs/allORFs_pangenome.fasta --max 0 /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam


##### STEP 4: FAT-CIGAR filtering
##### This is Prithika's tool, which keeps only those reads which exactly match to the reference sequence at both ends
##### Her recent version does this all in one line but as the tool is in flux I'll send you this stable older version where we do things in several lines
#for testing


samtools view -H /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_header.sam

samtools view -bS /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_PRE.bam

python cigarv2.py /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_PRE.bam /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.bam

samtools view -h /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.bam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.sam

samtools view /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.sam | awk '($6 ~ /^[1-9][0-9]=.*[1-9][0-9]=$/) || ($6 ~ /^[1-9][0-9]=.*[1-2][0-9][0-9]=$/) || ($6 ~ /^[1-2][0-9][0-9]=.*[1-9][0-9]=$/) || ($6 ~ /^[5-9][0-9]=$/) || ($6 ~ /^[1-2][0-9][0-9]=$/)' > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.sam

cat /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_header.sam /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered2.sam

samtools view -bS /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered2.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.bam


##### STEP 5: Variant calling
##### The only filter here is on the quality of the base call, the default frequency filter of 0.2 will apply (i.e. a variant has to seen in at least a fifth of reads for it to be called)

freebayes --min-base-quality 30 -f /home/joShare/Joseph/programs/allORFs_pangenome.fasta /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.bam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial.vcf


##### STEP 6: Variant splitting
##### This uses the vcflib tools and breaks down any complex variants in the vcf file into simpler variants
##### We tried loads of ways to do this task, the recipe below performed the best

vcfbreakmulti /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial2.vcf

vcfallelicprimitives -kg /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial2.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial3.vcf

vcfstreamsort /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial3.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial4.vcf

vcfuniq /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial4.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial5.vcf


##### STEP 7: Variant filtering
##### This again uses vcflib and filters here on read depth (>= 30) and variant type (i.e. SNPs only)

vcffilter -f "DP > 29 & TYPE = snp" /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial5.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/freebayes_output/NCYC${AllStrains[index]}_freebayes_SNP_genome.vcf


done
