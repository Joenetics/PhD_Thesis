#!/bin/bash


echo "Plate $1, strain $2, plate type $3 Started." >> Cigar_Proof_of_Run.txt
mkdir -p /home/joShare/Joseph/StrainData/Plate_$1/BWA_alignments/
mkdir -p /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/
mkdir -p /home/joShare/Joseph/StrainData/Plate_$1/freebayes_output/
mkdir -p /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2
mkdir -p /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/VCF_bit

/home/joShare/Joseph/programs/bwa/bwa mem /home/joShare/Joseph/programs/allORFs_pangenome.fasta /home/joShare/$3_Plate_$1/Deduplicated_and_trimmed_reads/NCYC$2/NCYC$2_forward_paired.fastq /home/joShare/$3_Plate_$1/Deduplicated_and_trimmed_reads/NCYC$2/NCYC$2_reverse_paired.fastq > /home/joShare/Joseph/StrainData/Plate_$1/BWA_alignments/NCYC$2.sam


samtools view -h -F 4 /home/joShare/Joseph/StrainData/Plate_$1/BWA_alignments/NCYC$2.sam > /home/joShare/Joseph/StrainData/Plate_$1/BWA_alignments/NCYC$2_mapped.sam


##### STEP 3: Remove soft and hard clippings
##### This step removes reads that only partially mapped to the reference

samclip --ref /home/joShare/Joseph/programs/allORFs_pangenome.fasta --max 0 /home/joShare/Joseph/StrainData/Plate_$1/BWA_alignments/NCYC$2_mapped.sam > /home/joShare/Joseph/StrainData/Plate_$1/BWA_alignments/NCYC$2_mapped_samclipped.sam


##### STEP 4: FAT-CIGAR filtering
##### This is Prithika's tool, which keeps only those reads which exactly match to the reference sequence at both ends
##### Her recent version does this all in one line but as the tool is in flux I'll send you this stable older version where we do things in several lines
#for testing

#/home/joShare/Joseph/programs/bwa/bwa mem /home/joShare/Joseph/programs/allORFs_pangenome.fasta /home/joShare/TGAC_Plate_1/Deduplicated_and_trimmed_reads/NCYC68/NCYC68_forward_paired.fastq /home/joShare/TGAC_Plate_1/Deduplicated_and_trimmed_reads/NCYC68/NCYC68_reverse_paired.fastq > /home/joShare/Joseph/StrainData/Plate_1/BWA_alignments/NCYC68.sam
#samtools view -h -F 4 /home/joShare/Joseph/StrainData/Plate_1/BWA_alignments/NCYC68.sam > /home/joShare/Joseph/StrainData/Plate_1/BWA_alignments/NCYC68_mapped.sam
#samclip --ref /home/joShare/Joseph/programs/allORFs_pangenome.fasta --max 0 /home/joShare/Joseph/StrainData/Plate_1/BWA_alignments/NCYC68_mapped.sam > /home/joShare/Joseph/StrainData/Plate_1/BWA_alignments/NCYC68_mapped_samclipped.sam
#samtools view -H /home/joShare/Joseph/StrainData/Plate_1/BWA_alignments/NCYC68_mapped_samclipped.sam > /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_header.sam
#samtools view -bS /home/joShare/Joseph/StrainData/Plate_1/BWA_alignments/NCYC68_mapped_samclipped.sam > /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_PRE.bam
#python cigarv2.py /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_PRE.bam /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_cigar.bam
#samtools view -h /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_cigar.bam > /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_cigar.sam
#samtools view /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_cigar.sam | awk '($6 ~ /^[1-9][0-9]=.*[1-9][0-9]=$/) || ($6 ~ /^[1-9][0-9]=.*[1-2][0-9][0-9]=$/) || ($6 ~ /^[1-2][0-9][0-9]=.*[1-9][0-9]=$/) || ($6 ~ /^[5-9][0-9]=$/) || ($6 ~ /^[1-2][0-9][0-9]=$/)' > /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_cigar_filtered.sam
#cat /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_header.sam /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_cigar_filtered.sam > /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_cigar_filtered2.sam
#samtools view -bS /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_cigar_filtered2.sam > /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_cigar_filtered.bam
#freebayes --min-base-quality 30 -f /home/joShare/Joseph/programs/allORFs_pangenome.fasta /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_cigar_filtered.bam > /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_initial.vcf


samtools view -H /home/joShare/Joseph/StrainData/Plate_$1/BWA_alignments/NCYC$2_mapped_samclipped.sam > /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_header.sam

samtools view -bS /home/joShare/Joseph/StrainData/Plate_$1/BWA_alignments/NCYC$2_mapped_samclipped.sam > /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_PRE.bam

python cigarv2.py /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_PRE.bam /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_cigar.bam

samtools view -h /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_cigar.bam > /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_cigar.sam

samtools view /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_cigar.sam | awk '($6 ~ /^[1-9][0-9]=.*[1-9][0-9]=$/) || ($6 ~ /^[1-9][0-9]=.*[1-2][0-9][0-9]=$/) || ($6 ~ /^[1-2][0-9][0-9]=.*[1-9][0-9]=$/) || ($6 ~ /^[5-9][0-9]=$/) || ($6 ~ /^[1-2][0-9][0-9]=$/)' > /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_cigar_filtered.sam

cat /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_header.sam /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_cigar_filtered.sam > /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_cigar_filtered2.sam

samtools view -bS /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_cigar_filtered2.sam > /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_cigar_filtered.bam


##### STEP 5: Variant calling
##### The only filter here is on the quality of the base call, the default frequency filter of 0.2 will apply (i.e. a variant has to seen in at least a fifth of reads for it to be called)

freebayes --min-base-quality 30 -f /home/joShare/Joseph/programs/allORFs_pangenome.fasta /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_cigar_filtered.bam > /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/VCF_bit/NCYC$2_initial.vcf
#delete old files to clear up space as you go
rm -rf /home/joShare/Joseph/StrainData/Plate_$1/BWA_alignments/NCYC$2_*
rm -rf /home/joShare/Joseph/StrainData/Plate_$1/BWA_alignments/NCYC$2.*
rm -rf /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/NCYC$2_*



##### STEP 6: Variant splitting
##### This uses the vcflib tools and breaks down any complex variants in the vcf file into simpler variants
##### We tried loads of ways to do this task, the recipe below performed the best
#freebayes vcfbreakmulti /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_initial.vcf > /home/joShare/Joseph/StrainData/Plate_1/Samtools_BAM_files/NCYC68/NCYC68_initial2.vcf

vcfbreakmulti /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/VCF_bit/NCYC$2_initial.vcf > /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/VCF_bit/NCYC$2_initial2.vcf

vcfallelicprimitives -kg /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/VCF_bit/NCYC$2_initial2.vcf > /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/VCF_bit/NCYC$2_initial3.vcf

vcfstreamsort /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/VCF_bit/NCYC$2_initial3.vcf > /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/VCF_bit/NCYC$2_initial4.vcf

vcfuniq /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/VCF_bit/NCYC$2_initial4.vcf > /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/VCF_bit/NCYC$2_initial5.vcf


##### STEP 7: Variant filtering
##### This again uses vcflib and filters here on read depth (>= 30) and variant type (i.e. SNPs only)

vcffilter -f "DP > 29 & TYPE = snp" /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/VCF_bit/NCYC$2_initial5.vcf > /home/joShare/Joseph/StrainData/Plate_$1/freebayes_output/NCYC$2_freebayes_SNP_genome.vcf
rm -rf /home/joShare/Joseph/StrainData/Plate_$1/Samtools_BAM_files/NCYC$2/VCF_bit/*


echo "Plate $1, strain $2, plate type $3 finished." >> Cigar_Proof_of_Run.txt