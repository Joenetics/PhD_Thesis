#!/bin/bash
echo Conservative variant calling from Saccharomyces cerevisiae reads against the artificial 1,011 pangenome

##### EDIT THIS ARRAY AND INDEX BELOW TO CONTAIN/INCLUDE STRAINS UNDERGOING ANALYSIS

AllStrains=(166 371 372 373 745 746 747 783 794 894 2321 2322 2395 2396 2480 2486 2491 2492 2521 2529 2580 2753 3047 3096 3129 3398 3400 3719 3792 3870 140 141 147 161 408 411 492 524 559 566 582 585 608 677 678 696 820 2473 2568 2741 2885 3024 3141 3239 3255 3506 3877 62 135 138 142 154 155 158 159 162 195 377 502 539 541 758 759 796 797 844 845 930 931 974 1401 1645 1646 1647 1648 1649 1650 1651 1659 1660 2439 2440 2581 2599 2605 2666)

plate_number="2"
sequencing_plate="TGAC" # could be Eurofins

for index in $(seq 0 95);

do 

mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/freebayes_output/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}


/home/joShare/Joseph/programs/bwa/bwa mem /home/joShare/Joseph/programs/allORFs_pangenome.fasta /home/joShare/${sequencing_plate}_Plate_${plate_number}/Deduplicated_and_trimmed_reads/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_forward_paired.fastq /home/joShare/${sequencing_plate}_Plate_${plate_number}/Deduplicated_and_trimmed_reads/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_reverse_paired.fastq > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}.sam


samtools view -h -F 4 /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped.sam


##### STEP 3: Remove soft and hard clippings
##### This step removes reads that only partially mapped to the reference

samclip --ref /home/joShare/Joseph/programs/allORFs_pangenome.fasta --max 0 /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam


##### STEP 4: FAT-CIGAR filtering
##### This is Prithika's tool, which keeps only those reads which exactly match to the reference sequence at both ends
##### Her recent version does this all in one line but as the tool is in flux I'll send you this stable older version where we do things in several lines
#for testing


samtools view -H /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_header.sam

samtools view -bS /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_PRE.bam

python cigarv2.py /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_PRE.bam /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.bam

samtools view -h /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.bam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.sam

samtools view /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.sam | awk '($6 ~ /^[1-9][0-9]=.*[1-9][0-9]=$/) || ($6 ~ /^[1-9][0-9]=.*[1-2][0-9][0-9]=$/) || ($6 ~ /^[1-2][0-9][0-9]=.*[1-9][0-9]=$/) || ($6 ~ /^[5-9][0-9]=$/) || ($6 ~ /^[1-2][0-9][0-9]=$/)' > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.sam

cat /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_header.sam /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered2.sam

samtools view -bS /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered2.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.bam


##### STEP 5: Variant calling
##### The only filter here is on the quality of the base call, the default frequency filter of 0.2 will apply (i.e. a variant has to seen in at least a fifth of reads for it to be called)

freebayes --min-base-quality 30 -f /home/joShare/Joseph/programs/allORFs_pangenome.fasta /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.bam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial.vcf


##### STEP 6: Variant splitting
##### This uses the vcflib tools and breaks down any complex variants in the vcf file into simpler variants
##### We tried loads of ways to do this task, the recipe below performed the best

vcfbreakmulti /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial2.vcf

vcfallelicprimitives -kg /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial2.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial3.vcf

vcfstreamsort /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial3.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial4.vcf

vcfuniq /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial4.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial5.vcf


##### STEP 7: Variant filtering
##### This again uses vcflib and filters here on read depth (>= 30) and variant type (i.e. SNPs only)

vcffilter -f "DP > 29 & TYPE = snp" /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial5.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/freebayes_output/NCYC${AllStrains[index]}_freebayes_SNP_genome.vcf


done
