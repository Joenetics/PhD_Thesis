#!/bin/bash
echo Conservative variant calling from Saccharomyces cerevisiae reads against the artificial 1,011 pangenome

##### EDIT THIS ARRAY AND INDEX BELOW TO CONTAIN/INCLUDE STRAINS UNDERGOING ANALYSIS

AllStrains=(1013 1017 1020 1023 1030 1033 1037 1040 1044 1049 1052 1055 1060 1066 1069 1072 1076 1079 1082 1085 1089 1093 1097 1102 1106 1111 1114 1118 1122 1126 1129 1132 1138 1141 1147 1156 1159 1163 1167 1171 1175 1179 1183 1186 1190 1193 1196 1199 1202 1205 1208 1211 1215 1218 1221 1225 1231 1235 1240 1243 1246 1249 1254 1257 1260 1264 1270 1274 1277 1280 1283 1286 1289 1292 1298 1304 1308 1311 1314 1318 1321 1333 1336 1339 2732 2736 3306 3546 3549 3552 3997 4045 4051 4063 4068 4081)

plate_number="9"
sequencing_plate="EI" # could be Eurofins

for index in $(seq 0 95);

do 

mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/freebayes_output/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}


/home/joShare/Joseph/programs/bwa/bwa mem /home/joShare/Joseph/programs/allORFs_pangenome.fasta /home/joShare/${sequencing_plate}_Plate_${plate_number}/Deduplicated_and_trimmed_reads/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_forward_paired.fastq /home/joShare/${sequencing_plate}_Plate_${plate_number}/Deduplicated_and_trimmed_reads/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_reverse_paired.fastq > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}.sam


samtools view -h -F 4 /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped.sam


##### STEP 3: Remove soft and hard clippings
##### This step removes reads that only partially mapped to the reference

samclip --ref /home/joShare/Joseph/programs/allORFs_pangenome.fasta --max 0 /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam


##### STEP 4: FAT-CIGAR filtering
##### This is Prithika's tool, which keeps only those reads which exactly match to the reference sequence at both ends
##### Her recent version does this all in one line but as the tool is in flux I'll send you this stable older version where we do things in several lines
#for testing


samtools view -H /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_header.sam

samtools view -bS /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_PRE.bam

python cigarv2.py /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_PRE.bam /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.bam

samtools view -h /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.bam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.sam

samtools view /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.sam | awk '($6 ~ /^[1-9][0-9]=.*[1-9][0-9]=$/) || ($6 ~ /^[1-9][0-9]=.*[1-2][0-9][0-9]=$/) || ($6 ~ /^[1-2][0-9][0-9]=.*[1-9][0-9]=$/) || ($6 ~ /^[5-9][0-9]=$/) || ($6 ~ /^[1-2][0-9][0-9]=$/)' > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.sam

cat /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_header.sam /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered2.sam

samtools view -bS /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered2.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.bam


##### STEP 5: Variant calling
##### The only filter here is on the quality of the base call, the default frequency filter of 0.2 will apply (i.e. a variant has to seen in at least a fifth of reads for it to be called)

freebayes --min-base-quality 30 -f /home/joShare/Joseph/programs/allORFs_pangenome.fasta /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.bam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial.vcf


##### STEP 6: Variant splitting
##### This uses the vcflib tools and breaks down any complex variants in the vcf file into simpler variants
##### We tried loads of ways to do this task, the recipe below performed the best

vcfbreakmulti /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial2.vcf

vcfallelicprimitives -kg /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial2.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial3.vcf

vcfstreamsort /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial3.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial4.vcf

vcfuniq /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial4.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial5.vcf


##### STEP 7: Variant filtering
##### This again uses vcflib and filters here on read depth (>= 30) and variant type (i.e. SNPs only)

vcffilter -f "DP > 29 & TYPE = snp" /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial5.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/freebayes_output/NCYC${AllStrains[index]}_freebayes_SNP_genome.vcf


done
