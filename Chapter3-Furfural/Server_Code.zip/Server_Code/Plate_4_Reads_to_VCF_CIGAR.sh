#!/bin/bash
echo Conservative variant calling from Saccharomyces cerevisiae reads against the artificial 1,011 pangenome

##### EDIT THIS ARRAY AND INDEX BELOW TO CONTAIN/INCLUDE STRAINS UNDERGOING ANALYSIS

AllStrains=(392 971 2449 2560 2729 2703 2991 2827 1417 2483 2702 814 3853 2878 2450 3108 2754 2403 1416 1495 2999 2789 2513 2875 2508 2644 543 546 538 3788 2739 2976 17 1063 1064 1151 1337 2904 1449 2908 3612 3630 3662 826 232 754 667 975 956 695 739 235 3264 3265 3266 3311 3313 3314 3315 3318 3319 3445 3447 3448 3449 3451 3453 3454 3455 3456 3457 3458 3460 3461 3462 3466 3467 3469 3470 3471 3472 3486 3487 360 431 2592 2945 361 4000 1444 1603 1606 2397 2733 2737 3406)

plate_number="4"
sequencing_plate="Eurofins" # could be Eurofins

for index in $(seq 0 95);

do 

mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/freebayes_output/
mkdir -p /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}


/home/joShare/Joseph/programs/bwa/bwa mem /home/joShare/Joseph/programs/allORFs_pangenome.fasta /home/joShare/${sequencing_plate}_Plate_${plate_number}/Deduplicated_and_trimmed_reads/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_forward_paired.fastq /home/joShare/${sequencing_plate}_Plate_${plate_number}/Deduplicated_and_trimmed_reads/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_reverse_paired.fastq > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}.sam


samtools view -h -F 4 /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped.sam


##### STEP 3: Remove soft and hard clippings
##### This step removes reads that only partially mapped to the reference

samclip --ref /home/joShare/Joseph/programs/allORFs_pangenome.fasta --max 0 /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam


##### STEP 4: FAT-CIGAR filtering
##### This is Prithika's tool, which keeps only those reads which exactly match to the reference sequence at both ends
##### Her recent version does this all in one line but as the tool is in flux I'll send you this stable older version where we do things in several lines
#for testing


samtools view -H /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_header.sam

samtools view -bS /home/joShare/Joseph/StrainData/Plate_${plate_number}/BWA_alignments/NCYC${AllStrains[index]}_mapped_samclipped.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_PRE.bam

python cigarv2.py /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_PRE.bam /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.bam

samtools view -h /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.bam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.sam

samtools view /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar.sam | awk '($6 ~ /^[1-9][0-9]=.*[1-9][0-9]=$/) || ($6 ~ /^[1-9][0-9]=.*[1-2][0-9][0-9]=$/) || ($6 ~ /^[1-2][0-9][0-9]=.*[1-9][0-9]=$/) || ($6 ~ /^[5-9][0-9]=$/) || ($6 ~ /^[1-2][0-9][0-9]=$/)' > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.sam

cat /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_header.sam /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered2.sam

samtools view -bS /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered2.sam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.bam


##### STEP 5: Variant calling
##### The only filter here is on the quality of the base call, the default frequency filter of 0.2 will apply (i.e. a variant has to seen in at least a fifth of reads for it to be called)

freebayes --min-base-quality 30 -f /home/joShare/Joseph/programs/allORFs_pangenome.fasta /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_cigar_filtered.bam > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial.vcf


##### STEP 6: Variant splitting
##### This uses the vcflib tools and breaks down any complex variants in the vcf file into simpler variants
##### We tried loads of ways to do this task, the recipe below performed the best

vcfbreakmulti /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial2.vcf

vcfallelicprimitives -kg /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial2.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial3.vcf

vcfstreamsort /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial3.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial4.vcf

vcfuniq /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial4.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial5.vcf


##### STEP 7: Variant filtering
##### This again uses vcflib and filters here on read depth (>= 30) and variant type (i.e. SNPs only)

vcffilter -f "DP > 29 & TYPE = snp" /home/joShare/Joseph/StrainData/Plate_${plate_number}/Samtools_BAM_files/NCYC${AllStrains[index]}/NCYC${AllStrains[index]}_initial5.vcf > /home/joShare/Joseph/StrainData/Plate_${plate_number}/freebayes_output/NCYC${AllStrains[index]}_freebayes_SNP_genome.vcf


done
