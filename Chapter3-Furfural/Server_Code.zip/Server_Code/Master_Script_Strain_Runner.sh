#!/bin/bash
echo Conservative variant calling from Saccharomyces cerevisiae reads against the artificial 1,011 pangenome, using 30 cores

##### EDIT THIS ARRAY AND INDEX BELOW TO CONTAIN/INCLUDE STRAINS UNDERGOING ANALYSIS


nohup sh ./Secondary_Script_Strain_Runner.sh 0 &
nohup sh ./Secondary_Script_Strain_Runner.sh 1 &
nohup sh ./Secondary_Script_Strain_Runner.sh 2 &
nohup sh ./Secondary_Script_Strain_Runner.sh 3 &
nohup sh ./Secondary_Script_Strain_Runner.sh 4 &
nohup sh ./Secondary_Script_Strain_Runner.sh 5 &
nohup sh ./Secondary_Script_Strain_Runner.sh 6 &
nohup sh ./Secondary_Script_Strain_Runner.sh 7 &
nohup sh ./Secondary_Script_Strain_Runner.sh 8 &
nohup sh ./Secondary_Script_Strain_Runner.sh 9 &
nohup sh ./Secondary_Script_Strain_Runner.sh 10 &
nohup sh ./Secondary_Script_Strain_Runner.sh 11 &
nohup sh ./Secondary_Script_Strain_Runner.sh 12 &
nohup sh ./Secondary_Script_Strain_Runner.sh 13 &
nohup sh ./Secondary_Script_Strain_Runner.sh 14 &
nohup sh ./Secondary_Script_Strain_Runner.sh 15 &
nohup sh ./Secondary_Script_Strain_Runner.sh 16 &
nohup sh ./Secondary_Script_Strain_Runner.sh 17 &
nohup sh ./Secondary_Script_Strain_Runner.sh 18 &
nohup sh ./Secondary_Script_Strain_Runner.sh 19 &
nohup sh ./Secondary_Script_Strain_Runner.sh 20 &
nohup sh ./Secondary_Script_Strain_Runner.sh 21 &
nohup sh ./Secondary_Script_Strain_Runner.sh 22 &
nohup sh ./Secondary_Script_Strain_Runner.sh 23 &
nohup sh ./Secondary_Script_Strain_Runner.sh 24 &
nohup sh ./Secondary_Script_Strain_Runner.sh 25 &
nohup sh ./Secondary_Script_Strain_Runner.sh 26 &
nohup sh ./Secondary_Script_Strain_Runner.sh 27 &
nohup sh ./Secondary_Script_Strain_Runner.sh 28 &
nohup sh ./Secondary_Script_Strain_Runner.sh 29 &

