##This script puts all the Plate info into a text file, to be read by another program


import csv

outputfile = open("DictionaryFile.txt", "w")


AllFiles = ["Plate1.csv","Plate2.csv","Plate3.csv","Plate4.csv","Plate5.csv","Plate6.csv","Plate7.csv","Plate8.csv","Plate9.csv" ]

for file in AllFiles:
    with open(file) as csvfile:
        reader = csv.reader(csvfile, delimiter = ',')

        counter = 0
        TempPlate = str
        RowLetter = str

        for row in reader:
            if counter == 0: #Counter is 0 at first row
                TempPlate = (row[1]).replace(" ", "") # Saves plate name, removes space (Plate 9 -> Plate9)
                counter += 1 #Counter no longer used after first row
            elif row[0] == '': #this removes plate-name and plate-number rows.
                pass
            else:
                for i in row:
                    if len(i) == 1:
                        RowLetter = i
                    else: #TempPlate = plate number. RowLetter = well letter. row.Index(i) = well number. i = NCYC number & name of organism
                        RowIndex = str(row.index(i))
                        if len(RowIndex) == 1:
                            RowIndex = "0"+ RowIndex #this just adds '0' in front of 1,2,3... so plate names are consistent (Plate3A02, not Plate3A2...)
                        DictionaryKey = TempPlate + RowLetter + RowIndex
                        print(DictionaryKey, i.rstrip().replace(" ", "-"), file = outputfile) #Removes end spaces from names & replaces intra-spaces with '-'; removed on next program

