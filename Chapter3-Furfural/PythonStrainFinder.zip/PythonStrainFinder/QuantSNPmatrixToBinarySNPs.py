##MOST UPDATED SYSTEM (02/08/2018)

#NameInput = input("What is your file called? Make sure it's in the Jo_Stuff folder.")
InputMatrix = open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\ScGWAS185Det_all_snps2a.txt", 'r') #open(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff", NameInput, sep = ''), 'r')
#NameInput2 = input ("Input your desired output name.")
SplitNumber = float(input("What is your desired output split of SNPs? 2=binary (0,1), 3 = trinary (0,0.5,1)...."))
OutputMatrix = open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_stuff\\ConvertedMatrix" + str(int(SplitNumber)) + ".txt", 'w') # open(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", NameInput2, sep = ''), 'w')

print("Will split SNP values into:")
for o in range(0, int(SplitNumber)):
    print(round((1/int(SplitNumber-1)*o), 2), sep = '\n')

MiniDictionary = {}
TempArray = []


for line in InputMatrix:
    if line.startswith("\""):
        TempArray.append(line.split("\" ")[0].strip("\"")+ ',' + line.split("\" ")[1].replace(' ', ','))
        #MiniDictionary[line.split("\" ")[0].strip("\"")] = line.split("\" ")[1].replace(' ', ',')

BracketNumber = float((1)/(SplitNumber-1))
FinalArray = []
counter = len(TempArray)
for i in range(0, len(TempArray)):
    TempierArray = TempArray[i].strip('\n').split(',')
    ArrayAssembler = []
    ArrayAssembler.append("\"" + TempierArray[0] + "\" ")

    for e in range(1, len(TempierArray)):

        if str(TempierArray[e]) == '0':
            ArrayAssembler.append("0 ")
        elif str(TempierArray[e])== "1":
            ArrayAssembler.append("1 ")
        else:
            for j in range(0, int(SplitNumber)): #Splitnumber = (eg) 3, BracketNumber = 0.5 (=> 0,0.5, 1) ; j=0,1
                #print(TempierArray[e])
                if float(float(TempierArray[e])-float(BracketNumber*(j))) <= float(float(BracketNumber*(j+1)) - float(BracketNumber*j))/2 and float(BracketNumber * (j)) < float(TempierArray[e]) <= float(BracketNumber*(j+1)):
                    ArrayAssembler.append(str(round(BracketNumber*(j), 2)) + ' ')
                    #if float(TempierArray[e]) > float(0.5):                                ##This line and one below (and copy in other if-else
                    #    print(TempierArray[e], " to ", str(round(BracketNumber*(j), 2)))   ##Are for testing if answers are coming correct.
                elif float(BracketNumber * (j)) < float(TempierArray[e]) <= float(BracketNumber*(j+1)):
                    #if float(TempierArray[e]) > float(0.5):
                    #    print(TempierArray[e], " to ", str(round(BracketNumber*(j+1), 2)))
                    ArrayAssembler.append(str(round(BracketNumber*(j+1), 2)) + ' ')
                ##else here would spit out variables that dont fit current loop conditions (0-0.5, 0.5-1).
    counter = counter-1
    #print('\ncounter: ', counter)
    FinalArray.append(''.join(ArrayAssembler) + '\n')

for o in range(0,len(FinalArray)):
    print(FinalArray[o].strip(), sep = '\n', file= OutputMatrix)



