import csv
import sys
import datetime

##this is the current code, not SuccinateWekaMaker.py!
## for furfural succinate only study, use 'D'. Turns file into one for Weka

now = datetime.datetime.now() #get time&date for timestamp

PlateNumber = input("Plate number of input file? or: A= JointSlopeResults, B= UnseenData, C= All9Platesjoined. D = JointLogSlopes")
if PlateNumber.upper() == "A":      #see above
    InputFile = "JointSlopeResults.csv"
elif PlateNumber.upper() == "B":    #see above
    InputFile = "UnseenData.csv"
elif PlateNumber.upper() == "C":    #see above
    InputFile = "All9PlatesForWeka.csv"
elif PlateNumber.upper() == "D":
    InputFile = "WekaPredictedResistanceLogGrowthSacchOnlyDoubleReduced8.csv"
else:
    InputFile = "Plate" + PlateNumber + "SlopeResults.csv" #number should be 1-9... if fails, someone is a fool.
OutputFileName = InputFile[:-4] + "WEKA" + ".arff"

OutputFile = open(OutputFileName,'w')

if InputFile[-4:] == ".csv":
    pass #YOU SHALL PASS (wait... that's not the quote.)
else:
    print("File MUST be in format of .csv!\n Program will exit.")
    sys.exit()

CSVFile = []
with open(InputFile) as csvfile:                       #Open first file
    readCSV = csv.reader(csvfile, delimiter=',')   #Read into temp variable
    for row in readCSV:                            #Read each row
        #dothings
        #print(row[0])
        CSVFile.append(row)


print("%1.0 Title: ", InputFile[:-4], " Weka-fied.", sep= '', file=OutputFile)
print("%Creator: Joseph Shepherd\n%Email; Joseph.shepherd@uea.ac.uk (If I've left, email Tom.Clarke@uea.ac.uk)\n%Date: ", now,"\n%Feel free to steal and ask for help.", sep = '', file= OutputFile)
print("@RELATION ", InputFile[:-4], "\n", sep= '', file = OutputFile)
print("@ATTRIBUTE slope NUMERIC\n@ATTRIBUTE timepoint NUMERIC\n@ATTRIBUTE MaxOD NUMERIC\n@ATTRIBUTE RoughInflection NUMERIC\n@ATTRIBUTE resistant {1, 0}", sep = '', file=OutputFile)
print("@DATA\n", file = OutputFile)

if PlateNumber.upper() == "D":
    for line in CSVFile:
        if line[0] == "" or line[0].lower() == "well":   #remove first line without well number.
            pass
        elif line[8] != None:
            print(line[4], line[5], line[6], (line[7]), line[10], sep= ",", file = OutputFile)
        else:
            print(line[4], line[5], line[6], line[7], "?", sep= ",", file = OutputFile)

else:
    for line in CSVFile:
        if line[0] == "":   #remove first line without well number.
            pass
        elif line[8] != None:
            print(line[4], line[5], line[6], line[7], line[8], sep= ",", file = OutputFile)
        else:
            print(line[4], line[5], line[6], line[7], "?", sep= ",", file = OutputFile)
