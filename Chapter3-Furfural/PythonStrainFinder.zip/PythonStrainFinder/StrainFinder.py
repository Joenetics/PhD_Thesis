#Reads dictionary file. You plug in plate/well info; it gives you strain number.

DictionaryFile = open("DictionaryFile.txt", "r")
FancyDictionary = {} #This will be main dictionary for program later.
## It was then manually updated for all strain names. see 'DictionaryFileFull.txt'

for line in DictionaryFile:
    data = line.split(" ")
    FancyDictionary[data[0]] = data[1].rstrip("\n")

print("Type Plate and well info, e.g Plate1H2 \n CASE SENSITIVE \n Type \"done\" when done")
for i in range(0,200):
    Inputter = input("\nPlate and well:")

    if Inputter == "done":
        break
    else:
        try:
            print("Your strain is:", FancyDictionary[Inputter], "\n")
        except:
            print("Please make it case sensitive; \nThere are only 9 plates, wells A-H and numbers 1-12\ne.g; Plate3D6")
