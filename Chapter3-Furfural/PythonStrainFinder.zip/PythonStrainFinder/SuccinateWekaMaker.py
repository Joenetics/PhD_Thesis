import sys
import datetime
import csv


##see WekaMaker.py
now = datetime.datetime.now() #get time&date for timestamp

StrainListOrdered = "C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Ranked185Strains.csv"
SNPdatafile = open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\ConvertedMatrix3.txt", 'r')
WekaOutput = open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Ranked185Strains.arff", 'w')


SuccinateConc = "0.05" # input("How much succinate do you want to do as a threshold? E.g; 0.05")



MiniDictionary = {}

for line in SNPdatafile:
    if line.startswith("\""):
        MiniDictionary[line.split("\" ")[0].strip("\"")] = line.split("\" ")[1].replace(' ', ',')


OrderedOutput = []
CounterHigh = 0
CounterLow = 0
with open(StrainListOrdered) as CSVfile:
    csvfile = csv.reader(CSVfile , delimiter = ',')
    for each in csvfile:
        if each[4] == 'SuccinateMean':
            pass
        else:

            if float(each[4]) >= float(SuccinateConc): # 'high' means a high producer.
                #TempString = [each[0].strip(), ',', MiniDictionary[each[0]].strip('\n'), 'high']    ##This one uses NCYC number
                TempString = [MiniDictionary[each[0]].strip('\n'), ',high']
                OrderedOutput.append(''.join(TempString))
                CounterHigh +=1
            else:
                #TempString = [each[0].strip(),",", MiniDictionary[each[0]][-9:].strip('\n'), 'low']  ##This one uses NCYC number.
                TempString = [MiniDictionary[each[0]].strip('\n'), ',low']
                OrderedOutput.append(''.join(TempString))
                CounterLow +=1

print((CounterHigh)/ (CounterHigh + CounterLow)*100,  " Percent of strains counting as \'high\' producers")

print("%1.0 Title: ", StrainListOrdered[:-4], " Weka-fied.", sep= '', file=WekaOutput)
print("%Creator: Joseph Shepherd\n%Email; Joseph.shepherd@uea.ac.uk (If I've left, email Tom.Clark@uea.ac.uk)\n%Date: ", now,"\n%Feel free to steal and ask for help.", sep = '', file= WekaOutput)
print("@RELATION MLforSuccinateData" , file = WekaOutput)
for j in range(0,1481368):
    print("@ATTRIBUTE nominal", j," {0,0.5,1}", sep = '',file = WekaOutput)
print("@ATTRIBUTE Productivity {high,low}", '\n@DATA', file = WekaOutput)

for i in range(0, len(OrderedOutput)):
    print(OrderedOutput[i], file = WekaOutput)
