
##Why is linear pulling data from bad dictionary? SOLVE.
LogGrowth = input("Do you want to use log growth files? Y/N")

if LogGrowth.lower() == "y":
    LogGrowth = "LogGrowth"
else:
    LogGrowth = ""

SC_yes = input("Do you want SC only? y/n/DE")
if SC_yes.lower() == "y":
    SCset = input("Which SC set? Full(1), Reduced (2), DoubleReduced(3)?")
    if SCset == "1":
        SCset = "SacchOnlyFull"
        SClist = [70,72,73,74,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,505,1006,1026,1187,1228,1245,1681,492,2826,3284,3290,3312,3452,3468,104,107,108,110,113,118,121,122,124,125,126,167,176,177,181,182,183,185,186,187,190,192,196,197,198,199,200,201,202,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,1063,1064,1151,1337,3612,3630,826,232,754,667,956,695,739,235,3264,3265,3266,3311,3313,3314,3315,3318,3319,3445,3447,3448,3449,3451,3453,3454,3455,3456,3457,3458,3460,3461,3462,3466,3467,3469,3470,3471,3472,3486,3487,360,431,2592,2945,361,1444,1603,1606,2397,2733,2737,3406,356,357,358,430,463,478,479,482,619,620,621,671,672,684,816,1406,1407,1408,1409,1410,1411,1412,1413,1414,1415,1431,2401,2402,2517,2587,2683,2688,2695,2808,2809,2855,2947,2948,489,490,491,525,694,1529,1530,1765,238,241,341,609,807,935,1315,1673,3034,3358,3557,3562,3324,3025,3026,3027,3048,3051,3052,3028,2776,3029,3030,3122,3123,3325,3326,2777,3331,2778,3031,3332,3333,2779,3076,3334,3338,3077,3078,3032,3339,3121,3124,3080,3114,2780,2798,234,3033,3035,3125,3126,3127,2913,2965,3036,3037,3038,3039,2966,2967,2974]
    #contains 'maybe' SC strains.
    elif SCset == "2":
        SCset = "SacchOnlyReduced"
        SClist = [70, 72, 74, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 95, 96, 97, 167, 192, 196, 197, 200, 205, 206, 208, 210, 211, 212, 213, 221, 222, 223, 224, 225, 228, 232, 235, 241, 356, 357, 358, 360, 361, 430, 478, 479, 482, 490, 491, 505, 609, 619, 620, 621, 667, 672, 684, 695, 816, 1006, 1026, 1064, 1151, 1228, 1245, 1315, 1337, 1406, 1407, 1408, 1409, 1413, 1414, 1415, 1444, 1529, 1603, 1681, 2397, 2401, 2517, 2592, 2688, 2733, 2737, 2776, 2777, 2778, 2779, 2780, 2798, 2826, 2855, 2945, 2947, 2948, 2967, 2974, 3025, 3026, 3028, 3030, 3031, 3032, 3033, 3035, 3036, 3037, 3038, 3039, 3051, 3052, 3076, 3077, 3078, 3114, 3121, 3122, 3123, 3124, 3125, 3126, 3127, 3265, 3266, 3311, 3313, 3314, 3315, 3318, 3319, 3324, 3325, 3326, 3331, 3333, 3334, 3338, 3339, 3406, 3445, 3447, 3448, 3449, 3452, 3455, 3456, 3457, 3458, 3460, 3461, 3462, 3467, 3470, 3471, 3472, 3486, 3487, 3557, 3612, 3630, 94, 104, 107, 108, 110, 113, 118, 121, 122, 124, 176, 177, 183, 185, 186, 187, 190, 198, 199, 201, 202, 207, 209, 215, 216, 217, 218, 219, 220, 226, 227, 229, 231, 826, 956, 1187, 1410, 1765, 2402, 2587, 2695, 2809, 3048, 3080, 3264, 3284, 3290, 3312, 3468, 3469]
    #Only certaub SCs
    elif SCset == "3":
        SCset = "SacchOnlyDoubleReduced"
        SClist = [70, 72, 74, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 95, 96, 97, 167, 192, 196, 197, 200, 205, 206, 208, 210, 211, 212, 213, 221, 222, 223, 224, 225, 228, 232, 235, 241, 356, 357, 358, 360, 361, 430, 478, 479, 482, 490, 491, 505, 609, 619, 620, 621, 667, 672, 684, 695, 816, 1006, 1026, 1064, 1151, 1228, 1245, 1315, 1337, 1406, 1407, 1408, 1409, 1413, 1414, 1415, 1444, 1529, 1603, 1681, 2397, 2401, 2517, 2592, 2688, 2733, 2737, 2776, 2777, 2778, 2779, 2780, 2798, 2826, 2855, 2945, 2947, 2948, 2967, 2974, 3025, 3026, 3028, 3030, 3031, 3032, 3033, 3035, 3036, 3037, 3038, 3039, 3051, 3052, 3076, 3077, 3078, 3114, 3121, 3122, 3123, 3124, 3125, 3126, 3127, 3265, 3266, 3311, 3313, 3314, 3315, 3318, 3319, 3324, 3325, 3326, 3331, 3333, 3334, 3338, 3339, 3406, 3445, 3447, 3448, 3449, 3452, 3455, 3456, 3457, 3458, 3460, 3461, 3462, 3467, 3470, 3471, 3472, 3486, 3487, 3557, 3612, 3630]
elif SC_yes.lower() == "de":
    print("This data includes all previous Sacch data for accurate k-means comparison.")
    SCset = "DE"
    SClist = [70, 72, 74, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 95, 96, 97, 167, 192,
              196, 197, 200, 205, 206, 208, 210, 211, 212, 213, 221, 222, 223, 224, 225, 228, 232, 235, 241, 356, 357,
              358, 360, 361, 430, 478, 479, 482, 490, 491, 505, 609, 619, 620, 621, 667, 672, 684, 695, 816, 1006, 1026,
              1064, 1151, 1228, 1245, 1315, 1337, 1406, 1407, 1408, 1409, 1413, 1414, 1415, 1444, 1529, 1603, 1681,
              2397, 2401, 2517, 2592, 2688, 2733, 2737, 2776, 2777, 2778, 2779, 2780, 2798, 2826, 2855, 2945, 2947,
              2948, 2967, 2974, 3025, 3026, 3028, 3030, 3031, 3032, 3033, 3035, 3036, 3037, 3038, 3039, 3051, 3052,
              3076, 3077, 3078, 3114, 3121, 3122, 3123, 3124, 3125, 3126, 3127, 3265, 3266, 3311, 3313, 3314, 3315,
              3318, 3319, 3324, 3325, 3326, 3331, 3333, 3334, 3338, 3339, 3406, 3445, 3447, 3448, 3449, 3452, 3455,
              3456, 3457, 3458, 3460, 3461, 3462, 3467, 3470, 3471, 3472, 3486, 3487, 3557, 3612, 3630, "1A",
              "1B", "1C", "1D", "1E", "1F", "1G", "1H", "2A", "2B", "2C", "2D", "2E", "2F", "2G"]  # last strings are for DE strains

else:
    SClist = []
    SCset = ""


DictionaryForStrainNumbers = open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\DictionaryFileReal.txt", "r")
OutputFile = open("JoinedSlopeResults"+LogGrowth + SCset + ".csv", "w")
StrainDictionary = {}
for line in DictionaryForStrainNumbers:
    if SC_yes.lower() in ["y", "yes", "de"]:
        try:
            if int(line.split(" ")[1].split("-")[0].split(".")[0]) in SClist:
                StrainDictionary[str(line.split(" ")[0].replace("Plate", ""))] = line.split(" ")[1].split("-")[0]
        except:
            if str(line.split(" ")[1].split("-")[0].split(".")[0]) in SClist:
                StrainDictionary[str(line.split(" ")[0].replace("Plate", ""))] = line.split(" ")[1].split("-")[0]
    else:
        StrainDictionary[str(line.split(" ")[0].replace("Plate", ""))] = line.split(" ")[1].split("-")[0]
counter = 0
print("Well","Highest Slope control","Timepoint Control","Max OD control", "Rough Inflection Control", "Highest Slope furfural","Timepoint furfural","Max OD furfural","Rough Inflection Point", "C Value","Strain Number", sep =",", file = OutputFile)

if SC_yes.lower() == "de":
    for i in [1, 2, 3, 4, 5, 6, 7, 8, 9, "DE"]: #Plates 1 to 9 + de
        FileName = "Plate" + str(i) + "SlopeResults" + LogGrowth + ".csv"
        SlopeFile = open(FileName, "r")
        for line in SlopeFile:
            data = line.split(",")
            if (data[0]) == "\"\"":
                pass
            else:
                PlateAndStrain = str(i) + data[0].strip("\"")

                if PlateAndStrain in StrainDictionary:  ##Check if the strain is in the dictionary (Which excludes bad replicates like 17, 2804, ...)
                    print("P" + str(i) + line.strip("\n").replace("\"", ""), StrainDictionary[PlateAndStrain], sep=",",
                          file=OutputFile)  # Lets not add plate information until later?
                """elif PlateAndStrain in ["DEA01", "DEA02", "DEB01", "DEB02", "DEC01", "DEC02", "DED01", "DED02", "DEE01", "DEE02", "DEF01", "DEF02", "DEG01", "DEG02", "DEH01"]:  # DE wells
                    print("P_DE_" + line.strip("\n").replace("\"", ""), PlateAndStrain, sep=",",
                          file=OutputFile)"""
                counter += 1
else:
    for i in [1, 2, 3, 4, 5, 6, 7, 8, 9, "DE"]: #Plates 1 to 9 + de
        FileName = "Plate"+str(i)+"SlopeResults"+LogGrowth+".csv"
        SlopeFile = open(FileName, "r")
        for line in SlopeFile:
            data = line.split(",")
            if (data[0]) == "\"\"":
                pass
            else:
                PlateAndStrain = str(i) + data[0].strip("\"")

                if PlateAndStrain in StrainDictionary: ##Check if the strain is in the dictionary (Which excludes bad replicates like 17, 2804, ...)
                    print("P" + str(i)+line.strip("\n").replace("\"", ""), StrainDictionary[PlateAndStrain], sep = ",",file= OutputFile) #Lets not add plate information until later?
                else:
                    pass
                counter +=1
