import csv

MultiFile = open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\ALLYEAST_LATEST_succinate_glucose_malic_arabinitol.csv", 'r')
FurfuralFile = open("DictionaryFileFull.txt", 'r')
#comment out next line if just doing count of S.cerevisae
OutputFile = open("StrainsINeedToNMR.txt", 'w')

ListOfMulti = []
ListOfFurfural = []

for line in MultiFile:
    data= line.split(',')
    if data[0] == '' or data[0] == 'index':
        pass
    else:
        ListOfMulti.append(data[1])
counter5 = 0
total = 0
for line in FurfuralFile:
    data = (line.split(' ')[1]).split('-')
    ListOfFurfural.append(data[0])
'''#This was for counting number of S.cerevisae strains in dataset. total = 399. But sacch in QIB ahs only 185...
    if data[1].strip()== "Saccharomyces.cerevisiae":
        counter5 += 1
    total +=1
print("Sacch: ", counter5, "\nTotal Strains: ", total, sep ='')
'''


counter1 = 0
counter2 = 0
NCYCWithoutNMR = []
for i in ListOfFurfural:
    if i in ListOfMulti:
        counter1+=1
    else:
        NCYCWithoutNMR.append(i)
        counter2 +=1
#comment out these next two lines if just counting S.cerevisae strains.
print("Matched Strains:", counter1, "Unmatched Stains:", counter2, sep ="\t", file= OutputFile)
print("Strain numbers wihout current NMR: ", NCYCWithoutNMR, sep = "\t", file= OutputFile)  #Print the names of strains not previously done with NMR; do them myself.

