

InputTXT= open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\ScGWAS185Det_all_snps2a.txt", 'r')
OutputCSV = open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\SNPsAsCSV.csv", 'w')

TempArray = []
TempString = []
TempString.append("Strain")
for h in range (0, 1481368):
    TempString.append(",Data point" + str(h))

TempArray.append(''.join(TempString))
for line in InputTXT:
    if line.startswith("\""):
        TempArray.append(line.replace(' ', ',').strip('\"').strip('\n'))


for jk in range(0, len(TempArray)):
    print(TempArray[jk], file= OutputCSV)




