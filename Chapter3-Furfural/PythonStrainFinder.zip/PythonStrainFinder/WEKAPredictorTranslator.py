import sys
import csv

WEKAPredictions = "9PlatesPredicted.csv"

TailoredOutput = open("StrainsAndResistance.csv", 'w')

DictionaryFile = open("DictionaryFile.txt", "r")
FancyDictionary = {} #This will be main dictionary for program.
WellTranslator = ["A01" ,"A02" ,"A03" ,"A04" ,"A05","A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12"]

EntireCSV = []
for line in DictionaryFile:
    data = line.split(" ")
    FancyDictionary[data[0]] = data[1].rstrip("\n")

with open(WEKAPredictions) as csvfile:                       #Open first file
    readCSV1 = csv.reader(csvfile, delimiter=',')   #Read into temp variable
    for row in readCSV1:                            #Read each row
        EntireCSV.append(row)                       #Save entire CSV file, row by row
print("strain,resistance", sep='', file=TailoredOutput) #Header for output file



for k in range(1,10):
    for l in range(1,97):

        if EntireCSV[((k-1)+l)][2] == "02:00" or EntireCSV[((k-1)+l)][2] == "2:0":
            PlateAndWell = "Plate" + str(k) + str(WellTranslator[l-1])
            print(FancyDictionary[PlateAndWell], ",Non-Resistant", sep = "\t", file = TailoredOutput)#non-resistant
        elif EntireCSV[((k-1)+l)][2] == "01:01" or EntireCSV[((k-1)+l)][2] == "1:1":
            PlateAndWell = "Plate" + str(k) + str(WellTranslator[l-1])
            print(FancyDictionary[PlateAndWell], ",Resistant", sep = "\t",  file = TailoredOutput)#non-resistant
        else:
            print(EntireCSV[((k-1)+l)][2])
            print("Something's gone wrong...")





