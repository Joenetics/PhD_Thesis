import statistics
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.datasets.samples_generator import make_blobs
from sklearn.cluster import KMeans
import sys
import math
##This code turns k-means clustering prediction data into binary classifications. better than other one which used quartiles.

##This is later run through WekaMaker.py to convert file to .arff to ensure it works in Weka
LogOrLinear = input("Do you want to analyse log or linear growth? Log/Linear")
ScoreValue = 000 #input("What score do you want to count as resistant? 2-8, recommend 6.")
Species = "SacchOnly" #input("What species? E.g, SacchOnly,...")
#Species = ""
#SCset = "Full"
#SCset = "Reduced"
SCset = "DoubleReduced"

global sum_of_squares_dict
global sum_of_squares_dict2
sum_of_squares_dict = dict()
sum_of_squares_dict2 = dict()

Number_of_clusters_inflection = 2   # best at 4?
Number_of_clusters_maxod = 2       # alright at 6
Number_of_clusters_slope = 0
Number_of_clusters_slope_point = 2  # best at 5?
Number_of_clustes_cvalue = 0
Number_of_clustes_ratio = 0
Number_of_clustes_ratio_slope = 0


if LogOrLinear.lower() == "log":
    LogOrLinear = "LogGrowth"
    print("You have chosen to do log growth analysis of binary resistance.")

else:
    LogOrLinear = ""
    print("You have chosen to do linear growth analysis of binary resistance.\nIf you meant to do log, restart and type \'log\'.")


InputGrowthFile = open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\JoinedSlopeResults" + LogOrLinear+ Species + SCset + ".csv", "r")

OutputGrowthFile = open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\WekaPredictedResistance" + LogOrLinear+ ""+ Species + SCset + str(ScoreValue) +".csv", "w")


Wells = []
ControlSlopes = []
ControlTimepoints = []
ControlMaxOD = []
FurfuralSlopes = []
FurfuralTimepoints = []
FurfuralMaxOD = []
FurfuralInflections = []
StrainList = []
C_values = []
Inflection_control = []
Inflection_ratio = []
Slope_ratio = []

for line in InputGrowthFile:
    data = line.split(",")
    if data[0].lower() == "well":
        pass #This is header line. do not need.
    else:
        Wells.append(data[0])
        ControlSlopes.append(float(data[1]))
        ControlTimepoints.append(float(data[2]))
        ControlMaxOD.append(float(data[3]))
        Inflection_control.append(float(data[4]))
        FurfuralSlopes.append(float(data[5]))
        FurfuralTimepoints.append(float(data[6]))
        FurfuralMaxOD.append(float(data[7]))
        FurfuralInflections.append(float(data[8]))
        C_values.append(float(data[9]))
        StrainList.append(data[10].strip("\n"))
        Inflection_ratio.append((float(data[4])/float(data[8])))
        Slope_ratio.append((float(data[5])/float(data[1])))
print(str(len(FurfuralMaxOD)) + " strains present")

####TEST

wcss = []
for i in range(1, 11):
    kmeans = KMeans(n_clusters=i, init='k-means++', max_iter = 300, n_init=10, random_state=0)
    arrayy = np.asarray(FurfuralSlopes)
    kmeans.fit(arrayy.reshape(-1,1))
    wcss.append(kmeans.inertia_)
plt.plot(range(1, 11), wcss)
plt.title('Elbow Method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
#plt.show()
clusters = 5
kmeans = KMeans(n_clusters=clusters, init='k-means++', max_iter=300, n_init=10, random_state=0)
pred_y = kmeans.fit_predict(arrayy.reshape(-1,1))
templist = []
for ui in range(0, clusters):
    templist.append(kmeans.cluster_centers_[ui][0])


def makeclusters(cluster_number, array_tested):
    kmeans = KMeans(n_clusters=cluster_number, init='k-means++', max_iter=300, n_init=10, random_state=0)
    array_tested = np.asarray(array_tested)
    pred_y = kmeans.fit_predict(array_tested.reshape(-1,1))
    templist = []
    for ui in range(0, cluster_number):
        templist.append(kmeans.cluster_centers_[ui][0])
    templist = sorted(templist)
    return templist



'''
#old
FurfuralInflectionsPoints = [2.0633, 10.7692, 19.0667, 26.3409, 35.5366]  # make into five clusters
FurfuralMaxODPoints = [0.3257, 0.0823, (-0.1131), (-0.3404), (-0.6259)]  # make into 5 clusters
FurfuralSlopesPoints = [0.1486, 0.1019, 0.0656, 0.047, 0.0309]  # make into 5 clusters

#test
FurfuralInflectionsPoints = [1.3788, 7.6111, 12.9143,  19.907, 27.3191, 36.4706]  # make into 6 clusters
FurfuralMaxODPoints = [0.3257, 0.0978, -0.0752,  -0.2684, -0.4461, -0.6767]  # make into 6 clusters
FurfuralSlopesPoints = [0.1486, 0.1019, 0.0656, 0.047, 0.0309]  # make into 5 clusters
'''

global SummaryOfPoints
SummaryOfPoints = [0] * len(FurfuralMaxOD)
if Number_of_clusters_inflection > 0:
    FurfuralInflectionsPoints = makeclusters(Number_of_clusters_inflection, FurfuralInflections)
    expected_FurfuralInflectionsPoints = makeclusters(Number_of_clusters_inflection, FurfuralInflections)
if Number_of_clusters_maxod > 0:
    FurfuralMaxODPoints = makeclusters(Number_of_clusters_maxod, FurfuralMaxOD)
if Number_of_clusters_slope > 0:
    FurfuralSlopesPoints = makeclusters(Number_of_clusters_slope, FurfuralSlopes)
if Number_of_clusters_slope_point > 0:
    FurfuralSlope_point = makeclusters(Number_of_clusters_slope_point, FurfuralTimepoints)
    #print(FurfuralSlope_point)
if Number_of_clustes_cvalue > 0:
    Cvalue_cluster_points = makeclusters(Number_of_clustes_cvalue, C_values)
if Number_of_clustes_ratio > 0:
    Ratio_cluster_points = makeclusters(Number_of_clustes_ratio, Inflection_ratio)
if Number_of_clustes_ratio_slope > 0:
    Ratio_slope = makeclusters(Number_of_clustes_ratio_slope, Slope_ratio)

#print(FurfuralMaxODPoints)

InflectionCluster = []
MaxODCluster = []
SlopeCLuster = []
SlopeCluster_Point = []
cvalues = []
Inf_ratios = []
Slope_ratios = []

def make_cluster_scorings(number_clusters, raw_data, clusters, negative_or_positive, name_string):
    sum_of_squares_dict[name_string] = {}
    #print(sum_of_squares_dict)
    for oki in range(0, len(clusters)):
        sum_of_squares_dict[name_string][oki + 1] = []
    #print(sum_of_squares_dict)
    global SummaryOfPoints
    clustered_data = []
    Sum_of_Squares = 0

    for EachStrain in range(0, len(raw_data)):  #Low Inflection number = high resistance => high score.
        each_comparison = [0] * number_clusters  # see which cluster it most belongs to. 0 = perfect match
        #print("*****")
        #print(raw_data[EachStrain])
        #print(clusters)
        for eachcluster in range(0, len(clusters)):
            each_comparison[eachcluster] = abs(clusters[eachcluster] - raw_data[EachStrain])
        #print(each_comparison)
        smallestvalue = sorted(each_comparison)[0]
        #print(smallestvalue)
        Sum_of_Squares += float(float(abs(smallestvalue))**2)/(len(raw_data)-1)  # (closest point)^2 /number of strains

        for point in range(0, len(each_comparison)):
            if each_comparison[point] == smallestvalue:
                if ("All"+name_string) in sum_of_squares_dict2:
                    sum_of_squares_dict2["All"+name_string] = sum_of_squares_dict2["All"+name_string] + [raw_data[EachStrain]]
                else:
                    sum_of_squares_dict2["All" + name_string] = [raw_data[EachStrain]]
                if negative_or_positive == "Negative":
                    SummaryOfPoints[EachStrain] += (len(each_comparison) - point)
                    clustered_data.append((len(each_comparison) - point))
                    # for below:
                    # dict[characteristic, e.g, MaxOD][Cluster point, e.g, point 3 of 4] = list of values in that cluster
                    sum_of_squares_dict[name_string][len(each_comparison) - point] = sum_of_squares_dict[name_string][len(each_comparison) - point] + [raw_data[EachStrain]]
                if negative_or_positive == "Positive":
                    #print(point)
                    SummaryOfPoints[EachStrain] += (point + 1)
                    clustered_data.append((point + 1))
                    # for below:
                    # dict[characteristic, e.g, MaxOD][Cluster point, e.g, point 3 of 4] = list of values in that cluster
                    sum_of_squares_dict[name_string][point + 1] = sum_of_squares_dict[name_string][point + 1] + [raw_data[EachStrain]]
        #print("*****")

    #print(Sum_of_Squares)
    #sys.exit()
    return clustered_data


if Number_of_clustes_cvalue > 0:
    cvalues = make_cluster_scorings(Number_of_clustes_cvalue, C_values, Cvalue_cluster_points, "Positive", "C_Value")

if Number_of_clusters_inflection > 0:
    InflectionCluster = make_cluster_scorings(Number_of_clusters_inflection, FurfuralInflections, FurfuralInflectionsPoints, "Negative", "Inflection")

if Number_of_clusters_slope_point > 0:
    SlopeCluster_Point = make_cluster_scorings(Number_of_clusters_slope_point, FurfuralTimepoints, FurfuralSlope_point, "Negative", "Slope_Point")

if Number_of_clusters_maxod > 0:
    MaxODCluster = make_cluster_scorings(Number_of_clusters_maxod, FurfuralMaxOD, FurfuralMaxODPoints, "Positive", "MaxOD")

if Number_of_clusters_slope > 0:
    SlopeCLuster = make_cluster_scorings(Number_of_clusters_slope, FurfuralSlopes, FurfuralSlopesPoints, "Positive", "Slope_Value")

if Number_of_clustes_ratio > 0:
    Inf_ratios = make_cluster_scorings(Number_of_clustes_ratio, Inflection_ratio, Ratio_cluster_points, "Positive", "Cluster_Ratio")

if Number_of_clustes_ratio_slope > 0:
    Slope_ratios = make_cluster_scorings(Number_of_clustes_ratio_slope, Slope_ratio, Ratio_slope, "Positive", "Slope Ratio")


'''
if Number_of_clustes_cvalue > 0:
    for EachStrain in range(0, len(C_values)):  #Low Inflection number = high resistance => high score.
        each_comparison = [0] * Number_of_clustes_cvalue  # see which cluster it most belongs to. 0 = perfect match
        for eachcluster in range(0, len(Cvalue_cluster_points)):
            each_comparison[eachcluster] = abs(Cvalue_cluster_points[eachcluster] - C_values[EachStrain])
        smallestvalue = sorted(each_comparison)[0]

        for point in range(0, len(each_comparison)):
            if each_comparison[point] == smallestvalue:
                SummaryOfPoints[EachStrain] += (len(each_comparison) - point)
                cvalues.append((len(each_comparison) - point))



if Number_of_clusters_inflection > 0:
    for EachStrain in range(0, len(FurfuralInflections)):  #Low Inflection number = high resistance => high score.
        each_comparison = [0] * Number_of_clusters_inflection  # see which cluster it most belongs to. 0 = perfect match
        for eachcluster in range(0, len(FurfuralInflectionsPoints)):
            each_comparison[eachcluster] = abs(FurfuralInflectionsPoints[eachcluster] - FurfuralInflections[EachStrain])
        smallestvalue = sorted(each_comparison)[0]

        for point in range(0, len(each_comparison)):
            if each_comparison[point] == smallestvalue:
                SummaryOfPoints[EachStrain] += (len(each_comparison) - point)
                InflectionCluster.append((len(each_comparison) - point))


if Number_of_clusters_slope_point > 0:
    for EachStrain in range(0, len(FurfuralTimepoints)):  #Low Inflection number = high resistance => high score.
        each_comparison = [0] * Number_of_clusters_slope_point  # see which cluster it most belongs to. 0 = perfect match
        for eachcluster in range(0, len(FurfuralSlope_point)):
            each_comparison[eachcluster] = abs(FurfuralSlope_point[eachcluster] - FurfuralTimepoints[EachStrain])
        smallestvalue = sorted(each_comparison)[0]

        for point in range(0, len(each_comparison)):
            if each_comparison[point] == smallestvalue:
                SummaryOfPoints[EachStrain] += (len(each_comparison) - point)
                SlopeCluster_Point.append((len(each_comparison) - point))

if Number_of_clusters_maxod > 0:
    for EachStrain in range(0, len(FurfuralMaxOD)):         ##High OD = high resistance => high score.
        each_comparison = [0] * Number_of_clusters_maxod  # see which cluster it most belongs to. 0 = perfect match
        for eachcluster in range(0, len(FurfuralMaxODPoints)):
            each_comparison[eachcluster] = abs(FurfuralMaxODPoints[eachcluster] - FurfuralMaxOD[EachStrain])
        smallestvalue = sorted(each_comparison)[0]

        for point in range(0, len(each_comparison)):
            if each_comparison[point] == smallestvalue:
                SummaryOfPoints[EachStrain] += (point + 1 )
                MaxODCluster.append(point + 1 )

if Number_of_clusters_slope > 0:
    for EachStrain in range(0, len(FurfuralSlopes)):   #high slope = high resistance => high score.
        each_comparison = [0] * Number_of_clusters_slope  # see which cluster it most belongs to. 0 = perfect match
        for eachcluster in range(0, len(FurfuralSlopesPoints)):
            each_comparison[eachcluster] = abs(FurfuralSlopesPoints[eachcluster] - FurfuralSlopes[EachStrain])
        smallestvalue = sorted(each_comparison)[0]

        for point in range(0, len(each_comparison)):
            if each_comparison[point] == smallestvalue:
                SummaryOfPoints[EachStrain] += (point + 1 )
                SlopeCLuster.append(point + 1 )
'''

NumberResistant = 0
NumberSusceptible = 0
BinaryResistance = []
for i in range(0, len(SummaryOfPoints)):
    if SummaryOfPoints[i] >= int(ScoreValue):
        NumberResistant += 1
        BinaryResistance.append("1")
    else:
        NumberSusceptible += 1
        BinaryResistance.append("0")


name_string = ""
master_figures = [""] * len(Wells)
if Number_of_clusters_inflection > 0:
    name_string = name_string + ",Inflection Cluster Score"
    for i in range(0, len(InflectionCluster)):
        master_figures[i] = master_figures[i] + "," + str(InflectionCluster[i])

if Number_of_clusters_maxod > 0:
    name_string = name_string + ",MaxOD Cluster Score"
    for i in range(0, len(MaxODCluster)):
        master_figures[i] = master_figures[i] + "," + str(MaxODCluster[i])

if Number_of_clustes_cvalue > 0:
    name_string = name_string + ",C_value Cluster Score"
    for i in range(0, len(cvalues)):
        master_figures[i] = master_figures[i] + "," + str(cvalues[i])

if Number_of_clusters_slope > 0:
    name_string = name_string + ",Slope Cluster Score"
    for i in range(0, len(SlopeCLuster)):
        master_figures[i] = master_figures[i] + "," + str(SlopeCLuster[i])

if Number_of_clusters_slope_point > 0:
    name_string = name_string + ",Slope Point Cluster Score"

    for i in range(0, len(SlopeCluster_Point)):
        master_figures[i] = master_figures[i] + "," + str(SlopeCluster_Point[i])
if Number_of_clustes_ratio > 0:
    name_string  = name_string + ",Inflection Ratio furfural/control score"
    for i in range(0, len(Inf_ratios)):
        master_figures[i] = master_figures[i] + "," + str(Inf_ratios[i])
#print(master_figures)
if Number_of_clustes_ratio_slope > 0:
    name_string  = name_string + ",Slope Ratio furfural/control score"
    for i in range(0, len(Slope_ratios)):
        master_figures[i] = master_figures[i] + "," + str(Slope_ratios[i])


print("Well,Highest Slope control,Timepoint Control,Max OD control,Rough Inflection Control,Highest Slope furfural,Timepoint furfural,Max OD furfural,Rough Inflection Point,C Value, Inflection Ratio furfural/control,Slope Ratio furfural/control, Strain Number,Resistance Points (1-10),Binary Resistance (1= resistant)" + name_string, file =OutputGrowthFile)


for Line in range(0, len(SummaryOfPoints)):
    #print(Wells[Line], ControlSlopes[Line], ControlTimepoints[Line], ControlMaxOD[Line], FurfuralSlopes[Line], FurfuralTimepoints[Line], FurfuralMaxOD[Line], FurfuralInflections[Line], StrainList[Line], SummaryOfPoints[Line], BinaryResistance[Line],  sep = ",", file = OutputGrowthFile)
    print(Wells[Line], ControlSlopes[Line], ControlTimepoints[Line], ControlMaxOD[Line], Inflection_control[Line], FurfuralSlopes[Line], FurfuralTimepoints[Line], FurfuralMaxOD[Line], FurfuralInflections[Line], str(C_values[Line]), Inflection_ratio[Line],Slope_ratio[Line],StrainList[Line], SummaryOfPoints[Line], str(BinaryResistance[Line]) + master_figures[Line], sep = ",", file = OutputGrowthFile)


print("Percent of strains counted as resistant: " + str(float((float(NumberResistant)/(float(NumberSusceptible) + float(NumberResistant))))*100) + "%")

#new system (me), from paper
#sum_of_squares_dict
#print(sum_of_squares_dict2)
for charcteristic in sum_of_squares_dict:
    ssa = 0
    all_points = sum_of_squares_dict2["All" + charcteristic]
    overall_mean = sum(all_points)/len(all_points)
    for cluster in range(0, len(sum_of_squares_dict[charcteristic])):
        cluster_points = sum_of_squares_dict[charcteristic][cluster + 1]
        cluster_mean = sum(cluster_points)/len(cluster_points)
        mini_total = 0
        for point in cluster_points:
            for point2 in cluster_points:
                mini_total += (point - point2)**2
        mini_total = mini_total/(2*len(cluster_points))
        ssa += mini_total
    sss = math.log(len(all_points)/12) - (2)*math.log(len(sum_of_squares_dict[charcteristic]))

        #logpn=122=plogkconstant
            #print("*****")
            #print((point - cluster_mean) ** 2)
            #print(ssa)

        #ssa += ((cluster_mean - overall_mean)**2)
    #print(ssa/len(all_points))
    #final_value = round(ssa/len(all_points), 5)
    final_value = ssa
    #final_value =
    print("Sum of squares for %s at k-number %s is %f" % (charcteristic, len(sum_of_squares_dict[charcteristic]), final_value))
    print("Expected %s, difference is %s" % (str(sss), str(ssa-sss)))


'''
#old system (jo)
#sum_of_squares_dict
#print(sum_of_squares_dict2)
for charcteristic in sum_of_squares_dict:
    ssa = 0
    all_points = sum_of_squares_dict2["All" + charcteristic]
    overall_mean = sum(all_points)/len(all_points)
    for cluster in range(0, len(sum_of_squares_dict[charcteristic])):
        cluster_points = sum_of_squares_dict[charcteristic][cluster + 1]
        cluster_mean = sum(cluster_points)/len(cluster_points)
        for point in cluster_points:
            ssa += ((point - cluster_mean) ** 2)
            #print("*****")
            #print((point - cluster_mean) ** 2)
            #print(ssa)

        #ssa += ((cluster_mean - overall_mean)**2)
    #print(ssa/len(all_points))
    #final_value = round(ssa/len(all_points), 5)
    final_value = ssa

    print("Sum of squares for %s at k-number %s is %f" % (charcteristic, len(sum_of_squares_dict[charcteristic]), final_value))
'''
