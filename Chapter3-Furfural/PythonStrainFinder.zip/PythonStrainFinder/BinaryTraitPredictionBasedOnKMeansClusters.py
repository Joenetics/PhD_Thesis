import statistics
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans
import sys
import math
import random

##This code turns k-means clustering prediction data into binary classifications. better than other one which used quartiles.

##This is later run through WekaMaker.py to convert file to .arff to ensure it works in Weka
LogOrLinear = input("Do you want to analyse log or linear growth? Log/Linear")
ScoreValue = 666 #input("What score do you want to count as resistant? 2-8, recommend 6.")
Species = "SacchOnly" #input("What species? E.g, SacchOnly,...")
#Species = ""
#SCset = "Full"
#SCset = "Reduced"
SCset = "DoubleReduced"
de_or_not = input("Do you want to do DE plate?y/n")
if de_or_not.lower() == "y":
    SCset = ""  # for DE
    Species = "DE"  # for DE
global sum_of_squares_dict
global sum_of_squares_dict2
global our_clusters
our_clusters = [["", ""]] * 7

sum_of_squares_dict = dict()
sum_of_squares_dict2 = dict()

Number_of_clusters_inflection = 6   # best at 6
Number_of_clusters_maxod = 6       # alright at 6
Number_of_clusters_slope = 0
Number_of_clusters_slope_point = 6  # best at 6
Number_of_clustes_cvalue = 0
Number_of_clustes_ratio = 0
Number_of_clustes_ratio_slope = 0

#save or load
load_from_save = True
if load_from_save:
    print("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\Clusters_%s_%s_%s_%s_%s_%s_%s.csv" % (str(Number_of_clusters_inflection), str(Number_of_clusters_maxod),
                                                     str(Number_of_clusters_slope), str(Number_of_clusters_slope_point),
                                                     str(Number_of_clustes_cvalue), str(Number_of_clustes_ratio),
                                                     str(Number_of_clustes_ratio_slope)), "r")
    our_clusters = [x.strip().split(";") for x in open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\Clusters_%s_%s_%s_%s_%s_%s_%s.csv" % (str(Number_of_clusters_inflection),
                                                                                                                                                          str(Number_of_clusters_maxod),
                                                                                                                                                          str(Number_of_clusters_slope),
                                                                                                                                                          str(Number_of_clusters_slope_point),
                                                                                                                                                          str(Number_of_clustes_cvalue),
                                                                                                                                                          str(Number_of_clustes_ratio),
                                                                                                                                                          str(Number_of_clustes_ratio_slope)), "r")]
    for listy in range(0, len(our_clusters)):
        non_string = []
        for item in our_clusters[listy]:
            if item == "":
                non_string = []
            else:
                non_string.append(float(item))
        our_clusters[listy] = non_string
    #print(our_clusters)


total_max = Number_of_clusters_inflection + Number_of_clusters_maxod + Number_of_clusters_slope + Number_of_clusters_slope_point + Number_of_clustes_cvalue + Number_of_clustes_ratio + Number_of_clustes_ratio_slope
if LogOrLinear.lower() == "log":
    LogOrLinear = "LogGrowth"
    print("You have chosen to do log growth analysis of binary resistance.")

else:
    LogOrLinear = ""
    print("You have chosen to do linear growth analysis of binary resistance.\nIf you meant to do log, restart and type \'log\'.")

if load_from_save:
    InputGrowthFile = open(
        "C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\JoinedSlopeResultsLogGrowthDEOnly.csv",
        "r")
    OutputGrowthFile = open(
        "C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\WekaPredictedResistanceDEOnly.csv", "w")
else:
    InputGrowthFile = open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\JoinedSlopeResults" + LogOrLinear + Species + SCset + ".csv", "r")

    OutputGrowthFile = open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\WekaPredictedResistance" + LogOrLinear + Species + SCset + str(ScoreValue) +".csv", "w")


Wells = []
ControlSlopes = []
ControlTimepoints = []
ControlMaxOD = []
FurfuralSlopes = []
FurfuralTimepoints = []
FurfuralMaxOD = []
FurfuralInflections = []
StrainList = []
C_values = []
Inflection_control = []
Inflection_ratio = []
Slope_ratio = []

for line in InputGrowthFile:
    data = line.split(",")
    if data[0].lower() == "well":
        pass #This is header line. do not need.
    else:
        Wells.append(data[0])
        ControlSlopes.append(float(data[1]))
        ControlTimepoints.append(float(data[2]))
        ControlMaxOD.append(float(data[3]))
        Inflection_control.append(float(data[4]))
        FurfuralSlopes.append(float(data[5]))
        FurfuralTimepoints.append(float(data[6]))
        FurfuralMaxOD.append(float(data[7]))
        FurfuralInflections.append(float(data[8]))
        C_values.append(float(data[9]))
        StrainList.append(data[10].strip("\n"))
        Inflection_ratio.append((float(data[4])/float(data[8])))
        Slope_ratio.append((float(data[5])/float(data[1])))
print(str(len(FurfuralMaxOD)) + " strains present")

Expected_FurfuralInflections = list()
Expected_FurfuralMaxOD = list()
Expected_FurfuralTimepoints = list()
for fakepoint in range(0, len(Wells)):
    Expected_FurfuralInflections.append(random.randint(sorted(FurfuralInflections)[0], sorted(FurfuralInflections)[-1]))
    Expected_FurfuralMaxOD.append(random.uniform(sorted(FurfuralMaxOD)[0], sorted(FurfuralMaxOD)[-1]))
    Expected_FurfuralTimepoints.append(random.randint(sorted(FurfuralTimepoints)[0], sorted(FurfuralTimepoints)[-1]))


####TEST

wcss = []
for i in range(1, 11):
    kmeans = KMeans(n_clusters=i, init='k-means++', max_iter = 300, n_init=10, random_state=0)
    arrayy = np.asarray(FurfuralSlopes)
    kmeans.fit(arrayy.reshape(-1,1))
    wcss.append(kmeans.inertia_)
plt.plot(range(1, 11), wcss)
plt.title('Elbow Method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
#plt.show()
clusters = 5
kmeans = KMeans(n_clusters=clusters, init='k-means++', max_iter=300, n_init=10, random_state=0)
pred_y = kmeans.fit_predict(arrayy.reshape(-1,1))
templist = []
for ui in range(0, clusters):
    templist.append(kmeans.cluster_centers_[ui][0])


def makeclusters(cluster_number, array_tested):
    kmeans = KMeans(n_clusters=cluster_number, init='k-means++', max_iter=300, n_init=10, random_state=0)
    array_tested = np.asarray(array_tested)
    pred_y = kmeans.fit_predict(array_tested.reshape(-1,1))
    templist = []
    for ui in range(0, cluster_number):
        templist.append(kmeans.cluster_centers_[ui][0])
    templist = sorted(templist)
    return templist



'''
#old
FurfuralInflectionsPoints = [2.0633, 10.7692, 19.0667, 26.3409, 35.5366]  # make into five clusters
FurfuralMaxODPoints = [0.3257, 0.0823, (-0.1131), (-0.3404), (-0.6259)]  # make into 5 clusters
FurfuralSlopesPoints = [0.1486, 0.1019, 0.0656, 0.047, 0.0309]  # make into 5 clusters

#test
FurfuralInflectionsPoints = [1.3788, 7.6111, 12.9143,  19.907, 27.3191, 36.4706]  # make into 6 clusters
FurfuralMaxODPoints = [0.3257, 0.0978, -0.0752,  -0.2684, -0.4461, -0.6767]  # make into 6 clusters
FurfuralSlopesPoints = [0.1486, 0.1019, 0.0656, 0.047, 0.0309]  # make into 5 clusters
'''


global SummaryOfPoints
SummaryOfPoints = [0] * len(FurfuralMaxOD)
if Number_of_clusters_inflection > 0:
    if load_from_save:
        FurfuralInflectionsPoints = our_clusters[0]
        Expected_FurfuralInflectionsPoints = makeclusters(Number_of_clusters_inflection, Expected_FurfuralInflections)
    else:
        FurfuralInflectionsPoints = makeclusters(Number_of_clusters_inflection, FurfuralInflections)
        Expected_FurfuralInflectionsPoints = makeclusters(Number_of_clusters_inflection, Expected_FurfuralInflections)
        our_clusters[0] = (FurfuralInflectionsPoints)
if Number_of_clusters_maxod > 0:
    if load_from_save:
        FurfuralMaxODPoints = our_clusters[1]
        Expected_FurfuralMaxODPoints = makeclusters(Number_of_clusters_maxod, Expected_FurfuralMaxOD)
    else:
        FurfuralMaxODPoints = makeclusters(Number_of_clusters_maxod, FurfuralMaxOD)
        Expected_FurfuralMaxODPoints = makeclusters(Number_of_clusters_maxod, Expected_FurfuralMaxOD)
        our_clusters[1] = (FurfuralMaxODPoints)
if Number_of_clusters_slope > 0:
    if load_from_save:
        FurfuralSlopesPoints = our_clusters[2]
    else:
        FurfuralSlopesPoints = makeclusters(Number_of_clusters_slope, FurfuralSlopes)
        our_clusters[2] = (FurfuralSlopesPoints)
if Number_of_clusters_slope_point > 0:
    if load_from_save:
        FurfuralSlope_point = our_clusters[3]
        Expected_FurfuralSlope_point = makeclusters(Number_of_clusters_slope_point, Expected_FurfuralTimepoints)
    else:
        FurfuralSlope_point = makeclusters(Number_of_clusters_slope_point, FurfuralTimepoints)
        Expected_FurfuralSlope_point = makeclusters(Number_of_clusters_slope_point, Expected_FurfuralTimepoints)
        our_clusters[3] = (FurfuralSlope_point)
    #print(FurfuralSlope_point)
if Number_of_clustes_cvalue > 0:
    if load_from_save:
        Cvalue_cluster_points = our_clusters[4]
    else:
        Cvalue_cluster_points = makeclusters(Number_of_clustes_cvalue, C_values)
        our_clusters[4] = (Cvalue_cluster_points)
if Number_of_clustes_ratio > 0:
    if load_from_save:
        Ratio_cluster_points = our_clusters[5]
    else:
        Ratio_cluster_points = makeclusters(Number_of_clustes_ratio, Inflection_ratio)
        our_clusters[5] = (Ratio_cluster_points)
if Number_of_clustes_ratio_slope > 0:
    if load_from_save:
        Ratio_slope = our_clusters[6]
    else:
        Ratio_slope = makeclusters(Number_of_clustes_ratio_slope, Slope_ratio)
        our_clusters[6] = (Ratio_slope)

#print(FurfuralMaxODPoints)

InflectionCluster = []
MaxODCluster = []
SlopeCLuster = []
SlopeCluster_Point = []
cvalues = []
Inf_ratios = []
Slope_ratios = []

def make_cluster_scorings(number_clusters, raw_data, clusters, negative_or_positive, name_string):
    sum_of_squares_dict[name_string] = {}
    #print(sum_of_squares_dict)
    for oki in range(0, len(clusters)):
        sum_of_squares_dict[name_string][oki + 1] = []
    #print(sum_of_squares_dict)
    global SummaryOfPoints
    clustered_data = []
    Sum_of_Squares = 0

    for EachStrain in range(0, len(raw_data)):  #Low Inflection number = high resistance => high score.
        each_comparison = [0] * number_clusters  # see which cluster it most belongs to. 0 = perfect match
        #print("*****")
        #print(raw_data[EachStrain])
        #print(clusters)
        for eachcluster in range(0, len(clusters)):
            each_comparison[eachcluster] = abs(clusters[eachcluster] - raw_data[EachStrain])
        #print(each_comparison)
        smallestvalue = sorted(each_comparison)[0]
        #print(smallestvalue)
        Sum_of_Squares += float(float(abs(smallestvalue))**2)/(len(raw_data)-1)  # (closest point)^2 /number of strains

        for point in range(0, len(each_comparison)):
            if each_comparison[point] == smallestvalue:
                if ("All"+name_string) in sum_of_squares_dict2:
                    sum_of_squares_dict2["All"+name_string] = sum_of_squares_dict2["All"+name_string] + [raw_data[EachStrain]]
                else:
                    sum_of_squares_dict2["All" + name_string] = [raw_data[EachStrain]]
                if negative_or_positive == "Negative":
                    if "Expected" not in name_string:
                        SummaryOfPoints[EachStrain] += (len(each_comparison) - point)
                    clustered_data.append((len(each_comparison) - point))
                    # for below:
                    # dict[characteristic, e.g, MaxOD][Cluster point, e.g, point 3 of 4] = list of values in that cluster
                    sum_of_squares_dict[name_string][len(each_comparison) - point] = sum_of_squares_dict[name_string][len(each_comparison) - point] + [raw_data[EachStrain]]
                if negative_or_positive == "Positive":
                    if "Expected" not in name_string:
                        SummaryOfPoints[EachStrain] += (point + 1)
                    clustered_data.append((point + 1))
                    # for below:
                    # dict[characteristic, e.g, MaxOD][Cluster point, e.g, point 3 of 4] = list of values in that cluster
                    sum_of_squares_dict[name_string][point + 1] = sum_of_squares_dict[name_string][point + 1] + [raw_data[EachStrain]]
        #print("*****")

    #print(Sum_of_Squares)
    #sys.exit()
    return clustered_data


if Number_of_clustes_cvalue > 0:
    cvalues = make_cluster_scorings(Number_of_clustes_cvalue, C_values, Cvalue_cluster_points, "Positive", "C_Value")

if Number_of_clusters_inflection > 0:
    InflectionCluster = make_cluster_scorings(Number_of_clusters_inflection, FurfuralInflections, FurfuralInflectionsPoints, "Negative", "Inflection")
    Expected_InflectionCluster = make_cluster_scorings(Number_of_clusters_inflection, Expected_FurfuralInflections, Expected_FurfuralInflectionsPoints, "Negative", "InflectionExpected")

if Number_of_clusters_slope_point > 0:
    SlopeCluster_Point = make_cluster_scorings(Number_of_clusters_slope_point, FurfuralTimepoints, FurfuralSlope_point, "Negative", "Slope_Point")
    Expected_SlopeCluster_Point = make_cluster_scorings(Number_of_clusters_slope_point, Expected_FurfuralTimepoints, Expected_FurfuralSlope_point, "Negative", "Slope_PointExpected")

if Number_of_clusters_maxod > 0:
    MaxODCluster = make_cluster_scorings(Number_of_clusters_maxod, FurfuralMaxOD, FurfuralMaxODPoints, "Positive", "MaxOD")
    Expected_MaxODCluster = make_cluster_scorings(Number_of_clusters_maxod, Expected_FurfuralMaxOD, Expected_FurfuralMaxODPoints, "Positive", "MaxODExpected")

if Number_of_clusters_slope > 0:
    SlopeCLuster = make_cluster_scorings(Number_of_clusters_slope, FurfuralSlopes, FurfuralSlopesPoints, "Positive", "Slope_Value")

if Number_of_clustes_ratio > 0:
    Inf_ratios = make_cluster_scorings(Number_of_clustes_ratio, Inflection_ratio, Ratio_cluster_points, "Positive", "Cluster_Ratio")

if Number_of_clustes_ratio_slope > 0:
    Slope_ratios = make_cluster_scorings(Number_of_clustes_ratio_slope, Slope_ratio, Ratio_slope, "Positive", "Slope Ratio")


'''
if Number_of_clustes_cvalue > 0:
    for EachStrain in range(0, len(C_values)):  #Low Inflection number = high resistance => high score.
        each_comparison = [0] * Number_of_clustes_cvalue  # see which cluster it most belongs to. 0 = perfect match
        for eachcluster in range(0, len(Cvalue_cluster_points)):
            each_comparison[eachcluster] = abs(Cvalue_cluster_points[eachcluster] - C_values[EachStrain])
        smallestvalue = sorted(each_comparison)[0]

        for point in range(0, len(each_comparison)):
            if each_comparison[point] == smallestvalue:
                SummaryOfPoints[EachStrain] += (len(each_comparison) - point)
                cvalues.append((len(each_comparison) - point))



if Number_of_clusters_inflection > 0:
    for EachStrain in range(0, len(FurfuralInflections)):  #Low Inflection number = high resistance => high score.
        each_comparison = [0] * Number_of_clusters_inflection  # see which cluster it most belongs to. 0 = perfect match
        for eachcluster in range(0, len(FurfuralInflectionsPoints)):
            each_comparison[eachcluster] = abs(FurfuralInflectionsPoints[eachcluster] - FurfuralInflections[EachStrain])
        smallestvalue = sorted(each_comparison)[0]

        for point in range(0, len(each_comparison)):
            if each_comparison[point] == smallestvalue:
                SummaryOfPoints[EachStrain] += (len(each_comparison) - point)
                InflectionCluster.append((len(each_comparison) - point))


if Number_of_clusters_slope_point > 0:
    for EachStrain in range(0, len(FurfuralTimepoints)):  #Low Inflection number = high resistance => high score.
        each_comparison = [0] * Number_of_clusters_slope_point  # see which cluster it most belongs to. 0 = perfect match
        for eachcluster in range(0, len(FurfuralSlope_point)):
            each_comparison[eachcluster] = abs(FurfuralSlope_point[eachcluster] - FurfuralTimepoints[EachStrain])
        smallestvalue = sorted(each_comparison)[0]

        for point in range(0, len(each_comparison)):
            if each_comparison[point] == smallestvalue:
                SummaryOfPoints[EachStrain] += (len(each_comparison) - point)
                SlopeCluster_Point.append((len(each_comparison) - point))

if Number_of_clusters_maxod > 0:
    for EachStrain in range(0, len(FurfuralMaxOD)):         ##High OD = high resistance => high score.
        each_comparison = [0] * Number_of_clusters_maxod  # see which cluster it most belongs to. 0 = perfect match
        for eachcluster in range(0, len(FurfuralMaxODPoints)):
            each_comparison[eachcluster] = abs(FurfuralMaxODPoints[eachcluster] - FurfuralMaxOD[EachStrain])
        smallestvalue = sorted(each_comparison)[0]

        for point in range(0, len(each_comparison)):
            if each_comparison[point] == smallestvalue:
                SummaryOfPoints[EachStrain] += (point + 1 )
                MaxODCluster.append(point + 1 )

if Number_of_clusters_slope > 0:
    for EachStrain in range(0, len(FurfuralSlopes)):   #high slope = high resistance => high score.
        each_comparison = [0] * Number_of_clusters_slope  # see which cluster it most belongs to. 0 = perfect match
        for eachcluster in range(0, len(FurfuralSlopesPoints)):
            each_comparison[eachcluster] = abs(FurfuralSlopesPoints[eachcluster] - FurfuralSlopes[EachStrain])
        smallestvalue = sorted(each_comparison)[0]

        for point in range(0, len(each_comparison)):
            if each_comparison[point] == smallestvalue:
                SummaryOfPoints[EachStrain] += (point + 1 )
                SlopeCLuster.append(point + 1 )
'''

NumberResistant = 0
NumberSusceptible = 0
BinaryResistance = []
for i in range(0, len(SummaryOfPoints)):
    if SummaryOfPoints[i] >= int(ScoreValue):
        NumberResistant += 1
        BinaryResistance.append("1")
    else:
        NumberSusceptible += 1
        BinaryResistance.append("0")


name_string = ""
master_figures = [""] * len(Wells)
if Number_of_clusters_inflection > 0:
    name_string = name_string + ",Inflection Cluster Score"
    for i in range(0, len(InflectionCluster)):
        master_figures[i] = master_figures[i] + "," + str(InflectionCluster[i])

if Number_of_clusters_maxod > 0:
    name_string = name_string + ",MaxOD Cluster Score"
    for i in range(0, len(MaxODCluster)):
        master_figures[i] = master_figures[i] + "," + str(MaxODCluster[i])

if Number_of_clustes_cvalue > 0:
    name_string = name_string + ",C_value Cluster Score"
    for i in range(0, len(cvalues)):
        master_figures[i] = master_figures[i] + "," + str(cvalues[i])

if Number_of_clusters_slope > 0:
    name_string = name_string + ",Slope Cluster Score"
    for i in range(0, len(SlopeCLuster)):
        master_figures[i] = master_figures[i] + "," + str(SlopeCLuster[i])

if Number_of_clusters_slope_point > 0:
    name_string = name_string + ",Slope Point Cluster Score"

    for i in range(0, len(SlopeCluster_Point)):
        master_figures[i] = master_figures[i] + "," + str(SlopeCluster_Point[i])
if Number_of_clustes_ratio > 0:
    name_string = name_string + ",Inflection Ratio furfural/control score"
    for i in range(0, len(Inf_ratios)):
        master_figures[i] = master_figures[i] + "," + str(Inf_ratios[i])
#print(master_figures)
if Number_of_clustes_ratio_slope > 0:
    name_string = name_string + ",Slope Ratio furfural/control score"
    for i in range(0, len(Slope_ratios)):
        master_figures[i] = master_figures[i] + "," + str(Slope_ratios[i])


print("Well,Highest Myu control,Myu Timepoint Control,Max OD control,Inflection Point Control,Highest Myu furfural,Myu Timepoint furfural,Max OD furfural,Inflection Point Furfural,C Value,Inflection Ratio furfural/control,Slope Ratio furfural/control, Strain Number,Resistance Points (1-%s),Binary Resistance (1= resistant)" % (str(total_max)) + name_string, file =OutputGrowthFile)


for Line in range(0, len(SummaryOfPoints)):
    #print(Wells[Line], ControlSlopes[Line], ControlTimepoints[Line], ControlMaxOD[Line], FurfuralSlopes[Line], FurfuralTimepoints[Line], FurfuralMaxOD[Line], FurfuralInflections[Line], StrainList[Line], SummaryOfPoints[Line], BinaryResistance[Line],  sep = ",", file = OutputGrowthFile)
    print(Wells[Line], ControlSlopes[Line], ControlTimepoints[Line], ControlMaxOD[Line], Inflection_control[Line], FurfuralSlopes[Line], FurfuralTimepoints[Line], FurfuralMaxOD[Line], FurfuralInflections[Line], str(C_values[Line]), Inflection_ratio[Line],Slope_ratio[Line],StrainList[Line], SummaryOfPoints[Line], str(BinaryResistance[Line]) + master_figures[Line], sep = ",", file = OutputGrowthFile)


print("Percent of strains counted as resistant: " + str(float((float(NumberResistant)/(float(NumberSusceptible) + float(NumberResistant))))*100) + "%")

#new system (me), from paper
#sum_of_squares_dict
#print(sum_of_squares_dict2)
for charcteristic in sum_of_squares_dict:
    ssa = 0
    all_points = sum_of_squares_dict2["All" + charcteristic]
    overall_mean = sum(all_points)/len(all_points)
    for cluster in range(0, len(sum_of_squares_dict[charcteristic])):
        cluster_points = sum_of_squares_dict[charcteristic][cluster + 1]
        cluster_mean = sum(cluster_points)/len(cluster_points)
        mini_total = 0
        for point in cluster_points:
            for point2 in cluster_points:
                mini_total += (point - point2)**2
        mini_total = mini_total/(2*len(cluster_points))
        ssa += mini_total
    sss = math.log(len(all_points)/12) - (2)*math.log(len(sum_of_squares_dict[charcteristic]))

        #logpn=122=plogkconstant
            #print("*****")
            #print((point - cluster_mean) ** 2)
            #print(ssa)

        #ssa += ((cluster_mean - overall_mean)**2)
    #print(ssa/len(all_points))
    #final_value = round(ssa/len(all_points), 5)
    final_value = ssa
    #final_value =
    print("Sum of squares for %s at k-number %s is %f" % (charcteristic, len(sum_of_squares_dict[charcteristic]), final_value))
    #print("Expected %s, difference is %s" % (str(sss), str(ssa-sss)))

#print(our_clusters)
if not load_from_save:
    print("Saving...")
    print_clusters = []
    for listy in our_clusters:
        non_float = []
        for item in listy:
            non_float.append(str(item))
        print_clusters.append(";".join(non_float))
    print("\n".join(print_clusters), sep="", file = open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\Clusters_%s_%s_%s_%s_%s_%s_%s.csv" % (str(Number_of_clusters_inflection),
                                                                                                                                                                    str(Number_of_clusters_maxod),
                                                                                                                                                                    str(Number_of_clusters_slope),
                                                                                                                                                                    str(Number_of_clusters_slope_point),
                                                                                                                                                                    str(Number_of_clustes_cvalue),
                                                                                                                                                                    str(Number_of_clustes_ratio),
                                                                                                                                                                    str(Number_of_clustes_ratio_slope)), "w"))
    print("Saved in C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\Clusters_%s_%s_%s_%s_%s_%s_%s.csv"
          % (str(Number_of_clusters_inflection), str(Number_of_clusters_maxod), str(Number_of_clusters_slope),
             str(Number_of_clusters_slope_point), str(Number_of_clustes_cvalue), str(Number_of_clustes_ratio),
             str(Number_of_clustes_ratio_slope)))
our_clusters = []

'''
#old system (jo)
#sum_of_squares_dict
#print(sum_of_squares_dict2)
for charcteristic in sum_of_squares_dict:
    ssa = 0
    all_points = sum_of_squares_dict2["All" + charcteristic]
    overall_mean = sum(all_points)/len(all_points)
    for cluster in range(0, len(sum_of_squares_dict[charcteristic])):
        cluster_points = sum_of_squares_dict[charcteristic][cluster + 1]
        cluster_mean = sum(cluster_points)/len(cluster_points)
        for point in cluster_points:
            ssa += ((point - cluster_mean) ** 2)
            #print("*****")
            #print((point - cluster_mean) ** 2)
            #print(ssa)

        #ssa += ((cluster_mean - overall_mean)**2)
    #print(ssa/len(all_points))
    #final_value = round(ssa/len(all_points), 5)
    final_value = ssa

    print("Sum of squares for %s at k-number %s is %f" % (charcteristic, len(sum_of_squares_dict[charcteristic]), final_value))
'''
