import csv

DictionaryFile= open("DictionaryFileFull.txt", 'r')
OutputCSV = open("DictionaryOutput.csv", 'w')


ArrayForCSV = []
for line in DictionaryFile:
    line2 = line.replace(' ', '*').replace('-', '*').replace('.', ' ').replace(',', '.').replace('*', ',')
    ArrayForCSV.append(line2)

print("Plate,NCYC number,Strain name", file= OutputCSV)
for i in ArrayForCSV:
    print(i.strip(),file = OutputCSV)


