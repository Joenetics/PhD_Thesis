##This code is for generating Manhatten Plots. Gets trait data (etc) and joins it together with SNP data.


##I think I only used these packages...
install.packages("qqman")
install.packages("MASS")
install.packages("lme4")
install.packages("car")
install.packages("ggplot2")
install.packages("ggplot")
install.packages("data.table")
install.packages("backports")
library(data.table)
library (qqman)
library (MASS)
library (lme4)
library (car)
library (ggplot2)

##Format these two lines, then just run the code below to input files
Plates <- c(1,2,3,4,5,6,7)          ##E.g c(1,2,3,4)
PlatesName <- "1-2-3-4-5-6-7"       ##E.g "1-2-3-4"
#PartialOrBinary <- "Partial" 
PartialOrBinary <- "Binary"
#Plates <- c("ZYGO")          ##E.g c(1,2,3,4)
#PlatesName <- "ZYGO"       ##E.g "1-2-3-4"

#Species <- "ZYGO" #not implimented correctly.
Species <- "SacchOnly" #only SC strains
#Species <- "" #if nothing. Or 'All'
IncludingMasked <- "NoMasked"  # dont put masked SNPs in final output
#IncludingMasked <-  ""  # put masked in final output
#S28COnly <- "S28C_Only"  # this is only activated for kinship calculations, but not for actual linear regressions
S28COnly <- ""
#SCset <- "Full"
#SCset <- "Reduced"
SCset <- "DoubleReduced"

if (length(Plates) ==1){
SNPs <- read.csv(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Plate", PlatesName, "VCF_AfterR\\Linear_Regression_",PartialOrBinary,"_SNPs_MappedToReference_Plate", PlatesName, IncludingMasked, S28COnly, SCset, ".txt", sep = ''), sep = ' ', header= FALSE)
print("SNPs done...")
Letter_SNPs <- read.csv(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Plate", PlatesName, "VCF_AfterR\\ATGC_File_AllStrains_Plate", PlatesName, IncludingMasked, S28COnly,SCset, ".csv", sep = ''), header=FALSE)
print("Letter SNPs done...")
TraitData <- read.csv("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC Excel\\PythonStrainFinder\\All9PlatesForWeka.csv", header= TRUE)
print("TraitData done...")
GeneNames <- read.csv(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Plate", PlatesName, "VCF_AfterR\\MAFfile_HighQuality_SNPsOnly_Plate", PlatesName, IncludingMasked, S28COnly, SCset, ".csv", sep = ''), header= FALSE)
print("Gene Names done...")
Qmatrix <- read.csv(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Plate", PlatesName, "VCF_AfterR\\QMatrixForPlates_", PlatesName,".Q", sep =''), sep = " ", row.names = 1, header = FALSE)
print("QMatrix done...")
} else {
  SNPs <- read.csv(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\Linear_Regression_", PartialOrBinary,"_SNPs_MappedToReference_Plates_", PlatesName,Species, IncludingMasked, S28COnly,SCset, ".txt", sep =''), sep = ' ', header= FALSE)
  print("SNPs done...")
  Letter_SNPs <- read.csv(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\ATGC_File_AllStrains_Plates_", PlatesName, Species, IncludingMasked, S28COnly,SCset, ".csv", sep= ''), header=FALSE)
  print("Letter SNPs done...")
  TraitData <- read.csv("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\WekaPredictedResistanceLogGrowthSacchOnlyDoubleReduced5.csv", header= TRUE)
  #TraitData <- read.csv("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\JoinedSlopeResultsLogGrowthBinaryResistance_6OrGreaterSacchOnly.csv", header= TRUE)
  #TraitData <- read.csv("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\JoinedSlopeResultsLogGrowthBinaryResistance_8OrGreater.csv", header= TRUE)
  #TraitData <- read.csv("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joseph_NMR_TraitData.csv", header= TRUE, row.names = 1)
  print("Trait Data done...")
  GeneNames <- read.csv(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\MAFfile_HighQuality_SNPsOnly_Plates_", PlatesName, Species, IncludingMasked,S28COnly, SCset, ".csv", sep = ''), header= FALSE)
  print("Gene Names done...")
  SelectListOfStrains <- read.csv(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\OnlyPlates_", PlatesName,"_OnlySpecies_", Species,".csv", sep =''), header = TRUE)
  print("Select List Of Strains done...")
  #Qmatrix <- read.csv(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\BinaryQMatrixForPlates_", PlatesName,Species,".Q", sep =''), sep = " ", header = FALSE)
  #Qmatrix <- read.csv(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\Linear_Regression_Binary_SNPs_MappedToReference_Plates_1-2-3-4-5-6-7SacchOnly_Clusters20.q", sep =''), sep = "\t", header = FALSE)
  #Qmatrix <- read.csv(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\ATGC_File_AllStrains_Plates_1-2-3-4-5-6-7SacchOnlyNoMasked_ATGCClusters1.q", sep =''), sep = "\t", header = FALSE)
  #Qmatrix <- read.csv(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\ATGC_File_AllStrains_Plates_1-2-3-4-5-6-7SacchOnlyNoMaskedS28C_Only_ATGCClusters_TND1.q", sep =''), sep = "\t", header = FALSE)
  Qmatrix <- read.csv(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\CoreOnlyATGC_File_AllStrains_Plates_1-2-3-4-5-6-7SacchOnlyDoubleReduced_ATGCClusters_TND10.q", sep =''), sep = "\t", header = FALSE)
  #Qmatrix <- read.csv(paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\Post-QMatrixForPython_1-2-3-4-5-6-7SacchOnly_3Clusters.Q", sep =''), sep = " ", header = FALSE)
  print("QMatrix done...")
}


Strain_list <- SelectListOfStrains$NCYC.Number
for (i in Strain_list){
  print(i)
}

Genes <- data.frame(unique(GeneNames$V3))
row.names(SelectListOfStrains) <- SelectListOfStrains$NCYC.Number
#row.names(TraitData) <- TraitData$StrainNumber
row.names(TraitData) <- TraitData$Strain.Number
GeneNames <- data.frame(GeneNames)
rownames(Qmatrix) <- Qmatrix$V1
Qmatrix <- Qmatrix[,-1]   #remove strain names.


#Qmatrix <- apply(Qmatrix,2,as.numeric) #delete this?


##this is 10-interval
Qmatrix[Qmatrix <0.05] <- 0
Qmatrix[Qmatrix >0.05 & Qmatrix< 0.15] <- 0.1
Qmatrix[Qmatrix >0.15 & Qmatrix<0.25] <- 0.2
Qmatrix[Qmatrix >0.25 & Qmatrix<0.35] <- 0.3
Qmatrix[Qmatrix >0.35 & Qmatrix<0.45] <- 0.4
Qmatrix[Qmatrix >0.45 & Qmatrix<0.55] <- 0.5
Qmatrix[Qmatrix >0.55 & Qmatrix<0.65] <- 0.6
Qmatrix[Qmatrix >0.65 & Qmatrix<0.75] <- 0.7
Qmatrix[Qmatrix >0.75 & Qmatrix<0.85] <- 0.8
Qmatrix[Qmatrix >0.85 & Qmatrix<0.95] <- 0.9
Qmatrix[Qmatrix >0.95 & Qmatrix<1] <- 1

#8 step? (0.125) or 0.0625
Qmatrix[Qmatrix <0.0625] <- 0
Qmatrix[Qmatrix >0.0625 & Qmatrix<0.1875] <- 0.125
Qmatrix[Qmatrix >0.1875 & Qmatrix<0.3125] <- 0.25
Qmatrix[Qmatrix >0.3125 & Qmatrix<0.4375] <- 0.375
Qmatrix[Qmatrix >0.4375 & Qmatrix<0.5625] <- 0.5
Qmatrix[Qmatrix >0.5625 & Qmatrix<0.6875] <- 0.625
Qmatrix[Qmatrix >0.6875 & Qmatrix<0.8125] <- 0.750
Qmatrix[Qmatrix >0.8125 & Qmatrix<0.9375] <- 0.875
Qmatrix[Qmatrix >0.9375] <- 1

#5 Step? (0.2...)
Qmatrix[Qmatrix <0.1] <- 0
Qmatrix[Qmatrix >0.1 & Qmatrix<0.3] <- 0.2
Qmatrix[Qmatrix >0.3 & Qmatrix<0.5] <- 0.4
Qmatrix[Qmatrix >0.5 & Qmatrix<0.7] <- 0.6
Qmatrix[Qmatrix >0.7 & Qmatrix<0.9] <- 0.8
Qmatrix[Qmatrix >0.9] <- 1

#4..?
Qmatrix[Qmatrix <0.125] <- 0
Qmatrix[Qmatrix >0.125 & Qmatrix<0.375] <- 0.25
Qmatrix[Qmatrix >0.375 & Qmatrix<0.625] <- 0.5
Qmatrix[Qmatrix >0.625 & Qmatrix<0.875] <- 0.75
Qmatrix[Qmatrix >0.875] <- 1
Qmatrix <- Qmatrix * 4

#3..?
Qmatrix[Qmatrix <0.16] <- 0
Qmatrix[Qmatrix >0.16 & Qmatrix<0.49] <- 0.33
Qmatrix[Qmatrix >0.49 & Qmatrix<0.82] <- 0.66
Qmatrix[Qmatrix >0.82] <- 1
Qmatrix <- Qmatrix * 3

#Turn to one vector!!
Qmatrix$V5 <- Qmatrix$V2*0 ##make new vector in df
for (kk in c(1:length(Qmatrix[,1]))){
  ColValue1 <- Qmatrix[kk,1]
  ColValue2 <- Qmatrix[kk,2]
  ColValue3 <- Qmatrix[kk,3]
  if (ColValue1 > ColValue2 && ColValue1 > ColValue3){
    Qmatrix[kk,4] <- 1
  }
  else if (ColValue2 > ColValue1 && ColValue2 > ColValue3){
    Qmatrix[kk,4] <- 2
  }
  else if (ColValue3 > ColValue2 && ColValue3 > ColValue1){
    Qmatrix[kk,4] <- 3
  }
}


#Run this first, always.
##This makes a DF for the SNPs and removes strain data, making them column names.
SNPs <- t(SNPs)
dfSNPs <- data.frame(SNPs)
colnames(dfSNPs) <- dfSNPs[1,]
dfSNPs <- dfSNPs[-1,]
row.names(dfSNPs) <- (GeneNames$V1)


#Run this second, always. (then skip to ###ONE or ###TWO to start.)
##This is for letter SNPs, to match them later to p-value things
Letter_SNPs <- t(Letter_SNPs)
df_Letter_SNPs <- data.frame(Letter_SNPs)
colnames(df_Letter_SNPs) <- colnames(dfSNPs)
df_Letter_SNPs <- df_Letter_SNPs[-1,]
row.names(df_Letter_SNPs) <- (GeneNames$V1)

##Trait data part. NEED to run all of this part.
for (i in c(611,2435,2474,2516,2628,2677)){##Remove strains that failed genome sequencing in plate 7 
  TraitData <- TraitData[row.names(TraitData) != i,]  
}

#THIS LINE IF YOU WANT ONLY THE SELECT STRAINS (usually SC)
TraitData <- TraitData[c(SelectListOfStrainsIndex),]
TraitData[is.na(TraitData)] <- 0


TraitData1 <- TraitData[row.names(TraitData) == "DeleteAll",]
dfSNPs2 <- dfSNPs[,colnames(dfSNPs) == "DeleteAll"]
df_Letter_SNPs2 <- df_Letter_SNPs[,colnames(dfSNPs) == "DeleteAll"]
Qmatrix2 <- Qmatrix[row.names(Qmatrix) == "DeleteAll",]
SelectListOfStrains2 <- SelectListOfStrains[row.names(SelectListOfStrains) == "DeleteAll",]

for (j in c(colnames(dfSNPs))){             ##Include strains in new df that are present in dfSNPs
  #if ( j %in% c(colnames(dfSNPs)) && j %in% row.names(TraitData) && j %in% row.names(Qmatrix) && TraitData[j,10] < 6 | TraitData[j,10] > 9){
    if ( j %in% c(colnames(dfSNPs)) && j %in% row.names(TraitData) && j %in% row.names(Qmatrix)){
    #TraitData1 <- rbind(TraitData1, TraitData[row.names(TraitData) == j,] )  # original, with all resistances
    TraitData1 <- rbind(TraitData1, TraitData[row.names(TraitData) == j,] )
    dfSNPs2 <- cbind(dfSNPs2, dfSNPs[,colnames(dfSNPs) ==  j] )
    df_Letter_SNPs2 <- cbind(df_Letter_SNPs2, df_Letter_SNPs[,colnames(df_Letter_SNPs) ==  j] )
    Qmatrix2 <- rbind(Qmatrix2, Qmatrix[row.names(Qmatrix) == j,] )
    SelectListOfStrains2 <- rbind(SelectListOfStrains2, SelectListOfStrains[row.names(SelectListOfStrains) == j,] )
    
  }


}
colnames(dfSNPs2) <- rownames(TraitData1)##bring back names to columns of dfSNPs2
colnames(df_Letter_SNPs2) <- rownames(TraitData1)##bring back names to columns of dfSNPs2



#This is for Furfural MaxOD data.
Resistances <- TraitData1$Resistance.Points..1.10.  # Resistances are o longer MaxOD; here, they are resistance from 1-15.
Resistances <- TraitData1$Inflection.Cluster.Score  # ]
Resistances <- TraitData1$Inflection.Cluster.Score
Resistances <- TraitData1$Max.OD.Cluster.Score
Resistances <- TraitData1$Slope.Gradient.Cluster.Score
Resistances <- TraitData1$Inflection.Cluster.Score + TraitData1$Slope.Gradient.Cluster.Score

Resistances <- Resistances/10                      #Turn resistances into a continuous 0-1 scale.
Slopes <- TraitData[c(1:666),5]
Timepoints <- TraitData[c(1:666),6]
Succinate <- TraitData1$Succinate ##only with new NMR one
Succinate[is.na(Succinate)] <- 0 ##We dont need NA values.
Resistances <- TraitData1$Max.OD.furfural


##Maybe try log of values? 100x ?

logg <- -log10(Resistances)
logg[logg == Inf] <- 0


###TEST for below.
for (i in c(1:20)){

Linears <- lm(Resistances~ unlist(dfSNPs2[i,]))


Lmerians <- lmer(Resistances ~ unlist(dfSNPs2[i,])+ (1 | Qmatrix2[,1]) + (1 | Qmatrix2[,2]) + (1 | Qmatrix2[,3]) , REML = FALSE)
#Lmerians2 <- lmer(Resistances ~ unlist(dfSNPs2[i,])+  (1 | Qmatrix2[,4]) , REML = FALSE) #For some reason, only 3rd column matters ... Maybe need mro data?
#Lmerians3 <- lmer(Resistances ~ unlist(dfSNPs2[i,])+ (1 | Qmatrix2[,1]) + (1 | Qmatrix2[,2]) + (1 | Qmatrix2[,3]) +  (1 | Qmatrix2[,4]) , REML = FALSE) #For some reason, only 3rd column matters ... Maybe need mro data?

print(summary(Linears)$coefficients[8])
summary(Lmerians)
print((Anova(Lmerians)$Pr)[1])
#print((Anova(Lmerians2)$Pr)[1])
#print((Anova(Lmerians3)$Pr)[1])
}
options(warn=-1)

###ONE 
#This is code for all strains in dataset

###This is code for making GWAS data frame!!! Each SNP gains a P-value, for later addition into manhatten plot.
PValues <- array(0,dim(dfSNPs2)[1])
LmerPValues <- array (0, dim(dfSNPs2)[1])
LmerPValues_positivenegative <- array (0, dim(dfSNPs2)[1])
logLmerPValues <- array (0, dim(dfSNPs2)[1])
Positive_Negative_Correlation <- array (0, dim(dfSNPs2)[1])

#i <-1
for (i in c(1:dim(dfSNPs2)[1])){
  # logLmerians <- lmer(logg ~ unlist(dfSNPs2[i,])+ (1 | Qmatrix2[,1]) + (1 | Qmatrix2[,2]) + (1 | Qmatrix2[,3]) , REML = FALSE, options(warn = -1))
  
 Linears <- lm(Resistances~ unlist(dfSNPs2[i,]))   ##Remember, resistances MUST == strain numbers! (multiples of 96 for wells.) Then, LR from 0/1 to OD is better!
 #print(Linears$coefficients[2]) 
 if (is.na(summary(Linears)$coefficients[8])){
    PValues[i] <- 1
  }
  else {
    PValues[i] <- summary(Linears)$coefficients[8]
  }
 if (is.na((Linears)$coefficients[2])){
   Positive_Negative_Correlation[i] <- "NA"
 }
 else if (as.double((Linears)$coefficients[2]) >= 0){
   Positive_Negative_Correlation[i] <- "+"
 }
 else {
   Positive_Negative_Correlation[i] <- "-"
}
  #if (is.na(Anova(logLmerians)$Pr[1])){
  #  logLmerPValues[i]<- 1
  #}
  #else {
  #  logLmerPValues[i] <- (Anova(Lmerians)$Pr)[1]
  #}
}


for (i in c(1:dim(dfSNPs2)[1])){
 # logLmerians <- lmer(logg ~ unlist(dfSNPs2[i,])+ (1 | Qmatrix2[,1]) + (1 | Qmatrix2[,2]) + (1 | Qmatrix2[,3]) , REML = FALSE, options(warn = -1))
  
  Lmerians <- lmer(Resistances ~ unlist(dfSNPs2[i,])+ (1 | Qmatrix2[,1]) + (1 | Qmatrix2[,2]) + (1 | Qmatrix2[,3]) , REML = FALSE, options(warn = -1))
  Linears <- lm(Resistances~ unlist(dfSNPs2[i,]))   ##Remember, resistances MUST == strain numbers! (multiples of 96 for wells.) Then, LR from 0/1 to OD is better!
  if (is.na(summary(Linears)$coefficients[8])){
    PValues[i] <- 1
  }
  else {
    PValues[i] <- summary(Linears)$coefficients[8]
  }
  if (is.na(Anova(Lmerians)$Pr[1])){
  LmerPValues[i]<- 1
  }
  else {
  LmerPValues[i] <- (Anova(Lmerians)$Pr)[1]
  }
  #if (is.na(Anova(logLmerians)$Pr[1])){
  #  logLmerPValues[i]<- 1
  #}
  #else {
  #  logLmerPValues[i] <- (Anova(Lmerians)$Pr)[1]
  #}
}

#Initise MyORFs (just numbers, use ORF numbers as fake chromosomes)
MyORFs <- c(1:length(GeneNames$V2))
#Make unique list of ORF names, for chrlabel bit later
ORFnames <- unique(GeneNames$V3)
#This vector of whole gene name must be a character for Manhatten plot.
GeneNames$V3 <- as.character(GeneNames$V3)
#Make DF for manhatten plot
MyGWAS <- data.frame(SNP= GeneNames$V1, CHR= MyORFs, BP= c(1:length(GeneNames$V1)), P= PValues)
MyLmerGWAS <- data.frame(SNP= GeneNames$V1, CHR= MyORFs, BP= c(1:length(GeneNames$V1)), P= LmerPValues)
MylogLmerGWAS <- data.frame(SNP= GeneNames$V1, CHR= MyORFs, BP= c(1:length(GeneNames$V1)), P= logLmerPValues)
#Run Manhatten Plot
manhattan(MyGWAS, col=c("blue4","red3", "green2", "orange3"), chrlabs= ORFnames,  suggestiveline = FALSE, genomewideline = FALSE) #genomewideline = -log10(5e-08)
manhattan(MyLmerGWAS, col=c("blue4","red3", "green2", "orange3"), chrlabs= ORFnames,  suggestiveline = FALSE, genomewideline = FALSE) #genomewideline = -log10(5e-08)



##Without QMATRIX, With dfSNPs2
for (i in c(1:dim(dfSNPs2)[1])){
  Linears <- lm(Succinate~ unlist(dfSNPs2[i,]))   ##Remember, resistances MUST == strain numbers! (multiples of 96 for wells.) Then, LR from 0/1 to OD is better!
  if (is.na(summary(Linears)$coefficients[8])){
    PValues[i] <- 1
  }
  else {
    PValues[i] <- summary(Linears)$coefficients[8]
  }
  
}z


#printing names of genes with selected p-values in list

for (i in c(1:length(PValues))){
  
  if (PValues[i] < 0.001 ){
    ACount = 0
    GCount = 0
    CCount = 0
    TCount = 0
    print(paste("Name of Gene:", GeneNames[i,1], "PValue:", PValues[i]))
    #print(Resistances)
    #print(df_Letter_SNPs[i,],  row.names = FALSE)
    for (f in c(1:length(df_Letter_SNPs2[i,]))){
      if (df_Letter_SNPs2[i,][f] == "A"){
        ACount <- ACount +1
      }
      else if (df_Letter_SNPs2[i,][f] == "G"){
        GCount <- GCount +1
      }
      else if (df_Letter_SNPs2[i,][f] == "C"){
        CCount <- CCount +1
      }
      else if (df_Letter_SNPs2[i,][f] == "T"){
        TCount <- TCount +1
      }
      else{
        print(paste("what: ", df_Letter_SNPs2[i,][f]))
      }
    }
    print(paste("A: ", toString(ACount), "T: ", toString(TCount), "G: ", toString(GCount), "C: ", toString(CCount)), sep ='')
  }
}


#printing names of genes with selected lmer-p-values in list
for (i in c(1:length(LmerPValues))){
  
  if (LmerPValues[i] < 0.0000001 ){
    ACount = 0
    GCount = 0
    CCount = 0
    TCount = 0
    print(paste("Name of Gene:", GeneNames[i,1], "PValue:", LmerPValues[i]))
    #print(Resistances)
    #print(df_Letter_SNPs[i,],  row.names = FALSE)
    for (f in c(1:length(df_Letter_SNPs2[i,]))){
      if (df_Letter_SNPs2[i,][f] == "A"){
        ACount <- ACount +1
      }
      else if (df_Letter_SNPs2[i,][f] == "G"){
        GCount <- GCount +1
      }
      else if (df_Letter_SNPs2[i,][f] == "C"){
        CCount <- CCount +1
      }
      else if (df_Letter_SNPs2[i,][f] == "T"){
        TCount <- TCount +1
      }
      else{
        print(paste("what: ", df_Letter_SNPs2[i,][f]))
      }
    }
    print(paste("A: ", toString(ACount), "T: ", toString(TCount), "G: ", toString(GCount), "C: ", toString(CCount)), sep ='')
  }
}


for (i in c(1:length(Resistances))){
  print(Resistances[i], row.names = FALSE)
}

#Initise MyORFs (just numbers, use ORF numbers as fake chromosomes)
MyORFs <- c(1:length(GeneNames$V2))
#Make unique list of ORF names, for chrlabel bit later
ORFnames <- unique(GeneNames$V3)
#This vector of whole gene name must be a character for Manhatten plot.
GeneNames$V3 <- as.character(GeneNames$V3)
#Make DF for manhatten plot
MyGWAS <- data.frame(SNP= GeneNames$V1, CHR= MyORFs, BP= c(1:length(GeneNames$V1)), P= PValues)
MyLmerGWAS <- data.frame(SNP= GeneNames$V1, CHR= MyORFs, BP= c(1:length(GeneNames$V1)), P= LmerPValues)
MylogLmerGWAS <- data.frame(SNP= GeneNames$V1, CHR= MyORFs, BP= c(1:length(GeneNames$V1)), P= logLmerPValues)
#Run Manhatten Plot
manhattan(MyGWAS, col=c("blue4","red3", "green2", "orange3"), chrlabs= ORFnames,  suggestiveline = FALSE, genomewideline = FALSE) #genomewideline = -log10(5e-08)
manhattan(MyLmerGWAS, col=c("blue4","red3", "green2", "orange3"), chrlabs= ORFnames,  suggestiveline = FALSE, genomewideline = FALSE) #genomewideline = -log10(5e-08)
manhattan(MylogLmerGWAS, col=c("blue4","red3", "green2", "orange3"), chrlabs= ORFnames,  suggestiveline = FALSE, genomewideline = FALSE) #genomewideline = -log10(5e-08)


manhattan(MyGWAS, col=c("blue4"), chrlabs= ORFnames,  suggestiveline = FALSE, genomewideline = FALSE) #genomewideline = -log10(5e-08)
manhattan(MyLmerGWAS, col=c("red3"), chrlabs= ORFnames,  suggestiveline = FALSE, genomewideline = FALSE) #genomewideline = -log10(5e-08)



#Random error, one value was 0 in pvalues, so -log10(p) was infinity... this fixes that.
logLmerPValues[logLmerPValues == 0] <- 0.00001
for (i in c(1: length(LmerPValues))){
  if (LmerPValues[i] == 0.0003){
    print(LmerPValues[i])
  }
}

##Printing Stuff to 'Studio_Hits' file. Then, use RStudio_Hits_mapped_To_Yeast_genome.py to map hits to genome.
CounterForHits <- 0
PValueThreshold <- 0.001         #Modify this for different threshold on hits file.
for (i in c(1:length(PValues))){
  
  if (PValues[i] < PValueThreshold ){
    
    CounterForHits <- CounterForHits + 1
  }
  
}
OutputCSV <- as.data.frame(cbind(c(1:CounterForHits), c(1:CounterForHits)))
colnames(OutputCSV) <- c("GeneNames", "Pvalues")
OutputNumber <- 1
for (i in c(1:length(PValues))){
  
  if (PValues[i] < PValueThreshold ){
    
    OutputCSV[OutputNumber,1] <- GeneNames[i,3]
    OutputCSV[OutputNumber,2] <- PValues[i]
    OutputNumber <- OutputNumber +1
    
  }
  
}
write.csv(OutputCSV, file = paste("Succinate_96Sacch_NOQ_RegularRegression", "_RStudioHits.csv"))











################################################################
###TWO
#This is code for reduced dataset (e.g, only sacch, etc)

##List Strains
colnames(SelectListOfStrains2) <- c("Index", "NCYC", "Strain", "Resistant?", "Binary Resistance")
SelectListOfStrainsNames <- SelectListOfStrains2$NCYC ##Only NCYC number list
SelectListOfStrainsIndex <- SelectListOfStrains2$Index ##Only index of strains

#Resistances becomes the final OD of each strain (in furfural tests). For NMR data, skip this bit. 
ResistancesForSelectStrains <- TraitData1[c(SelectListOfStrainsIndex),7]
##Select List of strains SNP df
SelectSNPs2 <- dfSNPs[,SelectListOfStrainsIndex]
Select_Letter_SNPs <- df_Letter_SNPs[, SelectListOfStrainsIndex]

##put here a way to mix SC & NMR columns only. Start by creating empty DFs
SelectTraitData <- TraitData[row.names(TraitData) == "DeleteAll",]
SelectSNPs <- dfSNPs[,colnames(dfSNPs) == "DeleteAll"]
Select_Letter_SNPs <- df_Letter_SNPs[,colnames(dfSNPs) == "DeleteAll"]

for (j in c(colnames(SelectSNPs2))){             ##Include strains in new df that are present in dfSNPs
  
  if ( j %in% c(colnames(SelectSNPs2)) && j %in% row.names(TraitData1)){  ##TraitData1 has successful NMR strains; SelectSNPs2 has SC (or other) strainss.
    SelectTraitData <- rbind(SelectTraitData, TraitData[row.names(TraitData) == j,] )
    SelectSNPs <- cbind(SelectSNPs, dfSNPs[,colnames(dfSNPs) ==  j] )
    Select_Letter_SNPs <- cbind(Select_Letter_SNPs, df_Letter_SNPs[,colnames(df_Letter_SNPs) ==  j] )
    
  }
  
}
colnames(SelectSNPs) <- rownames(SelectTraitData)##bring back names to columns of dfSNPs2
colnames(Select_Letter_SNPs) <- rownames(SelectTraitData)##bring back names to columns of dfSNPs2


###This is code for making Sacch-only GWAS data frame!!! Each SNP gains a P-value, for later addition into manhatten plot.
PValuesListed <- array(0,dim(SelectSNPs)[1])
for (i in c(1:dim(SelectSNPs)[1])){
  Linears <- lm(SelectTraitData$Succinate~ unlist(SelectSNPs[i,]))
  if (is.na(summary(Linears)$coefficients[8])){FileForPythonThenWeka <- data.frame(GeneNames$V1, LmerPValues )

FileForPythonThenWeka <- data.frame(GeneNames$V1, LmerPValues )
colnames(FileForPythonThenWeka) <- c("GeneNames", "Pvalue_of_Gene")
write.table(FileForPythonThenWeka, paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\lmerPValues_Plates_", PlatesName,"_",Species, IncludingMasked,S28COnly,SCset,  "15points_TND10.csv", sep = ''), sep = ",", col.names = FALSE, row.names = FALSE)
FileForPythonThenWeka <- data.frame(GeneNames$V1, PValues)
colnames(FileForPythonThenWeka) <- c("GeneNames", "Pvalue_of_Gene")
write.table(FileForPythonThenWeka, paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\PValues_Plates_", PlatesName,"_", PartialOrBinary, Species, IncludingMasked, S28COnly,SCset, "15points_Inflection.csv", sep = ''), sep = ",", col.names = FALSE, row.names = FALSE)

FileForPythonThenWeka <- data.frame(GeneNames$V1, LmerPValues, Positive_Negative_Correlation)
colnames(FileForPythonThenWeka) <- c("GeneNames", "Pvalue_of_Gene", "Positive_Or_Negative_Correlation")
write.table(FileForPythonThenWeka, paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\lmerPValues_Plates_", PlatesName,"_",Species, IncludingMasked,S28COnly,SCset,  "15points_SlopeAndInflection_withQ.csv", sep = ''), sep = ",", col.names = FALSE, row.names = FALSE)
FileForPythonThenWeka <- data.frame(GeneNames$V1, PValues, Positive_Negative_Correlation)
colnames(FileForPythonThenWeka) <- c("GeneNames", "Pvalue_of_Gene", "Positive_Or_Negative_Correlation")
write.table(FileForPythonThenWeka, paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\PValues_Plates_", PlatesName,"_", PartialOrBinary, Species, IncludingMasked, S28COnly,SCset, "15points_SlopeAndInflection11.csv", sep = ''), sep = ",", col.names = FALSE, row.names = FALSE)

    PValuesListed[i] <- 1
  }
  else {
    PValuesListed[i] <- summary(Linears)$coefficients[8]
  }
}


#This array will be printed to csv, then used by PValuesForML.py to make .arff file


SameAsTopForOD <- data.frame(row.names(TraitData1), TraitData1$Binary.Resistance..1..resistant.)
colnames(SameAsTopForOD) <- c("Strain", "Strain_Resistance")
write.table(SameAsTopForOD, paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\Joined_MAF_files\\Strain_and_Resistance_", PlatesName, "_", Species, "12.csv", sep = ''), sep = ",", col.names = FALSE, row.names = FALSE)


#printing names of genes with selected p-values in list
for (i in c(1:length(PValuesListed))){
  
  if (PValuesListed[i] < 0.00001 ){
    ACount = 0
    GCount = 0
    CCount = 0
    TCount = 0
    print(paste("Name of Gene:", GeneNames[i,1], "PValue:", PValuesListed[i]))
    #print(Resistances)
    #print(df_Letter_SNPs[i,],  row.names = FALSE)
    for (f in c(1:length(Select_Letter_SNPs[i,]))){
      if (Select_Letter_SNPs[i,][f] == "A"){
        ACount <- ACount +1
      }
      else if (Select_Letter_SNPs[i,][f] == "G"){
        GCount <- GCount +1
      }
      else if (Select_Letter_SNPs[i,][f] == "C"){
        CCount <- CCount +1
      }
      else if (Select_Letter_SNPs[i,][f] == "T"){
        TCount <- TCount +1
      }
      else{
        print(paste("what: ", Select_Letter_SNPs[i,][f]))
      }
    }
    print(paste("A: ", toString(ACount), "G: ", toString(GCount), "C: ", toString(CCount), "T: ", toString(TCount)), sep ='')
  }
}

for (i in c(1:length(SelectTraitData$Succinate))){
  print(SelectTraitData$Succinate[i], row.names = FALSE)
}

#Initise MyORFs (just numbers, use ORF numbers as fake chromosomes)
MyORFs <- GeneNames$V2
#Make unique list of ORF names, for chrlabel bit later
ORFnames <- unique(GeneNames$V3)
#This vector of whole gene name must be a character for Manhatten plot.
GeneNames$V3 <- as.character(GeneNames$V3)
#Make DF for manhatten plot
MyGWAS <- data.frame(SNP= GeneNames$V1, CHR= MyORFs, BP= c(1:length(GeneNames$V1)), P= PValuesListed)
#Run Manhatten Plot
manhattan(MyGWAS, col=c("blue4","red3", "green2", "orange3"), chrlabs= ORFnames,  suggestiveline = FALSE, genomewideline = -log10(1e-11))








## PCA plots

library(devtools)
install_github("htmltools")
install.packages("rlang")
install.packages("rgl")
install.packages("magick")
install.packages("htmltools")
library(htmltools)
library(rgl)
library(magick)
forPCA <- TraitData1[,c(5,7,8)]
colnames(forPCA) <- c("Slope", "Max OD", "Inflection")
pc <- princomp(forPCA, cor=TRUE, scores=TRUE)
#pc <- princomp(TraitData1[,c(5,7,8)], cor=TRUE, scores=TRUE)
summary(pc)
pc$loadings
traitvector <- TraitData1$Binary.Resistance..1..resistant.
traitvector[traitvector == "0"] <- "red"
traitvector[traitvector == "1"] <- "blue"
#plot3d(pc$scores[,1:3], col=traitvector, xlab = "X", ylab = "Y", zlab = "Z", box = TRUE ,axes=FALSE)
plot3d(pc$scores[,1:3], col=traitvector, xlab = "X", ylab = "Y", zlab = "Z")

#movie3d(spin3d(axis = c(0, 0, 1)), 5, dev = rgl.cur(), dir = tempdir("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Jo_Stuff\\Programs_for_joShare\\GIF\\"), convert = TRUE)


movie3d(spin3d(axis = c(0, 1, 0)), 12, dev = rgl.cur(), dir = getwd())


library(devtools)
install_github("vqv/ggbiplot")
install.packages("ggbiplot")
library(ggbiplot)

traitvector <- TraitData1$Slope.Gradient.Cluster.Score + TraitData1$Inflection.Cluster.Score
traitvector[traitvector < 6] <- "Non Resistant"
traitvector[traitvector == 6] <- "Resistant"
traitvector[traitvector == 7] <- "Resistant"
traitvector[traitvector == 8] <- "Resistant"
twochar.pca <- prcomp(TraitData1[,c(5,8)], center = TRUE, scale. = TRUE)

summary(twochar.pca)
ggbiplot(twochar.pca,  var.axes=FALSE, circle = TRUE, ellipse = TRUE,  labels = row.names(TraitData1), groups = traitvector)
