##working directory set as source of R file... which is with Plate reader data.
install.packages("reshape2")
install.packages("ggplot2")
install.packages("Hmisc", dependencies=T)
install.packages('inflection')
library('inflection')
library("Hmisc")
library("reshape2")
library("ggplot2")




#Run this, it reads in all the relevant CSVs (if they're in directory) so you can do the rest of the stuff
LogGrowth <- "LogGrowth" #Run this if you're doing log growth of ODs.
#LogGrowth <- ""          #Run this if you're just using regular data points (linear growth). not recommended.
i <- 1

for (i in 1:9){
FileName1 <- paste("Plate", i, "_Replicate1.csv", sep = '')
FileName2 <- paste("Plate", i, "_Replicate2.csv", sep = '')
FileName3 <- paste("Plate", i, "_Replicate3.csv", sep = '')
#FileName4 <- paste("YPlate", i, "F15R1.csv", sep = '')
#FileName5 <- paste("YPlate", i, "F15R2.csv", sep = '')
#FileName6 <- paste("YPlate", i, "F15R3.csv", sep = '')
#FileName7 <- paste("YPlate", i, "F15R4.csv", sep = '')
FileName8 <- paste("Plate", i, "_Replicate5.csv", sep = '')
#FileName9 <- "testing_three.csv"

MainFile1 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Malt_Extract\\", FileName1, sep = ''))
MainFile2 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Malt_Extract\\", FileName2, sep = ''))
MainFile3 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Malt_Extract\\", FileName3, sep = ''))
#MainFile4 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", FileName4, sep = ''))
#MainFile5 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", FileName5, sep = ''))
#MainFile6 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", FileName6, sep = ''))
#MainFile7 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", FileName7, sep = ''))
MainFile8 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Malt_Extract\\", FileName8, sep = ''))
#MainFile9 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\", FileName9, sep = ''))

# blabla[row,column]
JustData1 <- MainFile1[3:98,4:100]            #Take all the datapoints (every half hour) for all wells.
JustData2 <- MainFile2[3:98,4:100]            #Take all the datapoints (every half hour) for all wells.
JustData3 <- MainFile3[3:98,4:100]            #Take all the datapoints (every half hour) for all wells.
#JustData4 <- MainFile4[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
#JustData5 <- MainFile5[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
#JustData6 <- MainFile6[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
#JustData7 <- MainFile7[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
JustData8 <- MainFile8[3:98,4:100]            #Take all the datapoints (every half hour) for all wells.
#JustData9 <- MainFile9[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.

#sixliner(TRUE, FALSE, FALSE, i)  # sixliner only for YNB with furfural

}


ThreePlot(FALSE, FALSE, FALSE, TRUE, TRUE)

 ####Basic plot of all wells and timepoints

  tab <- t(JustData1) ##Find a way to loop all 3

  plot(tab[,1],type="l",ylim=c(min(tab),max(tab)), main = strsplit(FileName1, ".csv")[[1]], col="red",lty=2,ylab="Optical Density",lwd=1,xlab="Cycle")
  for (i in 2:95){
    lines(tab[,i], type = "l", col = "red", lty = 2, lwd = 1)
  }
  lines(tab[,96], type = "l", col = "black", lty = 2, lwd = 2) ##THIS IS THE CONTROL... which didnt work?
  grid()
  axis(1,at=c(1:nrow(tab)),labels=rownames(tab))

  tab <- t(JustData2) ##Find a way to loop all 3
 #### 
  plot(tab[,1],type="l",ylim=c(min(tab),max(tab)), main = strsplit(FileName2, ".csv")[[1]], col="red",lty=2,ylab="Optical Density",lwd=1,xlab="Cycle")
  for (i in 2:95){
    lines(tab[,i], type = "l", col = "red", lty = 2, lwd = 1)
  }
  lines(tab[,96], type = "l", col = "black", lty = 2, lwd = 2) ##THIS IS THE CONTROL... which didnt work?
  grid()
  axis(1,at=c(1:nrow(tab)),labels=rownames(tab))
 ####
  tab <- t(JustData3) ##Find a way to loop all 3
  
  plot(tab[,1],type="l",ylim=c(min(tab),max(tab)), main = strsplit(FileName3, ".csv")[[1]], col="red",lty=2,ylab="Optical Density",lwd=1,xlab="Cycle")
  for (i in 2:95){
    lines(tab[,i], type = "l", col = "red", lty = 2, lwd = 1)
  }
  lines(tab[,96], type = "l", col = "black", lty = 2, lwd = 2) ##THIS IS THE CONTROL... which didnt work?
  grid()
  axis(1,at=c(1:nrow(tab)),labels=rownames(tab))
  

  



###Here we do each rep on eachother; print out pdf of all 96 wells & their replicates.
  x11()
  par(mfrow=c(12,8))

  par(mar=c(1,1,1,1))
WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
AllThree <- rbind(log10(JustData1), log10(JustData2),log10(JustData3)) ##Log growth!
#AllThree <- rbind((JustData1), (JustData2),(JustData3))              ##normal growth!
for (i in c(1:96)){
  TempVector <- rbind(log10(JustData1[i,]), log10(JustData2[i,]), log10(JustData3[i,])) ##log growth
  #TempVector <- rbind((JustData1[i,]), (JustData2[i,]), (JustData3[i,]))       #Normal growth
  TempVector <- t(TempVector)
  plot(TempVector[,1],type="l",ylim=c(min(AllThree),max(AllThree)), main = paste("Well", WellNames[i], sep = ' '), col="red",lty=2,ylab="Optical Density",lwd=1,xlab="Cycle")
  for (i in 1:3){
    lines(TempVector[,i], type = "l", col = "red", lty = 2, lwd = 1)
  }
  grid()
  axis(1,at=c(1:nrow(TempVector)),labels=rownames(TempVector))

}
  
  dev.copy2pdf(file = "C:/Users/Jsdsa/Desktop/PhD_stuff/Replicates.pdf")
  
  
  
  
  
  ####4-colour plot of quadruple-replicate. 
  #Then, use ReplicateSwapper.py to swap well data, and find best 3 replicates.
  #FourPlot( Do you want it as 12*8 matrix? Then TRUE, do you want an output pdf? then also TRUE)
  #FourPlot(FALSE,FALSE) allows you to run through individual wells in console to see which replicates should be removed of the four.
  FourPlot(FALSE, FALSE)
  
  FourPlot <- function(plotted, yesno){
  
  if (plotted == TRUE) {
  x11()
  par(mfrow=c(8,12))
  
  par(mar=c(1,1,1,1))
  }
  
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
  Tab <- cbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData8[i,])
  Tab <- t(Tab)
  Tab <- data.frame(Tab)
  Tab[,2] <- rep(c(1:97),4)
  Tab[,3] <- c(rep("Red", 97),rep("Blue", 97), rep("Black", 97), rep("pink", 97))
  colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
  plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group, pch = 16, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=c(0,5), xlab = "Cycle(30Min)", ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  

  axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
  } 
  cat("Ignore warnings. They're for row names. Still need to fix that")
  if (yesno == TRUE){
    print("potate")
    dev.copy2pdf(file = paste("C:/Users/Jsdsa/Desktop/PhD_stuff/JustControl", Platenumber,".pdf", sep = ''))
  }
  }
  #Function ends here.

  
  
  ####3-colour plot of quadruple-replicate. 
  #ThreePlot( Do you want it as 12*8 matrix? Then TRUE, do you want an output pdf? then also TRUE)
  #ThreePlot(FALSE,FALSE) allows you to run through individual wells in console to see which replicates should be removed of the four.
  # third option is control (TRUE) and furfural (FALSE). fourth is for mean and SE instead of all replicates
  ThreePlot(FALSE, FALSE, FALSE, TRUE, FALSE)
 
  ThreePlot <- function(plotted, yesno, controlonly, meanSE, logvalues){
    std <- function(x) sd(x)/sqrt(length(x))
    if (plotted == TRUE) {
      x11()
      par(mfrow=c(8,12))
      
      par(mar=c(1,1,1,1))
    }
    
    WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
    for (i in 1:96){
      if (meanSE == FALSE) {
        
      
      if (controlonly == TRUE){
      Tab <- cbind(JustData1[i,], JustData2[i,],JustData3[i,])
      if (logvalues == TRUE){
        Tab <- log(Tab)
      }
      }
      else {
        Tab <- cbind(JustData4[i,], JustData5[i,],JustData6[i,])
        if (logvalues == TRUE){
          Tab <- log(Tab)
        }
      }
      Tab <- t(Tab)
      Tab <- data.frame(Tab)
      Tab[,2] <- rep(c(1:97),3)
      if (controlonly == TRUE){
        Tab[,3] <- c(rep("Red", 97),rep("Red", 97), rep("Red", 97))
        colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
        plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group, pch = 16, yaxt = 'n',xaxt = "n",  cex = 0.1, ylim=c(0,5), xlab = "Time(30Min)", ylab = "OD", main = WellNames[i])  
        
        #axis(1,at=c(1:nrow(Tab)),labels=rownames(c(1:49)))  # use another time
      }
      else{
        Tab[,3] <- c(rep("Blue", 97),rep("Black", 97), rep("Red", 97))
        colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
        plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group, pch = 16, yaxt = 'n',xaxt = "n",  cex = 1, ylim=c(0,5), xlab = "Time(30Min)", ylab = "OpticalDensity", main = paste("Well", WellNames[i], " Furfural", sep = ' '))  
        
        axis(1,at=c(1:nrow(Tab)),labels=rownames(c(1:97)))
      }
      }
      else{
        if (controlonly == TRUE){
          Tab <- cbind(rep(0, 97), rep(0, 97), rep(0, 97), rep(0, 97))
        for (j in 1:length(JustData1)){
          if (logvalues == TRUE){
            Tab[j, 1] <- mean(log(c(JustData1[i,j], JustData2[i,j],JustData3[i,j])))
            Tab[j, 2] <- std(log(c(JustData1[i,j], JustData2[i,j],JustData3[i,j])))
          }
          else{
            Tab[j, 1] <- mean(c(JustData1[i,j], JustData2[i,j],JustData3[i,j]))
            Tab[j, 2] <- std(c(JustData1[i,j], JustData2[i,j],JustData3[i,j]))
          }
        }}
        else{
          Tab <- cbind(rep(0, 97), rep(0, 97), rep(0, 97), rep(0, 97))
          for (j in 1:length(JustData1)){
            if (logvalues == TRUE){
              Tab[j, 1] <- mean(log(c(JustData4[i,j], JustData5[i,j],JustData6[i,j])))
              Tab[j, 2] <- std(log(c(JustData4[i,j], JustData5[i,j],JustData6[i,j])))
            }
            else{
              Tab[j, 1] <- mean(c(JustData4[i,j], JustData5[i,j],JustData6[i,j]))
              Tab[j, 2] <- std(c(JustData4[i,j], JustData5[i,j],JustData6[i,j]))
            }
          }
        }
        
        if (controlonly == TRUE){
          Tab[,3] <- c(rep("Red", 97))
        }
        else{
          Tab[,3] <- c(rep("Blue", 97))
        }
        Tab[,4] <- c(1:97)
        colnames(Tab) <- c("Mean", "STD", "Colour", "Cycle")
        Tab <- data.frame(Tab)
        Tab[,1] <- as.numeric(as.character(Tab[,1]))
        Tab[,2] <- as.numeric(as.character(Tab[,2]))
        if (controlonly == TRUE){
          #plot(c(1:49), Tab$Mean,  pch = 19, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=range(c(Tab$Mean - Tab$STD, Tab$Mean + Tab$STD )), xlab = "Time(30Mins)", ylab = "OpticalDensity", main = paste("Well", WellNames[i], " Control Conditions", sep = ' '))  
          plot(c(1:97), Tab$Mean,  pch = 19,   cex = 1, ylim=5, xlab = "Time(30Mins)", ylab = "OpticalDensity", main = paste("Well", WellNames[i], " Control Conditions", sep = ' '))  
          #plot(c(1:97), Tab$Mean,  pch = 19,   cex = 1, ylim=range(c(Tab$Mean - Tab$STD, Tab$Mean + Tab$STD )), xlab = "Time(30Mins)", ylab = "OpticalDensity", main = paste("Well", WellNames[i], " Control Conditions", sep = ' '))  
          
           }
        else{
          #plot(c(1:49), Tab$Mean,  pch = 19, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=range(c(Tab$Mean - Tab$STD, Tab$Mean + Tab$STD )), xlab = "Time(30Mins)", ylab = "OpticalDensity", main = paste("Well", WellNames[i], " Furfural Conditions", sep = ' ')) 
          plot(c(1:97), Tab$Mean,  pch = 19, cex = 1, ylim=range(c(Tab$Mean - Tab$STD, Tab$Mean + Tab$STD )), xlab = "Time(30Mins)", ylab = "OpticalDensity", main = paste("Well", WellNames[i], " Furfural Conditions", sep = ' ')) 
          
          }
        arrows(c(1:97), Tab$Mean - Tab$STD, c(1:97), Tab$Mean + Tab$STD , length=0.05, angle=90, code=3)
        #axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
        
      }
    } 
    cat("Ignore warnings. They're for row names. Still need to fix that")
    if (yesno == TRUE){
      print("potate")
      dev.copy2pdf(file = paste("C:/Users/Jsdsa/Desktop/PhD_stuff/JustControl", Platenumber,".pdf", sep = ''))
    }
  }
  
  #Function ends here.
  ThreePlot(TRUE, FALSE, TRUE, FALSE, FALSE)
  # ThreePlot <- function(plotted_96, yesno, controlonly, meanSE, logvalues){
  Tab$Mean - Tab$STD
  as.numeric(as.character(Tab$Mean)) - as.numeric(as.character(Tab$STD))
  as.numeric(as.character(Tab$Mean)) + as.numeric(as.character(Tab$STD)) 
  

  
  ##Mean with SD error bars method? eh, didnt continue. keep for posterity. just in case
  
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    Tab <- rbind(JustData1[i,], JustData2[i,],JustData3[i,])
    Tab <- t(Tab)
    Tab <- data.frame(Tab)
    for (j in 1:49){
    Tab[j,4] <- (mean(c(Tab[j,1], Tab[j,2], Tab[j,3])))
    Tab[j,5] <- (sd(c(Tab[j,1], Tab[j,2], Tab[j,3])))
    }
    Tab[,6] <- c(1:49)
    colnames(Tab) <- c("Cycle1", "Cycle2", "Cycle3", "Mean","SD", "Cycle")
    plot(Tab$Cycle, Tab$Mean, pch = 16, cex = 1, xlab = "Cycle(30Min)", ylab = "OD + SD", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
    with (
      data = Tab
      , expr = errbar(Tab$Cycle, Tab$Mean, Tab$Mean + Tab$SD, Tab$Mean - Tab$SD, add=T, pch=1, cap=.1)
    )
    axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
  } 
  cat("Ignore warnings. They're for row names. Still need to fix that")
 
  ##Log10 method, with line over. messy. redo as mean. But works, with all 6 reps being done as log10

  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    Tab <- cbind((log10(cbind(JustData1[i,], JustData2[i,],JustData3[i,]))), log10(cbind(JustData4[i,], JustData5[i,],JustData6[i,])))
    Tab <- t(Tab)
    Tab <- data.frame(Tab)
    Tab[,2] <- rep(c(1:49),6)
    Tab[,3] <- rep((c(rep("Red", 49),rep("Blue", 49), rep("Black", 49))),2)
    colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
    plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group, pch = 16, cex = 1, xlab = "Cycle(30Min)", ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
    
    axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
  } 
  cat("Ignore warnings. They're for row names. Still need to fix that")

  
  
  ##Mean semi-log; also not worth it
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    Tab <- rbind(JustData1[i,], JustData2[i,], JustData3[i,])
    Tab <- t(Tab)
    Tab <- data.frame(Tab)
    for (j in 1:49){
      Tab[j,4] <- mean(c(Tab[j,1], Tab[j,2], Tab[j,3]))
      Tab[j,5] <- log10(Tab[j,4])
    }
    
    Tab2 <- c(Tab[,4], Tab[,5])
    Tab2  <- data.frame(Tab2)
    Tab2[,2] <- rep(c(1:49),2)
    Tab2[,3] <- (c(rep("Red", 49),rep("Blue", 49)))
    colnames(Tab2) <- c("OpticalDensity", "Cycle", "Group")
    plot(Tab2$Cycle, Tab2$OpticalDensity, col = Tab2$Group, pch = 16, cex = 1, xlab = "Cycle(30Min)", ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
    
    axis(1,at=c(1:nrow(Tab2)),labels=rownames(Tab2))
  } 
  cat("Ignore warnings. They're for row names. Still need to fix that")
  
  
  #Maybe with Log10? looks slightly better.
  Tempy <- data.frame(log10(t(rbind(JustData1[i,], JustData2[i,], JustData3[i,], JustData4[i,], JustData5[i,], JustData6[i,]))))
  for (i in 1:49){
    Tempy[i,4] <- (sd(c(JustData1[i,], JustData2[i,], JustData3[i,], JustData4[i,], JustData5[i,], JustData6[i,])))
    Tempy[i,5] <- mean(c(JustData1[i,], JustData2[i,], JustData3[i,], JustData4[i,], JustData5[i,], JustData6[i,]))
  }
  Tempy[,6] <- c(1:49)
  colnames(Tempy) <- c("Replicate 1", "Replicate 2", "Replicate 3", "SD", "Mean", "TimePoint")
  
  plot(Tempy$TimePoint, Tempy$Mean, type="n", main = "SD bars for replicates to log10", ylab = "Mean", xlab = "Cycle")
  with (
    data = Tempy
    , expr = errbar(Tempy$TimePoint, Tempy$Mean, Tempy$Mean + Tempy$SD, Tempy$Mean - Tempy$SD, add=T, pch=1, cap=.1)
  )
  
  
  

  ####just 3 (all replicates of a condition.)
  ###
  x11()
  par(mfrow=c(8,12))
  
  par(mar=c(1,1,1,1))
  
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    Tab <- cbind(JustData1[i,], JustData2[i,],JustData3[i,])
    Tab <- t(Tab)
    Tab <- data.frame(Tab)
    Tab[,2] <- rep(c(1:49),3)
    Tab[,3] <- c(rep("FireBrick1", 49),rep("FireBrick2", 49), rep("FireBrick3", 49))
    colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
    plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, cex = 1,xaxt='n', ylim=c(0,3.5) , ylab = "OpticalDensity", main = WellNames[i])  
    

  } 
  cat("Ignore warnings. They're for row names. Still need to fix that")
  dev.copy2pdf(file = "C:/Users/Jsdsa/Desktop/PhD_stuff/JustControl.pdf")
  
  
  
  ####ALL 6!!
  ###6 lines; with (blueish) and without furfurals (reddish)
  #sixliner(Do you want printouts as log10? yes =TRUE, do you want plots as a 12*8 matrix? yes= TRUE, do you want pdf prinout? yes= TRUE)
  
  sixliner(TRUE,FALSE, FALSE, i)
  
  sixliner <- function(LogOfValues, matrix, pdfout, Platenumber){
  if (matrix == TRUE){
  x11()
  par(mfrow=c(8,12))
  par(mar=c(1,1,1,1))
  
  }
  SteepestSlope1 <- c(1:96)
  SteepestSlope2 <- c(1:96)
  Match1 <- c(1:96)
  Match2 <- c(1:96)
  MaxOD1 <- c(1:96)
  MaxOD2 <- c(1:96)
  InfPoints <- rep(NA, 96)
  Inlfection_Point_Angle <- rep(NA, 96)
  
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    if (LogOfValues == TRUE){
      Tab <- log10(cbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData4[i,], JustData5[i,],JustData6[i,]))
      
    }
    else{
      Tab <- cbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData4[i,], JustData5[i,],JustData6[i,])
      
    }
    Tab <- t(Tab)
    Tab <- data.frame(Tab)
    Tab[,2] <- rep(c(1:49),6)
    Tab[,3] <- c(rep("FireBrick1", 49),rep("FireBrick2", 49), rep("FireBrick3", 49),rep("dodgerblue1", 49),rep("dodgerblue2", 49), rep("dodgerblue3", 49))
    colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
   
     ##Extra bit for slope calc.
    if (LogOfValues == TRUE){
      Tab6 <- rbind(log10(JustData1[i,]), log10(JustData2[i,]),log10(JustData3[i,]),log10(JustData4[i,]), log10(JustData5[i,]),log10(JustData6[i,]), c(1:49), c(1:49), c(1:49))
      
    }
   else{
    Tab6 <- rbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData4[i,], JustData5[i,],JustData6[i,], c(1:49), c(1:49), c(1:49))
   
  } 
    Tab6 <- t(Tab6)
    ##this loop makes average columns (7&8)
    for (k in 1:49){
      Tab6[k,7] <- (Tab6[k,1] + Tab6[k,2] + Tab6[k,3] )/3
      Tab6[k,8] <- (Tab6[k,4] + Tab6[k,5]+ Tab6[k,6] )/3
    }
    ##CORRECT FOR BAD DATA POINTS. 
    ##Only changes next point if it's unusualy high; if its a downward trend, it doesnt change values much.
    plot(1:49, Tab6[,8], main = "Unadjusted Data")
    for (k in 2:46){
      if(Tab6[k,8] < Tab6[k + 1,8] && Tab6[k + 1,8] < Tab6[k + 2,8] && Tab6[k+1,8] > Tab6[k + 3,8] && Tab6[k +2,8] > Tab6[k+3,8] && Tab6[k,8] < Tab6[k +3,8]){
        Tab6[k + 1,8] <- ((Tab6[k + 3,8] - Tab6[k,8])*0.333) + Tab6[k,8]
        Tab6[k + 2,8] <- ((Tab6[k + 3,8] - Tab6[k,8])*0.666) + Tab6[k,8]
      }
      if (Tab6[k,8] < Tab6[k + 1,8] && Tab6[k + 1,8] > Tab6[k + 2,8] && Tab6[k,8] < Tab6[k + 2,8] ){
      Tab6[k + 1,8] <- (Tab6[k,8] + Tab6[k + 2,8])/2
      }
      else if (Tab6[k,8] > Tab6[k + 1,8] && Tab6[k + 1,8] < Tab6[k + 2,8] && Tab6[k,8] < Tab6[k + 2,8]){
        Tab6[k + 1,8] <- (Tab6[k,8] + Tab6[k + 2,8])/2
      }
      
    }
    plot(1:49, Tab6[,8], main = "Smoothed data for slopes") #see what changes?
    #####
    
    
    Tab8 <- data.frame(c(1:97), c(1:97))
    colnames(Tab8) <- c("AverageFurfural", "IndexValue")
    for (h in c(1:48)){
      Tab8$AverageFurfural[2*h-1] <- (Tab8$AverageFurfural[h])
      Tab8$AverageFurfural[2*h] <- (Tab8$AverageFurfural[h] + Tab8$AverageFurfural[h+1])/2
    }
    Tab8$AverageFurfural[97] <- Tab6[49,8]
    LoData <- loess(Tab8$AverageFurfural~ Tab8$IndexValue, data = Tab8, span= 0.40)
    smoothed10 <- predict(LoData) 
    smoothed10 <- smoothed10[seq(1,97,2)]
    
    lo <- loess(Tab6[,8]~Tab6[,9])
    xl <- seq(min(Tab6[,9]),max(Tab6[,9]), (max(Tab6[,9]) - min(Tab6[,9]))/1000)
    out = predict(lo,xl)
    infl <- c(FALSE, diff(diff(out)>0)!=0)
    
    ##This does 3-point average (46+4 =49)
    Slopes1 <- rep(0, 48)
    Slopes2 <- rep(0, 48)
    Slopes3 <- rep(0, 48)
    for (p in 3:48){
      #print(Tab6[p+1,8])
      #print(Tab6[p-1,8])
      #print("*****")
      Slopes1[p] <- ((Tab6[p+1,7]-Tab6[p-1,7])/2)
      Slopes2[p] <- ((Tab6[p+1,8]-Tab6[p-1,8])/2) 
      Slopes3[p] <- ((Tab6[p+1,8]-Tab6[p-1,8])/2)   # inflection needs small slope changes for best results
      
    }
    #plot(1:48, Slopes3, main = "Slopes")
    
    angles <- rep(0, 46)  
    for (slope in 4:46){  # 46+next 2 points check == 48
      if (Tab6[slope+1, 8] > Tab6[slope,8] && Tab6[slope+2,8]> Tab6[slope+1,8] && Tab6[slope-2, 8] < Tab6[slope+2,8]){  # old version (check next two points for increase)

        #angles[slope] <- abs(atan(abs((Slopes3[slope-1] - Slopes3[slope + 1])/(1 + (Slopes3[slope-1] * Slopes3[slope + 1])))))
        angles[slope] <- abs(atan(abs((((Slopes3[slope - 1] + Slopes3[slope - 2])/2) - Slopes3[slope +1])/(1 + (Slopes3[slope+1] * ((Slopes3[slope - 1] + Slopes3[slope - 2])/2))))))
        
        }
    }
    #plot(1:46, angles, main = "Gradient swap")

    
    angles1 <- sort(angles)
    Inlfection_Point_Angle[i] <- match(c(angles1[46]),angles)
    
    if (angles1[46] == 0){
      Inlfection_Point_Angle[i] <- 48
    }
    #print(angles1[45])
    #print(Inlfection_Point_Angle[i])
    #print(angles1)
    
    
    #print(match(c(angles1[46]),angles))
    #print(angles1[46]* 57.2958)
    #print(match(c(angles1[45]),angles))
    #print(angles1[45]* 57.2958)
    #print(match(c(angles1[44]),angles))
    #print(angles1[44]* 57.2958)
    #print(match(c(angles1[43]),angles))
    #print(angles1[43]* 57.2958)
    #print(match(c(angles1[42]),angles))
    #print(angles1[42]* 57.2958)
    
    
    
    MaxOD1[i] <- Tab6[49,7]
    MaxOD2[i] <- Tab6[49,8]
    Slopes3 <- sort(Slopes1)
    Slopes4 <- sort(Slopes2)
    Match1[i] <- match(c(Slopes3[48]),Slopes1)
    Match2[i] <- match(c(Slopes4[48]),Slopes2) ##this is the literal point of steepest slope (middle line)
    InfPoints[i] <- Match2[i] - round(as.numeric((Tab6[(Match2[i]), 8]-Tab6[1,8])/Slopes4[48]),digits=0)
                                      ##Find OD of point representing highest slope. remove lowest point of graph. 
                                    ##then,divide number by slope; find timepoint for when inflection roughly started for fast growth. 
    
    #start_slope = (((Tab6[3,8]+Tab6[4,8]+Tab6[5,8])/3)-Tab6[3,8])
    #print(InfPoints[i])
    #print(Match2[i]-3)
    #print("***")
    #InfPoints[i] <- (Match2[i]- 3)/(start_slope- Slopes4[47])
    #find intersection of slope at point 3 and one at steepest point; doesnt work as many intersect at >|100|
    
    SteepestSlope1[i] <- Slopes3[48]
    SteepestSlope2[i] <- Slopes4[48]
    
    #####
    if (LogOfValues == TRUE){
      plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=c(-1,1) , ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
      
    }
    else{
      plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=c(0,3) , ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
      
    }
   legend("topleft", legend=c(signif(Slopes3[48], digits = 3), signif(Slopes4[48], digits = 3)), col=c("red", "blue"), cex = 1, x.intersp = 0.1,y.intersp = 0.7)
      
      ##axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
      axis(2, 0:3)
    points(xl[infl ], out[infl ], col="black")
    lines(xl, out, col='red', lwd=2)
  } 
  #MainFrame <- data.frame(SteepestSlope1, Match1,MaxOD1, SteepestSlope2, Match2, MaxOD2, InfPoints)
  MainFrame <- data.frame(SteepestSlope1, Match1,MaxOD1, SteepestSlope2, Match2, MaxOD2, Inlfection_Point_Angle)
  colnames(MainFrame) <- c("Highest Slope control", "Timepoint Control", "Max OD control","Highest Slope furfural", "Timepoint furfural", "Max OD furfural", "Rough Inflection Point")
  rownames(MainFrame) <- WellNames
  if (LogOfValues == TRUE){
    write.csv(MainFrame, file = paste("Plate", Platenumber, "SlopeResults", LogGrowth,".csv", sep = ''))
  }
  else{
  write.csv(MainFrame, file = paste("Plate", Platenumber, "SlopeResults.csv", sep = ''))
  }
  sum(SteepestSlope1)/96
  sum(SteepestSlope2)/96
  cat("Ignore warnings. They're for row names. Still need to fix that")
  if (pdfout == TRUE){
  dev.copy2pdf(file = paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Plate", Platenumber, "WithAndWithout.pdf", sep=''))
  }}
  #function ends here
  
  
  sixliner(TRUE,FALSE, FALSE, i)
  
  
  ####ALL 6!!
  ###6 lines; with (blueish) and without furfurals (reddish)
  #sixliner(Do you want printouts as log10? yes =TRUE, do you want plots as a 12*8 matrix? yes= TRUE, do you want pdf prinout? yes= TRUE)
  
  sixlinerKai(TRUE,FALSE, FALSE, i)
  
  sixlinerKai <- function(LogOfValues, matrix, pdfout, Platenumber){
    if (matrix == TRUE){
      x11()
      par(mfrow=c(8,12))
      par(mar=c(1,1,1,1))
      
    }
    SteepestSlope1 <- c(1:96)
    SteepestSlope2 <- c(1:96)
    Match1 <- c(1:96)
    Match2 <- c(1:96)
    MaxOD1 <- c(1:96)
    MaxOD2 <- c(1:96)
    InfPoints <- rep(NA, 96)
    Inlfection_Point_Angle <- rep(NA, 96)
    
    WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
    for (i in 1:96){
      if (LogOfValues == TRUE){
        Tab <- log10(cbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData4[i,], JustData5[i,],JustData6[i,]))
        
      }
      else{
        Tab <- cbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData4[i,], JustData5[i,],JustData6[i,])
        
      }
      Tab <- t(Tab)
      Tab <- data.frame(Tab)
      Tab[,2] <- rep(c(1:97),6)
      Tab[,3] <- c(rep("FireBrick1", 97),rep("FireBrick2", 97), rep("FireBrick3", 97),rep("dodgerblue1", 97),rep("dodgerblue2", 97), rep("dodgerblue3", 97))
      colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
      
      ##Extra bit for slope calc.
      if (LogOfValues == TRUE){
        Tab6 <- rbind(log10(JustData1[i,]), log10(JustData2[i,]),log10(JustData3[i,]),log10(JustData4[i,]), log10(JustData5[i,]),log10(JustData6[i,]), c(1:97), c(1:97), c(1:97))
        
      }
      else{
        Tab6 <- rbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData4[i,], JustData5[i,],JustData6[i,], c(1:97), c(1:97), c(1:97))
        
      } 
      Tab6 <- t(Tab6)
      ##this loop makes average columns (7&8)
      for (k in 1:49){
        Tab6[k,7] <- (Tab6[k,1] + Tab6[k,2] + Tab6[k,3] )/3
        Tab6[k,8] <- (Tab6[k,4] + Tab6[k,5]+ Tab6[k,6] )/3
      }
      
      Tab8 <- data.frame(c(1:97), c(1:97))
      colnames(Tab8) <- c("AverageFurfural", "IndexValue")
      for (h in c(1:96)){
        Tab8$AverageFurfural[2*h-1] <- (Tab8$AverageFurfural[h])
        Tab8$AverageFurfural[2*h] <- (Tab8$AverageFurfural[h] + Tab8$AverageFurfural[h+1])/2
      }
      #dont need this as have enough datapoints (97)
      #Tab8$AverageFurfural[97] <- Tab6[97,8]
      #LoData <- loess(Tab8$AverageFurfural~ Tab8$IndexValue, data = Tab8, span= 0.40)
      #smoothed10 <- predict(LoData) 
      #smoothed10 <- smoothed10[seq(1,97,2)]
      
      lo <- loess(Tab6[,8]~Tab6[,9])
      xl <- seq(min(Tab6[,9]),max(Tab6[,9]), (max(Tab6[,9]) - min(Tab6[,9]))/1000)
      out = predict(lo,xl)
      infl <- c(FALSE, diff(diff(out)>0)!=0)
      
      ##This does 3-point average (46+4 =49)
      Slopes1 <- rep(0, 96)
      Slopes2 <- rep(0, 96)
      for (p in 2:96){
        #print(Tab6[p+1,8])
        #print(Tab6[p-1,8])
        #print("*****")
        Slopes1[p] <- ((Tab6[p+1,7]-Tab6[p-1,7])/2)
        Slopes2[p] <- ((Tab6[p+1,8]-Tab6[p-1,8])/2) 
        #old
        # Slopes2[p] <- (((Tab6[p+1,8]+Tab6[p+2,8]+Tab6[p+3,8])/3)-Tab6[p,8])/1.5
      }
      
      angles <- rep(0, 94)  
      for (slope in 2:94){  # 46+next 2 points check == 48
        #print(Slopes2[slope+2])
        #print(Slopes2[slope+1])
        #print(Slopes2[slope])
        
        if (Slopes2[slope+1] > Slopes2[slope] && Slopes2[slope+2]> Slopes2[slope+1]){  # old version (check next two points for increase)
          #TOM: change to increase at next TWO points. same data? if 0 => 48 (top cluster)
          #if (Slopes2[slope+1] > Slopes2[slope] && Slopes2[slope+2]> Slopes2[slope+1] && Slopes2[slope+3]> Slopes2[slope+2]){  # new; cehck next 3 points.
          angles[slope] <- atan((Slopes2[slope] + Slopes2[slope + 2])/(1 + (Slopes2[slope] * Slopes2[slope + 2])))
        }
        #angles[slope] <- atan((Slopes2[slope] + Slopes2[slope + 1])/(1 + (Slopes2[slope] * Slopes2[slope + 1])))
        #angles[slope] <- abs(tan((Slopes2[slope] + Slopes2[slope + 1])/(1 + (Slopes2[slope] * Slopes2[slope + 1])))) #abs count decrease inflection? so ignore.
      }
      
      angles1 <- sort(angles)
      Inlfection_Point_Angle[i] <- match(c(angles1[94]),angles)
      if (angles1[94] == 0){
        Inlfection_Point_Angle[i] <- 96
      }
      #print(angles1[45])
      #print(Inlfection_Point_Angle[i])
      #print(angles1)
      
      MaxOD1[i] <- Tab6[97,7]
      MaxOD2[i] <- Tab6[97,8]
      Slopes3 <- sort(Slopes1)
      Slopes4 <- sort(Slopes2)
      Match1[i] <- match(c(Slopes3[96]),Slopes1)
      Match2[i] <- match(c(Slopes4[96]),Slopes2) ##this is the literal point of steepest slope (middle line)
      InfPoints[i] <- Match2[i] - round(as.numeric((Tab6[(Match2[i]), 8]-Tab6[1,8])/Slopes4[96]),digits=0)
      ##Find OD of point representing highest slope. remove lowest point of graph. 
      ##then,divide number by slope; find timepoint for when inflection roughly started for fast growth. 
      
      #start_slope = (((Tab6[3,8]+Tab6[4,8]+Tab6[5,8])/3)-Tab6[3,8])
      #print(InfPoints[i])
      #print(Match2[i]-3)
      #print("***")
      #InfPoints[i] <- (Match2[i]- 3)/(start_slope- Slopes4[47])
      #find intersection of slope at point 3 and one at steepest point; doesnt work as many intersect at >|100|
      
      SteepestSlope1[i] <- Slopes3[96]
      SteepestSlope2[i] <- Slopes4[96]
      
      #####
      if (LogOfValues == TRUE){
        plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=c(-1,1) , ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
        
      }
      else{
        plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, yaxt = 'n',xaxt = 'n',  cex = 1, ylim=c(0,3) , ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
        
      }
      legend("topleft", legend=c(signif(Slopes3[96], digits = 3), signif(Slopes4[96], digits = 3)), col=c("red", "blue"), cex = 1, x.intersp = 0.1,y.intersp = 0.7)
      
      ##axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
      axis(2, 0:3)
      points(xl[infl ], out[infl ], col="black")
      lines(xl, out, col='red', lwd=2)
    } 
    #MainFrame <- data.frame(SteepestSlope1, Match1,MaxOD1, SteepestSlope2, Match2, MaxOD2, InfPoints)
    MainFrame <- data.frame(SteepestSlope1, Match1,MaxOD1, SteepestSlope2, Match2, MaxOD2, Inlfection_Point_Angle)
    colnames(MainFrame) <- c("Highest Slope control", "Timepoint Control", "Max OD control","Highest Slope furfural", "Timepoint furfural", "Max OD furfural", "Rough Inflection Point")
    rownames(MainFrame) <- WellNames
    if (LogOfValues == TRUE){
      write.csv(MainFrame, file = paste("Plate", Platenumber, "SlopeResults", LogGrowth,".csv", sep = ''))
    }
    else{
      write.csv(MainFrame, file = paste("Plate", Platenumber, "SlopeResults.csv", sep = ''))
    }
    sum(SteepestSlope1)/96
    sum(SteepestSlope2)/96
    cat("Ignore warnings. They're for row names. Still need to fix that")
    if (pdfout == TRUE){
      dev.copy2pdf(file = paste("C:\\Users\\Joe\\Desktop\\PhD_stuff\\Plate", Platenumber, "WithAndWithout.pdf", sep=''))
    }}
  #function ends here
  
  sixlinerKai(TRUE,FALSE, FALSE, i)
  #######
  
    
  ##all 6 just for report
  x11()
  par(mfrow=c(8,12))
  
  #par(mar=c(2,2,2,2))
  par(mar=c(1,1,1,1))
  SteepestSlope1 <- c(1:96)
  SteepestSlope2 <- c(1:96)
  Match1 <- c(1:96)
  Match2 <- c(1:96)
  
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    Tab <- cbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData4[i,], JustData5[i,],JustData6[i,])
    Tab <- (t(Tab))
    Tab <- data.frame(Tab)
    Tab[,2] <- rep(c(1:49),6)
    Tab[,3] <- c(rep("FireBrick1", 49),rep("FireBrick2", 49), rep("FireBrick3", 49),rep("dodgerblue1", 49),rep("dodgerblue2", 49), rep("dodgerblue3", 49))
    colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
    
    #####
    #plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, ,  cex = 1, ylim=c(0,3) , ylab = "OpticalDensity", main = paste("Well", WellNames[i], sep = ' '))  
    plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, ,  cex = 1, xaxt = "n", yaxt = "n", ylab = "OpticalDensity", main = paste("Well", WellNames[i], sep = ' '))  
    
    if (i== 85){
      
      axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
      axis(2)
    }
  } 
  par(new=F)
  plot(xaxt = c(1:12), yaxt = c("A", "B", "C", "D", "E", "F", "G", "H"), ylab = "OpticalDensity", main = paste("Well", WellNames[i], sep = ' '))  
  cat("Ignore warnings. They're for row names. Still need to fix that")
  dev.copy2pdf(file = "C:\\Users\\Joe\\Desktop\\PhD_stuff\\Plate1WithAndWithout.pdf")
  
  ###############################################################################
  ##Just 1 well for testing####
  #first, load data
  FileName1 <- "ZYGO_TEST_F-top_vs_M-bottom.csv"
  MainFile1 <- read.csv(paste ("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\", FileName1, sep = ''))
  JustData1 <- MainFile1[3:98,4:52]            #Take all the datapoints (every half hour) for all wells.
  #### Next, run thingy
  
  x11()
  par(mfrow=c(8,12))
  
  par(mar=c(1,1,1,1))
  SteepestSlope1 <- c(1:96)
  SteepestSlope2 <- c(1:96)
  Match1 <- c(1:96)
  Match2 <- c(1:96)
  
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    Tab <- cbind(JustData1[i,])
    Tab <- (t(Tab))
    Tab <- data.frame(Tab)
    Tab[,2] <- rep(c(1:49))
    Tab[,3] <- rep("FireBrick1", 49)
    colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
    #####
    plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group ,pch = 16, ,  cex = 1, ylim=c(0,3) , ylab = "OpticalDensity", main = paste("Well", WellNames[i], sep = ' '))  
    
    if (i== 85){
      
      axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
      axis(2)
    }
  } 
  
  cat("Ignore warnings. They're for row names. Still need to fix that")
  dev.copy2pdf(file = "C:\\Users\\Joe\\Desktop\\PhD_stuff\\Plate1WithAndWithout.pdf")
  

  
  ####Below is orig. slope calc
  Tab6 <- rbind(JustData1[4,], JustData2[4,],JustData3[4,],JustData4[4,], JustData5[4,],JustData6[4,], c(1:49), c(1:49), c(1:49))
  Tab6 <- (t(Tab6))

  for (k in 1:49){
    Tab6[k,7] <- (Tab6[k,1] + Tab6[k,2] + Tab6[k,3] )/3
    Tab6[k,8] <- (Tab6[k,4] + Tab6[k,5]+ Tab6[k,6] )/3
  }
  Tab7 <- data.frame(Tab6)
  colnames(Tab7) <- c("AvControl1", "AvControl2", "AvControl3", "AcFurfural1", "AvFurfural2", "AvFurfural3", "AverageControl", "AverageFurfural", "Index")
  A<-findiplist(Tab7$AverageFurfural, Tab7$Index,0)
  print(A[5])
  Pizza = 1
  for (i in Tab7$AverageFurfural){
    Pie = i- A[5]
    if (abs(Pie) < Pizza){
      Pizza = Pie
    }
  }
  LagValue <- Pizza
  
  Slopes1 <- c(1:46)
  Slopes2 <- c(1:46)
  for (p in 1:46){
    Slopes1[p] <- (((Tab6[p+1,7]+Tab6[p+2,7]+Tab6[p+3,7])/3)-Tab6[p,7])/1.5
    Slopes2[p] <- (((Tab6[p+1,8]+Tab6[p+2,8]+Tab6[p+3,8])/3)-Tab6[p,8])/1.5
  }
  Slopes3 <- sort(Slopes1)
  Slopes4 <- sort(Slopes2)
  SteepestSlope1 <- Slopes3[46]
  SteepestSlope2 <- Slopes4[46]
  signif(SteepestSlope1, digits = 3)
  signif(SteepestSlope2, digits = 3)
  
  viewer <- data.frame(Slopes1, Slopes2, c(1:46))
plot(viewer$c.1.46., viewer$Slopes2, ylab = "Slope steepness", xlab = "timepoint")



  ##All 9- test

  
  x11()
  par(mfrow=c(8,12))
  
  par(mar=c(1,1,1,1))
  
  ###6 Colours; with (blueish) and without furfurals (reddish)
  WellNames <- c("A01" ,"A02" ,"A03" ,"A04" ,"A05" ,"A06" ,"A07" ,"A08" ,"A09" ,"A10" ,"A11" ,"A12" ,"B01" ,"B02" ,"B03" ,"B04" ,"B05" ,"B06" ,"B07" ,"B08" ,"B09" ,"B10" ,"B11" ,"B12" ,"C01" ,"C02" ,"C03" ,"C04" ,"C05" ,"C06" ,"C07" ,"C08" ,"C09" ,"C10" ,"C11" ,"C12" ,"D01" ,"D02" ,"D03" ,"D04" ,"D05" ,"D06" ,"D07" ,"D08" ,"D09" ,"D10" ,"D11" ,"D12" ,"E01" ,"E02" ,"E03" ,"E04" ,"E05" ,"E06" ,"E07" ,"E08" ,"E09" ,"E10" ,"E11" ,"E12" ,"F01" ,"F02" ,"F03" ,"F04" ,"F05" ,"F06" ,"F07" ,"F08" ,"F09" ,"F10" ,"F11" ,"F12" ,"G01" ,"G02" ,"G03" ,"G04" ,"G05" ,"G06" ,"G07" ,"G08" ,"G09" ,"G10" ,"G11" ,"G12" ,"H01" ,"H02" ,"H03" ,"H04" ,"H05" ,"H06" ,"H07" ,"H08" ,"H09" ,"H10" ,"H11" ,"H12")
  for (i in 1:96){
    Tab <- cbind(JustData1[i,], JustData2[i,],JustData3[i,],JustData4[i,], JustData5[i,], JustData6[i,],JustData7[i,], JustData8[i,], JustData9[i,])
    Tab <- t(Tab)
    Tab <- data.frame(Tab)
    Tab[,2] <- rep(c(1:49),9)
    Tab[,3] <- c(rep("FireBrick1", 49),rep("FireBrick2", 49), rep("FireBrick3", 49),rep("dodgerblue1", 49),rep("dodgerblue2", 49), rep("dodgerblue3", 49), rep("black", 49), rep("black", 49), rep("black", 49))
    colnames(Tab) <- c("OpticalDensity", "Cycle", "Group")
    plot(Tab$Cycle, Tab$OpticalDensity, col = Tab$Group, pch = 16, cex = 1, xlab = "Cycle(30Min)", ylab = "OpticalDensity", main = paste("Replicate Test Well", WellNames[i], sep = ' '))  
    
    axis(1,at=c(1:nrow(Tab)),labels=rownames(Tab))
  } 
  cat("Ignore warnings. They're for row names. Still need to fix that")
  dev.copy2pdf(file = "C:/Users/Jsdsa/Desktop/PhD_stuff/Plate3F25R3.pdf")
  
  
  
  