import sys
import csv

PlateA = input("Replicate number of first plate")         #name of file
PlateB = input("Replicate number of second plate")        #Name of second file
Plate1 = "C:\\Users\\Joe\\Desktop\\PhD_stuff\\Malt_Extract\\Plate1_Replicate" + PlateA + ".csv"
Plate2 = "C:\\Users\\Joe\\Desktop\\PhD_stuff\\Malt_Extract\\Plate1_Replicate" + PlateB + ".csv"

WellSwapper = input("Which well do you want to swap?")                                                             #Well number to swap
WellSwapper = WellSwapper.upper()


if len(WellSwapper) == 2:                                                                                        #Adds '0' for string match
    WellSwapper = WellSwapper[:1] + "0" + WellSwapper[1:]
print("Assuming well number", WellSwapper, sep = ' ')
if len(WellSwapper) > 3:                                                                                           #Error if well name too long
    print("Well name too long.\nThere are only wells A-H and numbers 1-12\ne.g; D06/D6", sep = '')
    sys.exit()
Alphabet = ["A", "B", "C", "D", "E", "F", "G", "H"]                                                                #Valid well letters (A-H)
Numbers = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]                                 #Valid well numbers (1-12)
if (WellSwapper[:1]) in Alphabet:
    pass
else:
    print("No well matched to \n", WellSwapper,"\nWell names are not sensitive. \nThere are only wells A-H and numbers 1-12\ne.g; D06/D6", sep = '')
    sys.exit()
if (WellSwapper[1:]) in Numbers:
    pass
else:
    print("No well matched to \n", WellSwapper,"\nWell names are not sensitive. \nThere are only wells A-H and numbers 1-12\ne.g; D06/D6", sep='')
    sys.exit()

LineSwapper1 = list                     #Initialising variables
LineSwapper2 = list
EntireCSV1 = []
EntireCSV2 = []

with open(Plate1) as csvfile:                       #Open first file
    readCSV1 = csv.reader(csvfile, delimiter=',')   #Read into temp variable
    for row in readCSV1:                            #Read each row
        if row[0] == WellSwapper:                   #If well number matches, good!
            LineSwapper1 = row                      #Save row if well matches
        EntireCSV1.append(row)                      #Save entire CSV file

with open(Plate2) as csvfile:                       #Open Second file
    readCSV2 = csv.reader(csvfile, delimiter=',')   #Read into temp variable
    for row in readCSV2:                            #Read each row
        if row[0] == WellSwapper:                   #If well number matches, good!
            LineSwapper2 = row                      #Save row if well matches
        EntireCSV2.append(row)                      #Save entire CSV file

index = int                     #Initialise variable

for line in EntireCSV1:                     #Loop through all CSV lines
    if line[0] == WellSwapper:              #If find correct row (matching well)
        index = EntireCSV1.index(line)      #Save index of matching row

#print("Before: ", EntireCSV1[index])
EntireCSV1[index] = LineSwapper2            #Swap other file's line for this one's.
#print("After: ", EntireCSV1[index])

#print("Before: ", EntireCSV2[index])
EntireCSV2[index] = LineSwapper1            #Swap other file's line for this one's.
#print("After: ", EntireCSV2[index])

with open(Plate1, "w", newline = '') as f:  #Re-write original file
    writer = csv.writer(f)
    writer.writerows(EntireCSV1)            #Print out modified file to CSV
with open(Plate2, "w", newline = '') as f:  #Re-write original file
    writer = csv.writer(f)
    writer.writerows(EntireCSV2)            #Print out modified file to CSV
