import statistics
import numpy as np
import sys


##This is later run through WekaMaker.py to convert file to .arff to ensure it works in Weka
LogOrLinear = input("Do you want to analyse log or linear growth? Log/Linear")
ScoreValue = 6 #input("What score do you want to count as resistant? 1-12, recommend 8.")
Species = "SacchOnly" #input("What species? E.g, SacchOnly,...")
if LogOrLinear.lower() == "log":
    LogOrLinear = "LogGrowth"
    print("You have chosen to do log growth analysis of binary resistance.")
else:
    LogOrLinear = ""
    print("You have chosen to do linear growth analysis of binary resistance.\nIf you meant to do log, restart and type \'log\'.")


InputGrowthFile = open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\JoinedSlopeResults" + LogOrLinear+ Species +".csv", "r")
OutputGrowthFile = open("C:\\Users\\Joe\\Desktop\\PhD_stuff\\NCYC_Excel\\PythonStrainFinder\\JoinedSlopeResults" + LogOrLinear+ "BinaryResistance_"+ str(ScoreValue)+"OrGreater"+ Species+".csv", "w")

print("Well,Highest Slope control,Timepoint Control,Max OD control,Highest Slope furfural,Timepoint furfural,Max OD furfural,Rough Inflection Point, Strain Number, Resistance Points (1-10), Binary Resistance (1= resistant)", file =OutputGrowthFile)

Wells = []
ControlSlopes = []
ControlTimepoints = []
ControlMaxOD = []
FurfuralSlopes = []
FurfuralTimepoints = []
FurfuralMaxOD = []
FurfuralInflections = []
StrainList = []
for line in InputGrowthFile:
    data = line.split(",")
    if data[0].lower() == "well":
        pass #This is header line. do not need.
    else:
        Wells.append(data[0])
        ControlSlopes.append(float(data[1]))
        ControlTimepoints.append(float(data[2]))
        ControlMaxOD.append(float(data[3]))
        FurfuralSlopes.append(float(data[4]))
        FurfuralTimepoints.append(float(data[5]))
        FurfuralMaxOD.append(float(data[6]))
        FurfuralInflections.append(float(data[7]))
        StrainList.append(data[8].strip("\n"))

print(str(len(FurfuralMaxOD)) + " strains present")




FurODMedians = np.percentile(FurfuralMaxOD, [25,50,75])
FurInflectionMedians = np.percentile(FurfuralInflections, [25,50,75])
FurSlopeMedians = np.percentile(FurfuralSlopes, [25,50,75])

SummaryOfPoints = [0] * len(FurfuralMaxOD)

for EachStrain in range(0, len(FurfuralInflections)):  #Low Inflection number = high resistance => high score.
    if FurfuralInflections[EachStrain] <= FurInflectionMedians[0]:
        SummaryOfPoints[EachStrain] += 0
    elif FurfuralInflections[EachStrain] > FurInflectionMedians[0] and FurfuralInflections[EachStrain] <= FurInflectionMedians[1]:
        SummaryOfPoints[EachStrain] += 1
    elif FurfuralInflections[EachStrain] > FurInflectionMedians[1] and FurfuralInflections[EachStrain] <= FurInflectionMedians[2]:
        SummaryOfPoints[EachStrain] += 2
    elif FurfuralInflections[EachStrain] > FurInflectionMedians[2]:
        SummaryOfPoints[EachStrain] += 3

for EachStrain in range(0, len(FurfuralMaxOD)):         ##High OD = high resistance => high score.
    if FurfuralMaxOD[EachStrain] <= FurODMedians[0]:
        SummaryOfPoints[EachStrain] += 2
    elif FurfuralMaxOD[EachStrain] > FurODMedians[0] and FurfuralMaxOD[EachStrain] <= FurODMedians[1]:
        SummaryOfPoints[EachStrain] += 4
    elif FurfuralMaxOD[EachStrain] > FurODMedians[1] and FurfuralMaxOD[EachStrain] <= FurODMedians[2]:
        SummaryOfPoints[EachStrain] += 5
    elif FurfuralMaxOD[EachStrain] > FurODMedians[2]:
        SummaryOfPoints[EachStrain] += 6

for EachStrain in range(0, len(FurfuralSlopes)):   #high slope = high resistance => high score.
    if FurfuralSlopes[EachStrain] <= FurSlopeMedians[0]:
        SummaryOfPoints[EachStrain] += 0
    elif FurfuralSlopes[EachStrain] > FurSlopeMedians[0] and FurfuralSlopes[EachStrain] <= FurSlopeMedians[1]:
        SummaryOfPoints[EachStrain] += 1
    elif FurfuralSlopes[EachStrain] > FurSlopeMedians[1] and FurfuralSlopes[EachStrain] <= FurSlopeMedians[2]:
        SummaryOfPoints[EachStrain] += 2
    elif FurfuralSlopes[EachStrain] > FurSlopeMedians[2]:
        SummaryOfPoints[EachStrain] += 3

NumberResistant = 0
NumberSusceptible = 0
BinaryResistance = []
for i in range(0, len(SummaryOfPoints)):
    if SummaryOfPoints[i] >= int(ScoreValue):
        NumberResistant += 1
        BinaryResistance.append("1")
    else:
        NumberSusceptible += 1
        BinaryResistance.append("0")


for Line in range(0, len(SummaryOfPoints)):
    print(Wells[Line], ControlSlopes[Line], ControlTimepoints[Line], ControlMaxOD[Line], FurfuralSlopes[Line], FurfuralTimepoints[Line], FurfuralMaxOD[Line], FurfuralInflections[Line], StrainList[Line], SummaryOfPoints[Line], BinaryResistance[Line], sep = ",", file = OutputGrowthFile)

print("Percent of strains counted as resistant: " + str(float((float(NumberResistant)/(float(NumberSusceptible)+ float(NumberResistant))))*100) + "%")




